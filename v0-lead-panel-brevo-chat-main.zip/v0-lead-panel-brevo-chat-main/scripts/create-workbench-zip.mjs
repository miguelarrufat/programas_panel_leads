import { execSync } from "child_process";
import { existsSync } from "fs";
import path from "path";

const sourceDir = path.resolve("salesforce/force-app/main/default");
const outputZip = path.resolve("public/workbench-deploy.zip");

if (!existsSync(sourceDir)) {
  console.error("Source directory not found:", sourceDir);
  process.exit(1);
}

// Create ZIP with package.xml at root level (required by Workbench)
execSync(`cd "${sourceDir}" && zip -r "${outputZip}" .`, {
  stdio: "inherit",
});

console.log("ZIP created successfully at:", outputZip);
console.log("Download it from: /workbench-deploy.zip");
