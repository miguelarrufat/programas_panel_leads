/**
 * Script to generate Salesforce deployment ZIP for Workbench
 * Run: node scripts/generate-salesforce-zip.js
 */

import { readdir, stat, readFile, mkdir, writeFile } from 'fs/promises';
import { join, relative, dirname } from 'path';
import { fileURLToPath } from 'url';
import JSZip from 'jszip';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const ROOT_DIR = '/vercel/share/v0-project';

const SOURCE_DIR = join(ROOT_DIR, 'salesforce/force-app/main/default');
const OUTPUT_FILE = 'brevo-salesforce-lwc.zip';

async function getAllFiles(dir, fileList = []) {
    const files = await readdir(dir);
    for (const file of files) {
        const filePath = join(dir, file);
        const fileStat = await stat(filePath);
        if (fileStat.isDirectory()) {
            await getAllFiles(filePath, fileList);
        } else {
            fileList.push(filePath);
        }
    }
    return fileList;
}

async function createZip() {
    const zip = new JSZip();
    const files = await getAllFiles(SOURCE_DIR);
    
    // Add files to archive
    for (const file of files) {
        const relativePath = relative(SOURCE_DIR, file);
        const content = await readFile(file);
        zip.file(relativePath, content);
    }
    
    // Generate ZIP
    const zipContent = await zip.generateAsync({ 
        type: 'nodebuffer',
        compression: 'DEFLATE',
        compressionOptions: { level: 9 }
    });
    
    // Write to current working directory
    await writeFile(OUTPUT_FILE, zipContent);
    
    console.log(`\n✅ ZIP created successfully!`);
    console.log(`📦 File: ${OUTPUT_FILE}`);
    console.log(`📊 Size: ${(zipContent.length / 1024).toFixed(2)} KB`);
    console.log(`\n🧪 Run Tests: BrevoConversationsControllerTest, BrevoWebhookHandlerTest, BrevoLeadTriggerHandlerTest, BrevoFieldUpdaterTest`);
}

createZip().catch(console.error);
