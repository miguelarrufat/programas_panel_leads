import { createWriteStream, mkdirSync, existsSync, readFileSync } from 'fs';
import { join, dirname } from 'path';
import archiver from 'archiver';

const projectRoot = process.cwd();
const publicDir = join(projectRoot, 'public');
const salesforceDir = join(projectRoot, 'salesforce', 'force-app', 'main', 'default');

// Ensure public directory exists
if (!existsSync(publicDir)) {
  mkdirSync(publicDir, { recursive: true });
}

async function createZip(outputPath, files) {
  return new Promise((resolve, reject) => {
    const output = createWriteStream(outputPath);
    const archive = archiver('zip', { zlib: { level: 9 } });
    
    output.on('close', () => resolve());
    archive.on('error', (err) => reject(err));
    
    archive.pipe(output);
    
    for (const file of files) {
      const filePath = join(salesforceDir, file.src);
      if (existsSync(filePath)) {
        archive.file(filePath, { name: file.dest });
      }
    }
    
    archive.finalize();
  });
}

// ZIP 2: Apex Classes
const zip2Files = [
  { src: 'package.xml', dest: 'package.xml' },
  { src: 'classes/BrevoConversationsController.cls', dest: 'classes/BrevoConversationsController.cls' },
  { src: 'classes/BrevoConversationsController.cls-meta.xml', dest: 'classes/BrevoConversationsController.cls-meta.xml' },
  { src: 'classes/BrevoConversationsControllerTest.cls', dest: 'classes/BrevoConversationsControllerTest.cls' },
  { src: 'classes/BrevoConversationsControllerTest.cls-meta.xml', dest: 'classes/BrevoConversationsControllerTest.cls-meta.xml' },
  { src: 'classes/BrevoLeadTriggerHandler.cls', dest: 'classes/BrevoLeadTriggerHandler.cls' },
  { src: 'classes/BrevoLeadTriggerHandler.cls-meta.xml', dest: 'classes/BrevoLeadTriggerHandler.cls-meta.xml' },
  { src: 'classes/BrevoLeadTriggerHandlerTest.cls', dest: 'classes/BrevoLeadTriggerHandlerTest.cls' },
  { src: 'classes/BrevoLeadTriggerHandlerTest.cls-meta.xml', dest: 'classes/BrevoLeadTriggerHandlerTest.cls-meta.xml' },
  { src: 'classes/BrevoWebhookHandler.cls', dest: 'classes/BrevoWebhookHandler.cls' },
  { src: 'classes/BrevoWebhookHandler.cls-meta.xml', dest: 'classes/BrevoWebhookHandler.cls-meta.xml' },
  { src: 'classes/BrevoWebhookHandlerTest.cls', dest: 'classes/BrevoWebhookHandlerTest.cls' },
  { src: 'classes/BrevoWebhookHandlerTest.cls-meta.xml', dest: 'classes/BrevoWebhookHandlerTest.cls-meta.xml' },
  { src: 'classes/BrevoMessageTriggerHandler.cls', dest: 'classes/BrevoMessageTriggerHandler.cls' },
  { src: 'classes/BrevoMessageTriggerHandler.cls-meta.xml', dest: 'classes/BrevoMessageTriggerHandler.cls-meta.xml' },
  { src: 'classes/BrevoMessageTriggerHandlerTest.cls', dest: 'classes/BrevoMessageTriggerHandlerTest.cls' },
  { src: 'classes/BrevoMessageTriggerHandlerTest.cls-meta.xml', dest: 'classes/BrevoMessageTriggerHandlerTest.cls-meta.xml' },
];

// ZIP 3: LWC + Triggers
const zip3Files = [
  { src: 'package.xml', dest: 'package.xml' },
  { src: 'lwc/brevoInbox/brevoInbox.html', dest: 'lwc/brevoInbox/brevoInbox.html' },
  { src: 'lwc/brevoInbox/brevoInbox.js', dest: 'lwc/brevoInbox/brevoInbox.js' },
  { src: 'lwc/brevoInbox/brevoInbox.css', dest: 'lwc/brevoInbox/brevoInbox.css' },
  { src: 'lwc/brevoInbox/brevoInbox.js-meta.xml', dest: 'lwc/brevoInbox/brevoInbox.js-meta.xml' },
  { src: 'lwc/brevoRecordChat/brevoRecordChat.html', dest: 'lwc/brevoRecordChat/brevoRecordChat.html' },
  { src: 'lwc/brevoRecordChat/brevoRecordChat.js', dest: 'lwc/brevoRecordChat/brevoRecordChat.js' },
  { src: 'lwc/brevoRecordChat/brevoRecordChat.css', dest: 'lwc/brevoRecordChat/brevoRecordChat.css' },
  { src: 'lwc/brevoRecordChat/brevoRecordChat.js-meta.xml', dest: 'lwc/brevoRecordChat/brevoRecordChat.js-meta.xml' },
  { src: 'triggers/BrevoLeadTrigger.trigger', dest: 'triggers/BrevoLeadTrigger.trigger' },
  { src: 'triggers/BrevoLeadTrigger.trigger-meta.xml', dest: 'triggers/BrevoLeadTrigger.trigger-meta.xml' },
  { src: 'triggers/BrevoMessageTrigger.trigger', dest: 'triggers/BrevoMessageTrigger.trigger' },
  { src: 'triggers/BrevoMessageTrigger.trigger-meta.xml', dest: 'triggers/BrevoMessageTrigger.trigger-meta.xml' },
];

async function main() {
  console.log('Generating ZIPs...');
  
  await createZip(join(publicDir, 'brevo-apex-classes.zip'), zip2Files);
  console.log('Created: brevo-apex-classes.zip');
  
  await createZip(join(publicDir, 'brevo-lwc-triggers.zip'), zip3Files);
  console.log('Created: brevo-lwc-triggers.zip');
  
  console.log('Done! ZIPs are in /public folder');
}

main().catch(console.error);
