import { execSync } from "child_process";
import { mkdirSync } from "fs";

// Find actual working dir
const cwd = execSync("pwd").toString().trim();
console.log("CWD:", cwd);

// List directory to debug
console.log("Files in cwd:", execSync("ls -la").toString());
console.log("Salesforce exists:", execSync("ls -la salesforce/ 2>&1 || echo 'NOT FOUND'").toString());
