"use client"

import { useState } from "react"
import { CheckCircle2, Circle, ChevronDown, ChevronRight, Copy, Check, ExternalLink } from "lucide-react"

interface Step {
  id: string
  title: string
  description: string
  details: string[]
  command?: string
  link?: { url: string; label: string }
  substeps?: string[]
}

const STEPS: { section: string; steps: Step[] }[] = [
  {
    section: "1. Configuracion en Brevo",
    steps: [
      {
        id: "brevo-api-key",
        title: "Obtener API Key de Brevo",
        description:
          "Genera una API Key con permisos de Conversations en tu cuenta de Brevo.",
        details: [
          "Ir a Brevo Dashboard > Settings > API Keys",
          "Click en 'Generate a new API key'",
          "Nombre: 'Salesforce Integration'",
          "Copiar la clave generada (solo se muestra una vez)",
        ],
        link: {
          url: "https://app.brevo.com/settings/keys/api",
          label: "Abrir Brevo API Keys",
        },
      },
      {
        id: "brevo-webhook",
        title: "Configurar Webhooks en Brevo Conversations",
        description:
          "Apuntar los webhooks de Brevo Conversations al middleware bridge desplegado en Vercel.",
        details: [
          "IMPORTANTE: Los webhooks de Conversations NO estan en Settings > SMTP y API.",
          "Estan en la app de Conversations:",
          "",
          "1. Ir a https://conversations-app.brevo.com",
          "2. Click en el icono de engranaje (Settings) abajo a la izquierda",
          "3. Ve a la seccion 'Integrations'",
          "4. Busca 'Webhooks' y activa la integracion",
          "5. Pega la URL: https://TU-DOMINIO.vercel.app/api/brevo-webhook",
          "",
          "Eventos que se dispararan automaticamente:",
          "  - conversationStarted (nueva conversacion)",
          "  - conversationFragment (cada mensaje nuevo)",
          "  - conversationTranscript (conversacion finalizada)",
        ],
        link: {
          url: "https://conversations-app.brevo.com",
          label: "Abrir Brevo Conversations",
        },
      },
    ],
  },
  {
    section: "2. Configuracion en Salesforce",
    steps: [
      {
        id: "sf-fields",
        title: "Desplegar campos personalizados",
        description:
          "Crear los campos Brevo en Lead y Contact usando SFDX CLI.",
        details: [
          "Desde la carpeta /salesforce del proyecto:",
          "Esto crea los 6 campos en Lead y 6 en Contact,",
          "el Platform Event, las clases Apex y los 2 LWC.",
        ],
        command:
          "sf project deploy start --source-dir force-app -o TU_ORG_ALIAS",
      },
      {
        id: "sf-named-cred",
        title: "Configurar Named Credential",
        description:
          "Configurar la API Key de Brevo como Named Credential en Salesforce.",
        details: [
          "Setup > Named Credentials > External Credentials > New",
          "  Label: Brevo_API_External",
          "  Authentication Protocol: Custom",
          "  Principals > New Principal:",
          "    Nombre: Brevo_API_Principal",
          "    Custom Headers:",
          "      Header Name: api-key",
          "      Header Value: {{TU_API_KEY_DE_BREVO}}",
          "",
          "Setup > Named Credentials > New Named Credential",
          "  Label: Brevo_API",
          "  URL: https://api.brevo.com/v3",
          "  External Credential: Brevo_API_External",
          "  Generar Authorization Header: NO",
        ],
      },
      {
        id: "sf-connected-app",
        title: "Crear Connected App (OAuth para el Bridge)",
        description:
          "Permite al webhook bridge autenticarse en Salesforce via OAuth.",
        details: [
          "Setup > App Manager > New Connected App",
          "  Name: Brevo Webhook Bridge",
          "  Enable OAuth Settings: SI",
          "  Callback URL: https://login.salesforce.com/services/oauth2/callback",
          "  Selected OAuth Scopes:",
          "    - Full access (full)",
          "    - Perform requests at any time (refresh_token, offline_access)",
          "  Require Proof Key: NO",
          "",
          "Despues de crear, copiar Consumer Key y Consumer Secret.",
          "Estas seran las variables SF_CLIENT_ID y SF_CLIENT_SECRET.",
        ],
      },
      {
        id: "sf-permission-set",
        title: "Crear Permission Set para Named Credential",
        description:
          "Asignar acceso a la Named Credential a los usuarios que usaran los LWC.",
        details: [
          "Setup > Permission Sets > New",
          "  Label: Brevo Conversations User",
          "  Asignar:",
          "    - External Credential Principal Access: Brevo_API_Principal",
          "    - Apex Class Access: BrevoConversationsController, BrevoFieldUpdater",
          "    - Custom Field Permissions: todos los campos Brevo_* en Lead y Contact",
          "",
          "Asignar el Permission Set a los usuarios que necesiten acceso.",
        ],
      },
    ],
  },
  {
    section: "3. Configuracion del Webhook Bridge (Vercel)",
    steps: [
      {
        id: "vercel-env",
        title: "Configurar variables de entorno en Vercel",
        description:
          "Estas variables permiten al bridge autenticarse contra Salesforce.",
        details: [
          "En Vercel Project Settings > Environment Variables, configurar:",
          "",
          "SF_LOGIN_URL = https://login.salesforce.com",
          "  (o https://test.salesforce.com para sandbox)",
          "",
          "SF_CLIENT_ID = Consumer Key de la Connected App",
          "",
          "SF_CLIENT_SECRET = Consumer Secret de la Connected App",
          "",
          "SF_USERNAME = usuario.integracion@tuempresa.com",
          "  (usuario dedicado para la integracion)",
          "",
          "SF_PASSWORD = password + security_token",
          "  (concatenar password y token sin espacios)",
          "",
          "BREVO_WEBHOOK_SECRET = (opcional) secret compartido con Brevo",
        ],
      },
      {
        id: "vercel-deploy",
        title: "Desplegar el bridge en Vercel",
        description: "Publicar el proyecto para activar el endpoint del webhook.",
        details: [
          "Desde v0, hacer click en 'Publish' para desplegar.",
          "El endpoint quedara disponible en:",
          "  https://TU-DOMINIO.vercel.app/api/brevo-webhook",
          "",
          "Verificar con GET:",
          "  curl https://TU-DOMINIO.vercel.app/api/brevo-webhook",
          "  Debe responder: { status: 'ok', service: '...' }",
        ],
      },
    ],
  },
  {
    section: "4. Activar LWC en Salesforce",
    steps: [
      {
        id: "lwc-inbox",
        title: "Inbox Global - App Page o Tab",
        description:
          "Colocar el brevoInbox LWC en una App Page para acceso global.",
        details: [
          "Setup > Lightning App Builder > New > App Page",
          "  Nombre: Brevo Conversations",
          "  Layout: Full Width (una columna)",
          "  Arrastrar componente: 'Brevo Inbox Global'",
          "  Guardar y Activar",
          "",
          "Opcion alternativa: Utility Bar",
          "  Setup > App Manager > Edit tu app > Utility Items",
          "  Add Utility Item > seleccionar 'Brevo Inbox Global'",
          "  Panel Width: 600, Panel Height: 480",
        ],
      },
      {
        id: "lwc-record",
        title: "Record Chat - Ficha Lead y Contact (con Email/WhatsApp/SMS)",
        description:
          "Colocar el brevoRecordChat LWC en los page layouts de Lead y Contact.",
        details: [
          "Setup > Object Manager > Lead > Lightning Record Pages",
          "  Editar la pagina activa",
          "  Arrastrar 'Brevo Record Chat' a la columna derecha",
          "  Guardar y Activar (asignar como default)",
          "",
          "Repetir para Contact:",
          "  Setup > Object Manager > Contact > Lightning Record Pages",
          "  Mismo proceso: arrastrar y activar",
        ],
      },
    ],
  },
  {
    section: "5. Configurar Email, WhatsApp y SMS (Fase 4)",
    steps: [
      {
        id: "sender-email",
        title: "Configurar remitente de Email transaccional",
        description:
          "Definir el nombre y email del remitente en Brevo Settings.",
        details: [
          "1. Verificar un email de remitente en Brevo:",
          "   Brevo > Settings > Senders, Domains & Dedicated IPs > Senders",
          "   Anadir y verificar el email que usaras como remitente",
          "",
          "2. Configurar en Salesforce:",
          "   Setup > Custom Settings > Brevo Settings > Manage",
          "   Click en 'New' o 'Edit' en el Default Organization Level Value",
          "   Rellenar:",
          "     Sender_Name__c = Nombre de tu empresa",
          "     Sender_Email__c = email verificado en Brevo",
        ],
        link: {
          url: "https://app.brevo.com/senders/list",
          label: "Gestionar remitentes en Brevo",
        },
      },
      {
        id: "sender-sms",
        title: "Configurar remitente SMS",
        description:
          "Definir el nombre alfanumerico del remitente SMS (max 11 caracteres).",
        details: [
          "Setup > Custom Settings > Brevo Settings > Manage",
          "Click en 'Edit' en el Default Organization Level Value",
          "Rellenar:",
          "  SMS_Sender__c = Nombre corto (ej: MiEmpresa)",
          "",
          "NOTA: El nombre SMS debe tener maximo 11 caracteres alfanumericos.",
          "En algunos paises se requiere registro previo del sender ID.",
        ],
      },
      {
        id: "whatsapp-templates",
        title: "Crear templates de WhatsApp en Brevo",
        description:
          "Los mensajes de WhatsApp solo se pueden iniciar con templates pre-aprobados.",
        details: [
          "1. Ir a Brevo > WhatsApp > Templates",
          "2. Crear un nuevo template con el contenido deseado",
          "3. Enviar para aprobacion de Meta/WhatsApp",
          "4. Una vez aprobado, aparecera en el selector del LWC",
          "",
          "IMPORTANTE: No se puede enviar texto libre como primer mensaje.",
          "WhatsApp requiere que el primer contacto sea via template aprobado.",
          "Si el destinatario responde dentro de 24h, se abre ventana de texto libre.",
        ],
        link: {
          url: "https://app.brevo.com/whatsapp/templates",
          label: "Gestionar templates de WhatsApp",
        },
      },
      {
        id: "brevo-crm-icon",
        title: "Icono de verificacion CRM Brevo (solo lectura)",
        description:
          "El LWC muestra automaticamente si el contacto existe en el CRM de Brevo.",
        details: [
          "No requiere configuracion adicional.",
          "El icono verde (check) aparece si el email del registro existe como contacto en Brevo CRM.",
          "El icono gris (X) aparece si no existe.",
          "",
          "Se verifica via GET /v3/contacts/{email} de la API de Brevo.",
          "Usa la misma API Key ya configurada en Brevo_Settings__c.",
        ],
      },
    ],
  },

  {
    section: "6. Conversaciones persistidas (Fase 6a + 6b)",
    steps: [
      {
        id: "diag-deploy-6a",
        title: "Paso 1: Desplegar Fase 6a (Solo objetos custom)",
        description:
          "Crea los objetos Brevo_Conversation__c y Brevo_Message__c en tu org. DEBE desplegarse ANTES que el codigo.",
        details: [
          "1. Descarga el ZIP de Fase 6a (solo objetos custom).",
          "2. Despliega via Workbench con 'Allow Missing Files' activado.",
          "   Test Level: NoTestRun (no hay Apex en este deploy).",
          "3. Incluye:",
          "   - Brevo_Conversation__c (13 campos: Id, VisitorId, Name, Email, Phone, Source, Status, etc.)",
          "   - Brevo_Message__c (8 campos: MessageId, SenderType, Text, CreatedAt, File, etc.)",
          "",
          "4. Despues del deploy, configura permisos del Guest User del Site:",
          "   Setup > Sites > [tu site] > Public Access Settings > Object Settings",
          "   - Brevo_Conversation__c: Read, Create, Edit (todos los campos)",
          "   - Brevo_Message__c: Read, Create, Edit (todos los campos)",
        ],
      },
      {
        id: "diag-deploy-6b",
        title: "Paso 2: Desplegar Fase 6b (Apex + LWC)",
        description:
          "Actualiza todas las clases Apex y LWC para usar los nuevos objetos. Desplegar DESPUES de que 6a este completado.",
        details: [
          "1. Descarga el ZIP de Fase 6b (Apex + LWC).",
          "2. Despliega via Workbench con Test Level: RunSpecifiedTests.",
          "   Run Tests: BrevoConversationsControllerTest,BrevoWebhookHandlerTest,BrevoFieldUpdaterTest",
          "3. Incluye:",
          "   - BrevoWebhookHandler: crea/upsert conversaciones y mensajes en tiempo real",
          "   - BrevoConversationsController: getConversations, getConversationMessages,",
          "     getConversationsForRecord, linkConversationToRecord, markConversationAsRead",
          "   - brevoInbox LWC: chat real, filtros, busqueda, vinculacion manual",
          "   - brevoRecordChat LWC: conversaciones por Lead/Contact",
        ],
      },
      {
        id: "diag-verify-site",
        title: "Verificar que el Site funciona",
        description:
          "Abrir el endpoint GET del webhook en el navegador para confirmar que el Site esta activo.",
        details: [
          "Abre en el navegador:",
          "  https://tudominio.my.salesforce-sites.com/services/apexrest/brevo/webhook",
          "",
          "Debe responder un JSON como:",
          '  {"status":"ok","message":"Brevo webhook endpoint is active...","leadsWithBrevoActivity":0,...}',
          "",
          "Si da error 404 o acceso denegado:",
          "  1. Verifica que el Site esta activo (Setup > Sites)",
          "  2. Verifica que BrevoWebhookHandler esta en Apex Class Access del Guest User",
          "  3. Verifica que el Guest User tiene permisos en los campos Brevo_* de Lead y Contact",
        ],
      },
      {
        id: "diag-test-search",
        title: "Diagnosticar busqueda de registros",
        description:
          "Usar el boton de diagnostico en el Inbox para verificar si un telefono/email encuentra registros.",
        details: [
          "1. Abre la pagina del Brevo Inbox en Salesforce",
          "2. Click en el icono de bug (arriba a la derecha)",
          "3. Introduce el telefono exacto que envia Brevo (ej: +34620702502) o el email",
          "4. Click en 'Ejecutar Diagnostico'",
          "5. El resultado mostrara si se encontro algun Lead o Contact",
          "",
          "Si NO encuentra nada, verifica:",
          "  - El formato del telefono en el Lead/Contact de SF",
          "  - Que el telefono tenga el prefijo internacional (+34...)",
          "  - Que el email sea exacto (mayusculas/minusculas)",
        ],
      },
    ],
  },
  {
    section: "7. Agrupacion persona+canal (Fase 7a + 7b)",
    steps: [
      {
        id: "diag-deploy-7a",
        title: "Paso 1: Desplegar Fase 7a (Objetos nuevos)",
        description:
          "Añade Brevo_Saved_Response__c y el campo Last_Visitor_Message_Date__c. Desplegar ANTES de 7b.",
        details: [
          "1. Descarga el ZIP de Fase 7a.",
          "2. Despliega via Workbench con Test Level: NoTestRun (solo objetos/campos).",
          "3. Incluye:",
          "   - Brevo_Saved_Response__c (respuestas guardadas)",
          "   - Last_Visitor_Message_Date__c en Brevo_Conversation__c",
        ],
        substeps: [],
      },
      {
        id: "diag-deploy-7b",
        title: "Paso 2: Desplegar Fase 7b (Apex + LWC con agrupacion)",
        description:
          "Actualiza Apex y LWC para agrupar conversaciones por persona+canal, alerta cross-channel, cerrar grupo y auto-resolve. Desplegar DESPUES de 7a.",
        details: [
          "1. Descarga el ZIP de Fase 7b (Apex + LWC).",
          "2. Despliega via Workbench con Test Level: RunSpecifiedTests.",
          "   Run Tests: BrevoConversationsControllerTest,BrevoWebhookHandlerTest,BrevoFieldUpdaterTest",
          "3. Incluye:",
          "   - BrevoConversationsController (agrupacion, getGroupedConversationMessages, closeConversation grupo, auto-resolve)",
          "   - BrevoWebhookHandler (reapertura conversacion cerrada, fallback Lead/Contact vinculado)",
          "   - BrevoFieldUpdater (retorno de IDs actualizados)",
          "   - brevoInbox (alerta cross-channel, cerrar grupo, emoji picker, respuestas guardadas, timer 24h)",
          "   - brevoRecordChat (agrupacion, cerrar grupo, timer 24h)",
          "",
          "Funcionalidades nuevas:",
          "  - Conversaciones agrupadas por persona+canal (un hilo por persona+whatsapp, otro por persona+email)",
          "  - Estado del grupo: Abierta > Resuelta > Cerrada (prioridad)",
          "  - Al enviar mensaje: auto-resolve (Abierta -> Resuelta)",
          "  - Boton Cerrar cierra TODAS las conversaciones del grupo",
          "  - Si la persona vuelve a escribir tras cerrar: se reabre automaticamente",
          "  - Alerta naranja si la persona escribio por otro canal (click navega a ese grupo)",
        ],
        substeps: [],
      },
    ],
  },
]

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false)

  const handleCopy = () => {
    navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <button
      onClick={handleCopy}
      className="flex items-center gap-1 rounded bg-secondary px-2 py-1 text-xs text-secondary-foreground transition-colors hover:bg-muted"
      aria-label="Copiar comando"
    >
      {copied ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
      {copied ? "Copiado" : "Copiar"}
    </button>
  )
}

export function SetupGuide() {
  const [completedSteps, setCompletedSteps] = useState<Set<string>>(new Set())
  const [expandedSteps, setExpandedSteps] = useState<Set<string>>(new Set())

  const toggleComplete = (id: string) => {
    setCompletedSteps((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  const toggleExpand = (id: string) => {
    setExpandedSteps((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  const totalSteps = STEPS.reduce((sum, s) => sum + (s.steps?.length || 0), 0)
  const completedCount = completedSteps.size
  const progressPercent = totalSteps > 0 ? (completedCount / totalSteps) * 100 : 0

  return (
    <div className="mx-auto max-w-4xl space-y-8">
      {/* Progress bar */}
      <div className="rounded-xl border border-border bg-card p-6">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-card-foreground">Progreso de configuracion</h2>
          <span className="text-sm text-muted-foreground">
            {completedCount} / {totalSteps} pasos
          </span>
        </div>
        <div className="mt-3 h-2 overflow-hidden rounded-full bg-muted">
          <div
            className="h-full rounded-full bg-primary transition-all duration-500"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>

      {/* Sections */}
      {STEPS.map((section) => (
        <div key={section.section} className="space-y-3">
          <h3 className="text-base font-semibold text-foreground">
            {section.section}
          </h3>

          <div className="space-y-2">
            {section.steps.map((step) => {
              const isComplete = completedSteps.has(step.id)
              const isExpanded = expandedSteps.has(step.id)

              return (
                <div
                  key={step.id}
                  className="overflow-hidden rounded-lg border border-border bg-card"
                >
                  <div className="flex items-start gap-3 p-4">
                    <button
                      onClick={() => toggleComplete(step.id)}
                      className="mt-0.5 shrink-0"
                      aria-label={
                        isComplete
                          ? "Marcar como pendiente"
                          : "Marcar como completado"
                      }
                    >
                      {isComplete ? (
                        <CheckCircle2 className="h-5 w-5 text-accent" />
                      ) : (
                        <Circle className="h-5 w-5 text-muted-foreground" />
                      )}
                    </button>

                    <div className="min-w-0 flex-1">
                      <button
                        onClick={() => toggleExpand(step.id)}
                        className="flex w-full items-center gap-2 text-left"
                      >
                        {isExpanded ? (
                          <ChevronDown className="h-4 w-4 shrink-0 text-muted-foreground" />
                        ) : (
                          <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" />
                        )}
                        <div>
                          <p
                            className={`font-medium ${isComplete ? "text-muted-foreground line-through" : "text-card-foreground"}`}
                          >
                            {step.title}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            {step.description}
                          </p>
                        </div>
                      </button>

                      {isExpanded && (
                        <div className="mt-3 space-y-3 pl-6">
                          <ul className="space-y-1 text-sm text-muted-foreground">
                            {step.details.map((detail, i) => (
                              <li
                                key={i}
                                className={
                                  detail.startsWith("  ")
                                    ? "pl-4 font-mono text-xs"
                                    : detail === ""
                                      ? "h-2"
                                      : ""
                                }
                              >
                                {detail}
                              </li>
                            ))}
                          </ul>

                          {step.command && (
                            <div className="flex items-center gap-2 rounded-lg bg-sidebar p-3 font-mono text-xs text-sidebar-foreground">
                              <code className="flex-1 break-all">
                                {step.command}
                              </code>
                              <CopyButton text={step.command} />
                            </div>
                          )}

                          {step.link && (
                            <a
                              href={step.link.url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center gap-1 text-sm text-primary hover:underline"
                            >
                              <ExternalLink className="h-3 w-3" />
                              {step.link.label}
                            </a>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      ))}

      {/* Deploy packages download */}
      <div className="rounded-xl border border-border bg-card p-6">
        <h3 className="mb-4 text-base font-semibold text-card-foreground">
          Paquetes de despliegue (Workbench)
        </h3>
        <p className="mb-4 text-sm text-muted-foreground">
          Descarga cada fase como ZIP y despliega via Workbench (Metadata Deploy). Desplegar en orden.
        </p>
        <div className="grid gap-3 sm:grid-cols-2">
          {[
            { phase: "1", label: "Fase 1: Campos + Platform Event", desc: "Campos Brevo en Lead/Contact, Named Credential, Remote Site" },
            { phase: "2", label: "Fase 2: Apex + LWC", desc: "Controller, FieldUpdater, brevoInbox, brevoRecordChat" },
            { phase: "3", label: "Fase 3: API Key Custom Setting", desc: "Brevo_Settings__c con API_Key__c" },
            { phase: "4", label: "Fase 4: Email / WhatsApp / SMS", desc: "Envio transaccional, selector templates WA, verificacion CRM, campos sender" },
  { phase: "5", label: "Fase 5: Webhook (Brevo -> SF)", desc: "REST endpoint que recibe eventos de Brevo y actualiza Lead/Contact automaticamente" },
  { phase: "6", label: "Fase 6: Conversaciones persistidas (PRODUCCION)", desc: "Objetos Brevo_Conversation__c + Brevo_Message__c + todo Apex + LWCs. Deploy unico con RunSpecifiedTests." },
  { phase: "6a", label: "Fase 6a: Solo objetos custom (sandbox)", desc: "Solo Brevo_Conversation__c y Brevo_Message__c. Para deploys separados en sandbox." },
          { phase: "6b", label: "Fase 6b: Solo Apex + LWC (sandbox)", desc: "Controller, WebhookHandler, FieldUpdater, Inbox y RecordChat. Desplegar DESPUES de 6a." },
          { phase: "7a", label: "Fase 7a: Objetos + campos nuevos", desc: "Brevo_Saved_Response__c + Last_Visitor_Message_Date__c. Desplegar ANTES de 7b." },
          { phase: "7b", label: "Fase 7b: Mejoras Inbox agrupado", desc: "Agrupacion persona+canal, cross-channel alerts, cerrar grupo, auto-resolve. Desplegar DESPUES de 7a." },
  ].map((p) => (
            <a
              key={p.phase}
              href={`/api/download-workbench-zip?phase=${p.phase}`}
              className="flex flex-col gap-1 rounded-lg border border-border p-4 transition-colors hover:bg-muted"
            >
              <span className="text-sm font-semibold text-card-foreground">{p.label}</span>
              <span className="text-xs text-muted-foreground">{p.desc}</span>
            </a>
          ))}
        </div>
      </div>

      {/* Architecture diagram */}
      <div className="rounded-xl border border-border bg-card p-6">
        <h3 className="mb-4 text-base font-semibold text-card-foreground">
          Diagrama de arquitectura
        </h3>
        <div className="overflow-x-auto rounded-lg bg-sidebar p-6 font-mono text-xs leading-relaxed text-sidebar-foreground">
          <pre>{`
  CLIENTE                     BREVO                      VERCEL                    SALESFORCE
  -------                     -----                      ------                    ----------

  WhatsApp  ──┐
  Email     ──┤
  Instagram ──┼──>  Brevo     ──── Webhook POST ────>  /api/brevo-webhook  ──── OAuth 2.0 ────>  Platform Event
  Web Chat  ──┘     Conversations                      (Bridge)                                   |
                                                         |                                        v
                         <── API Response ────────────   |                              Brevo_Message_Event__e
                                                         |                                        |
                                                         └── PATCH Lead/Contact ──────>  Actualiza campos:
                                                                                         Brevo_Sin_Leer__c
                                                                                         Brevo_Conv_Abiertas__c
                                                                                         Brevo_Ultima_Comunicacion__c
                                                                                         Brevo_Estado__c


  SALESFORCE LWC (Inbox Global)                         SALESFORCE LWC (Record Chat)
  ──────────────────────────────                        ────────────────────────────
  brevoInbox                                            brevoRecordChat
    |                                                     |
    ├── Apex: getConversations() ──── Named Cred ──>     ├── Wire: getRecord(email)
    ├── Apex: getMessages()                               ├── Apex: getConversationsByEmail()
    ├── Apex: sendMessage()    ──── api-key header ──>   ├── Apex: sendMessage()
    └── empApi: subscribe      <── Platform Event ──     └── empApi: subscribe (filtered)
          `}</pre>
        </div>
      </div>

      {/* Environment variables summary */}
      <div className="rounded-xl border border-border bg-card p-6">
        <h3 className="mb-4 text-base font-semibold text-card-foreground">
          Variables de entorno requeridas (Vercel)
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border text-left">
                <th className="pb-2 pr-4 font-medium text-muted-foreground">Variable</th>
                <th className="pb-2 pr-4 font-medium text-muted-foreground">Origen</th>
                <th className="pb-2 font-medium text-muted-foreground">Descripcion</th>
              </tr>
            </thead>
            <tbody className="text-card-foreground">
              {[
                ["SF_LOGIN_URL", "Salesforce", "https://login.salesforce.com o test.salesforce.com"],
                ["SF_CLIENT_ID", "Connected App", "Consumer Key de la Connected App"],
                ["SF_CLIENT_SECRET", "Connected App", "Consumer Secret de la Connected App"],
                ["SF_USERNAME", "Salesforce", "Usuario de integracion dedicado"],
                ["SF_PASSWORD", "Salesforce", "Password + Security Token concatenados"],
                ["BREVO_WEBHOOK_SECRET", "Brevo", "(Opcional) Secret para validar webhooks"],
              ].map(([variable, origen, desc]) => (
                <tr key={variable} className="border-b border-border/50">
                  <td className="py-2 pr-4 font-mono text-xs">{variable}</td>
                  <td className="py-2 pr-4">{origen}</td>
                  <td className="py-2 text-muted-foreground">{desc}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
