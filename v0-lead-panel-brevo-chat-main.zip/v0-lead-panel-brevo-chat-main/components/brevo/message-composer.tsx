"use client"

import { useState, useRef, useEffect } from "react"
import { Send, Paperclip, ImageIcon } from "lucide-react"
import { type Channel, getChannelLabel } from "@/lib/brevo-data"
import { cn } from "@/lib/utils"

export function MessageComposer({
  channel,
  onSend,
  disabled = false,
}: {
  channel: Channel
  onSend: (text: string) => void
  disabled?: boolean
}) {
  const [text, setText] = useState("")
  const textareaRef = useRef<HTMLTextAreaElement>(null)

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto"
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 120)}px`
    }
  }, [text])

  function handleSubmit() {
    const trimmed = text.trim()
    if (!trimmed || disabled) return
    onSend(trimmed)
    setText("")
  }

  function handleKeyDown(e: React.KeyboardEvent) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSubmit()
    }
  }

  return (
    <div className="border-t border-border bg-card p-3">
      <div className="mb-2 flex items-center gap-1.5">
        <span className="text-[11px] text-muted-foreground">
          Respondiendo via{" "}
          <span className="font-medium text-foreground">
            {getChannelLabel(channel)}
          </span>
        </span>
      </div>
      <div className="flex items-end gap-2">
        <div className="flex gap-1">
          <button
            className="rounded-md p-2 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
            aria-label="Adjuntar archivo"
          >
            <Paperclip size={16} />
          </button>
          <button
            className="rounded-md p-2 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
            aria-label="Adjuntar imagen"
          >
            <ImageIcon size={16} />
          </button>
        </div>
        <textarea
          ref={textareaRef}
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Escribe tu respuesta..."
          disabled={disabled}
          rows={1}
          className={cn(
            "flex-1 resize-none rounded-lg border border-border bg-background px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary",
            disabled && "cursor-not-allowed opacity-50"
          )}
        />
        <button
          onClick={handleSubmit}
          disabled={!text.trim() || disabled}
          className={cn(
            "flex h-9 w-9 items-center justify-center rounded-lg transition-colors",
            text.trim()
              ? "bg-primary text-primary-foreground hover:bg-primary/90"
              : "bg-muted text-muted-foreground"
          )}
          aria-label="Enviar mensaje"
        >
          <Send size={16} />
        </button>
      </div>
    </div>
  )
}
