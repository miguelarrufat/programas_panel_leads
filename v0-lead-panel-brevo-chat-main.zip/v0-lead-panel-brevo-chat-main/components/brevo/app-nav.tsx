"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { MessageSquare } from "lucide-react"

export function AppNav() {
  const pathname = usePathname()
  const isRecordPage = pathname.startsWith("/leads/") || pathname.startsWith("/contacts/")

  return (
    <nav className="flex h-12 items-center gap-3 border-b border-border bg-sidebar px-4">
      <Link href="/" className="flex items-center gap-2.5">
        <div className="flex h-7 w-7 items-center justify-center rounded-md bg-sidebar-primary">
          <MessageSquare size={14} className="text-sidebar-primary-foreground" />
        </div>
        <span className="text-sm font-bold text-sidebar-foreground">
          Brevo{" "}
          <span className="font-normal opacity-70">Conversations</span>
        </span>
      </Link>

      {isRecordPage && (
        <>
          <span className="text-sidebar-foreground/30">/</span>
          <span className="text-xs text-sidebar-foreground/70">
            {pathname.startsWith("/leads/") ? "Ficha Lead" : "Ficha Contact"}
          </span>
        </>
      )}
    </nav>
  )
}
