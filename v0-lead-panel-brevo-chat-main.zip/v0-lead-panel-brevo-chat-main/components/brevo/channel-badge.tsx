import { type Channel, getChannelLabel } from "@/lib/brevo-data"
import { MessageCircle, Mail, Camera, Globe } from "lucide-react"
import { cn } from "@/lib/utils"

const channelConfig: Record<
  Channel,
  { icon: typeof MessageCircle; colorClass: string }
> = {
  whatsapp: { icon: MessageCircle, colorClass: "bg-channel-whatsapp/15 text-channel-whatsapp" },
  email: { icon: Mail, colorClass: "bg-channel-email/15 text-channel-email" },
  instagram: { icon: Camera, colorClass: "bg-channel-instagram/15 text-channel-instagram" },
  webchat: { icon: Globe, colorClass: "bg-channel-webchat/15 text-channel-webchat" },
}

export function ChannelBadge({
  channel,
  showLabel = true,
  size = "sm",
}: {
  channel: Channel
  showLabel?: boolean
  size?: "sm" | "md"
}) {
  const config = channelConfig[channel]
  const Icon = config.icon
  const iconSize = size === "sm" ? 14 : 16

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full font-medium",
        config.colorClass,
        size === "sm" ? "px-2 py-0.5 text-xs" : "px-2.5 py-1 text-sm"
      )}
    >
      <Icon size={iconSize} />
      {showLabel && getChannelLabel(channel)}
    </span>
  )
}
