"use client"

import { type Conversation, type Channel, type ConversationStatus, formatTime } from "@/lib/brevo-data"
import { ChannelBadge } from "./channel-badge"
import { StatusBadge } from "./status-badge"
import { cn } from "@/lib/utils"
import { Search, Filter, Building2 } from "lucide-react"
import { useState, useMemo } from "react"

// School options for the filter
const schoolOptions = [
  { value: "all", label: "Todos los colegios" },
  { value: "Los Pinos", label: "Los Pinos" },
  { value: "San Jose", label: "San Jose" },
  { value: "Academia Central", label: "Academia Central" },
  { value: "Instituto Norte", label: "Instituto Norte" },
  { value: "Colegio del Valle", label: "Colegio del Valle" },
]

export function ConversationList({
  conversations,
  selectedId,
  onSelect,
  title = "Conversaciones",
  compact = false,
}: {
  conversations: Conversation[]
  selectedId: string | null
  onSelect: (conv: Conversation) => void
  title?: string
  compact?: boolean
}) {
  const [search, setSearch] = useState("")
  const [channelFilter, setChannelFilter] = useState<Channel | "all">("all")
  const [statusFilter, setStatusFilter] = useState<ConversationStatus | "all">("all")
  const [schoolFilter, setSchoolFilter] = useState<string>("all")
  const [showFilters, setShowFilters] = useState(false)

  const filtered = useMemo(() => {
    return conversations
      .filter((c) => {
        if (channelFilter !== "all" && c.channel !== channelFilter) return false
        if (statusFilter !== "all" && c.status !== statusFilter) return false
        if (search) {
          const q = search.toLowerCase()
          return (
            c.visitorName.toLowerCase().includes(q) ||
            c.lastMessage.toLowerCase().includes(q) ||
            c.visitorEmail.toLowerCase().includes(q)
          )
        }
        return true
      })
      .sort(
        (a, b) =>
          new Date(b.lastMessageTime).getTime() -
          new Date(a.lastMessageTime).getTime()
      )
  }, [conversations, search, channelFilter, statusFilter])

  return (
    <div className="flex h-full flex-col bg-card">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-border px-4 py-3">
        <h2 className="text-sm font-semibold text-foreground">{title}</h2>
        <button
          onClick={() => setShowFilters(!showFilters)}
          className={cn(
            "rounded-md p-1.5 transition-colors hover:bg-muted",
            showFilters && "bg-primary/10 text-primary"
          )}
          aria-label="Filtros"
        >
          <Filter size={16} />
        </button>
      </div>

      {/* Search */}
      <div className="border-b border-border px-3 py-2">
        <div className="flex items-center gap-2 rounded-md bg-muted px-3 py-1.5">
          <Search size={14} className="text-muted-foreground" />
          <input
            type="text"
            placeholder="Buscar conversaciones..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-transparent text-sm text-foreground placeholder:text-muted-foreground focus:outline-none"
          />
        </div>
      </div>

      {/* Filters */}
      {showFilters && (
        <div className="flex flex-wrap gap-2 border-b border-border px-3 py-2">
          <select
            value={channelFilter}
            onChange={(e) => setChannelFilter(e.target.value as Channel | "all")}
            className="rounded-md border border-border bg-card px-2 py-1 text-xs text-foreground"
          >
            <option value="all">Todos los canales</option>
            <option value="whatsapp">WhatsApp</option>
            <option value="email">Email</option>
            <option value="instagram">Instagram</option>
            <option value="webchat">Web Chat</option>
          </select>
          <select
            value={statusFilter}
            onChange={(e) =>
              setStatusFilter(e.target.value as ConversationStatus | "all")
            }
            className="rounded-md border border-border bg-card px-2 py-1 text-xs text-foreground"
          >
            <option value="all">Todos los estados</option>
            <option value="open">Abierta</option>
            <option value="pending">Pendiente</option>
            <option value="resolved">Resuelta</option>
          </select>
          <select
            value={schoolFilter}
            onChange={(e) => setSchoolFilter(e.target.value)}
            className="rounded-md border border-border bg-card px-2 py-1 text-xs text-foreground"
          >
            {schoolOptions.map((opt) => (
              <option key={opt.value} value={opt.value}>{opt.label}</option>
            ))}
          </select>
        </div>
      )}

      {/* List */}
      <div className="flex-1 overflow-y-auto">
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
            <Search size={32} className="mb-2 opacity-40" />
            <p className="text-sm">No se encontraron conversaciones</p>
          </div>
        ) : (
          filtered.map((conv) => (
            <button
              key={conv.id}
              onClick={() => onSelect(conv)}
              className={cn(
                "flex w-full flex-col gap-1.5 border-b border-border px-4 py-3 text-left transition-colors hover:bg-muted/60",
                selectedId === conv.id && "bg-primary/5 border-l-2 border-l-primary"
              )}
            >
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2 overflow-hidden">
                  {/* Avatar */}
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary/10 text-xs font-semibold text-primary">
                    {conv.visitorName
                      .split(" ")
                      .map((n) => n[0])
                      .join("")
                      .slice(0, 2)}
                  </div>
                  <div className="min-w-0">
                    <span className="block truncate text-sm font-medium text-foreground">
                      {conv.visitorName}
                    </span>
                    {!compact && (
                      <span className="block truncate text-xs text-muted-foreground">
                        {conv.visitorEmail}
                      </span>
                    )}
                  </div>
                </div>
                <div className="flex shrink-0 flex-col items-end gap-1">
                  <span className="text-[11px] text-muted-foreground">
                    {formatTime(conv.lastMessageTime)}
                  </span>
                  {conv.unreadCount > 0 && (
                    <span className="flex h-4.5 min-w-4.5 items-center justify-center rounded-full bg-primary px-1 text-[10px] font-bold text-primary-foreground">
                      {conv.unreadCount}
                    </span>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-2 pl-10">
                <ChannelBadge channel={conv.channel} showLabel={!compact} size="sm" />
                {!compact && <StatusBadge status={conv.status} />}
              </div>
              <p className="truncate pl-10 text-xs text-muted-foreground">
                {conv.lastMessage}
              </p>
            </button>
          ))
        )}
      </div>
    </div>
  )
}
