"use client"

import { useState, useCallback, type ReactNode } from "react"
import { type Conversation, type Message } from "@/lib/brevo-data"
import { ConversationList } from "./conversation-list"
import { ChatView } from "./chat-view"
import { cn } from "@/lib/utils"

export function InboxLayout({
  conversations: initialConversations,
  title = "Conversaciones",
  compact = false,
  headerSlot,
}: {
  conversations: Conversation[]
  title?: string
  compact?: boolean
  headerSlot?: ReactNode
}) {
  const [conversations, setConversations] = useState(initialConversations)
  const [selectedId, setSelectedId] = useState<string | null>(null)
  const [mobileShowChat, setMobileShowChat] = useState(false)

  const selectedConv = conversations.find((c) => c.id === selectedId) ?? null

  const handleSelect = useCallback((conv: Conversation) => {
    setSelectedId(conv.id)
    setMobileShowChat(true)
    // Mark as read
    setConversations((prev) =>
      prev.map((c) => (c.id === conv.id ? { ...c, unreadCount: 0 } : c))
    )
  }, [])

  const handleSend = useCallback(
    (conversationId: string, text: string) => {
      const newMsg: Message = {
        id: `msg-${Date.now()}`,
        conversationId,
        sender: "agent",
        text,
        timestamp: new Date().toISOString(),
        agentName: "Tu",
      }

      setConversations((prev) =>
        prev.map((c) =>
          c.id === conversationId
            ? {
                ...c,
                messages: [...c.messages, newMsg],
                lastMessage: text,
                lastMessageTime: newMsg.timestamp,
              }
            : c
        )
      )
    },
    []
  )

  const handleStatusChange = useCallback(
    (conversationId: string, status: Conversation["status"]) => {
      setConversations((prev) =>
        prev.map((c) => (c.id === conversationId ? { ...c, status } : c))
      )
    },
    []
  )

  const handleBack = useCallback(() => {
    setMobileShowChat(false)
  }, [])

  return (
    <div className="flex min-h-0 flex-1 flex-col overflow-hidden">
      {headerSlot}
      <div className="flex flex-1 overflow-hidden">
        {/* Conversation List */}
        <div
          className={cn(
            "w-full shrink-0 border-r border-border lg:w-[360px]",
            mobileShowChat ? "hidden lg:flex lg:flex-col" : "flex flex-col"
          )}
        >
          <ConversationList
            conversations={conversations}
            selectedId={selectedId}
            onSelect={handleSelect}
            title={title}
            compact={compact}
          />
        </div>

        {/* Chat View */}
        <div
          className={cn(
            "flex-1",
            !mobileShowChat ? "hidden lg:block" : "block"
          )}
        >
          <ChatView
            conversation={selectedConv}
            onSend={handleSend}
            onBack={handleBack}
            onStatusChange={handleStatusChange}
          />
        </div>
      </div>
    </div>
  )
}
