"use client"

import Link from "next/link"
import {
  type RecordSummary,
  type RecordType,
  formatDate,
} from "@/lib/brevo-data"
import { cn } from "@/lib/utils"
import {
  MessageSquare,
  Mail,
  Phone,
  Building2,
  ChevronRight,
  CircleAlert,
  CheckCircle2,
} from "lucide-react"

export function RecordsSummaryTable({
  records,
  type,
}: {
  records: RecordSummary[]
  type: RecordType
}) {
  const typeLabel = type === "lead" ? "Leads" : "Contacts"
  const basePath = type === "lead" ? "/leads" : "/contacts"

  return (
    <div className="rounded-xl border border-border bg-card">
      {/* Section header */}
      <div className="flex items-center justify-between border-b border-border px-4 py-3">
        <div className="flex items-center gap-2.5">
          <h3 className="text-sm font-semibold text-foreground">{typeLabel}</h3>
          <span className="rounded-full bg-muted px-2 py-0.5 text-[11px] font-medium text-muted-foreground">
            {records.length}
          </span>
        </div>
      </div>

      {/* Table header */}
      <div className="hidden border-b border-border bg-muted/50 px-4 py-2 lg:grid lg:grid-cols-12 lg:gap-3">
        <span className="col-span-3 text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
          Nombre
        </span>
        <span className="col-span-2 text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
          Estado Brevo
        </span>
        <span className="col-span-1 text-center text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
          Conv.
        </span>
        <span className="col-span-1 text-center text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
          Sin leer
        </span>
        <span className="col-span-1 text-center text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
          Abiertas
        </span>
        <span className="col-span-2 text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
          Ultima com.
        </span>
        <span className="col-span-2 text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
          Creada
        </span>
      </div>

      {/* Rows */}
      {records.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-8 text-muted-foreground">
          <MessageSquare size={24} className="mb-2 opacity-40" />
          <p className="text-sm">
            {"No hay " + typeLabel.toLowerCase() + " con conversaciones"}
          </p>
        </div>
      ) : (
        records.map((record) => (
          <Link
            key={record.recordId}
            href={`${basePath}/${record.recordId}`}
            className="group flex flex-col gap-2 border-b border-border px-4 py-3 transition-colors last:border-b-0 hover:bg-muted/40 lg:grid lg:grid-cols-12 lg:items-center lg:gap-3"
          >
            {/* Name + info */}
            <div className="col-span-3 flex items-center gap-2.5">
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary/10 text-xs font-semibold text-primary">
                {record.name
                  .split(" ")
                  .map((n) => n[0])
                  .join("")
                  .slice(0, 2)}
              </div>
              <div className="min-w-0">
                <p className="truncate text-sm font-medium text-foreground">
                  {record.name}
                </p>
                <div className="flex items-center gap-2 text-[11px] text-muted-foreground">
                  <span className="flex items-center gap-1 truncate">
                    <Mail size={10} />
                    {record.email}
                  </span>
                </div>
              </div>
            </div>

            {/* Status indicator */}
            <div className="col-span-2 flex items-center gap-2 pl-10 lg:pl-0">
              {record.hasUnread ? (
                <span className="flex items-center gap-1.5 rounded-full bg-destructive/10 px-2 py-0.5 text-[11px] font-medium text-destructive">
                  <CircleAlert size={12} />
                  Sin leer
                </span>
              ) : record.hasOpen ? (
                <span className="flex items-center gap-1.5 rounded-full bg-accent/10 px-2 py-0.5 text-[11px] font-medium text-accent">
                  <MessageSquare size={12} />
                  Abierta
                </span>
              ) : (
                <span className="flex items-center gap-1.5 rounded-full bg-muted px-2 py-0.5 text-[11px] font-medium text-muted-foreground">
                  <CheckCircle2 size={12} />
                  Sin pendientes
                </span>
              )}
            </div>

            {/* Stats - mobile */}
            <div className="flex flex-wrap items-center gap-3 pl-10 text-xs text-muted-foreground lg:hidden">
              <span className="flex items-center gap-1">
                <MessageSquare size={12} />
                {record.totalConversations} conv.
              </span>
              {record.unreadMessages > 0 && (
                <span className="flex h-4.5 min-w-4.5 items-center justify-center rounded-full bg-primary px-1 text-[10px] font-bold text-primary-foreground">
                  {record.unreadMessages}
                </span>
              )}
              <span>{record.openConversations} abiertas</span>
              {record.lastCommunicationDate && (
                <span>{formatDate(record.lastCommunicationDate)}</span>
              )}
            </div>

            {/* Stats - desktop */}
            <div className="col-span-1 hidden text-center lg:block">
              <span className="text-sm font-medium text-foreground">
                {record.totalConversations}
              </span>
            </div>
            <div className="col-span-1 hidden text-center lg:block">
              {record.unreadMessages > 0 ? (
                <span className="inline-flex h-5 min-w-5 items-center justify-center rounded-full bg-primary px-1.5 text-[11px] font-bold text-primary-foreground">
                  {record.unreadMessages}
                </span>
              ) : (
                <span className="text-sm text-muted-foreground">0</span>
              )}
            </div>
            <div className="col-span-1 hidden text-center lg:block">
              <span
                className={cn(
                  "text-sm font-medium",
                  record.openConversations > 0
                    ? "text-accent"
                    : "text-muted-foreground"
                )}
              >
                {record.openConversations}
              </span>
            </div>
            <div className="col-span-2 hidden lg:block">
              <span className="text-xs text-muted-foreground">
                {record.lastCommunicationDate
                  ? formatDate(record.lastCommunicationDate)
                  : "-"}
              </span>
            </div>
            <div className="col-span-2 hidden items-center gap-1 lg:flex">
              <span className="flex-1 text-xs text-muted-foreground">
                {record.firstConversationDate
                  ? formatDate(record.firstConversationDate)
                  : "-"}
              </span>
              <ChevronRight
                size={14}
                className="shrink-0 text-muted-foreground opacity-0 transition-all group-hover:translate-x-0.5 group-hover:opacity-100"
              />
            </div>
          </Link>
        ))
      )}
    </div>
  )
}
