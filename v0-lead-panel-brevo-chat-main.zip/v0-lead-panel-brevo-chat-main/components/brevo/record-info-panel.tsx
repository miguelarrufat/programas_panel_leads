"use client"

import { type LeadRecord, type ContactRecord, type RecordType } from "@/lib/brevo-data"
import { Building2, Mail, Phone, Briefcase, Tag } from "lucide-react"

export function RecordInfoPanel({
  recordType,
  record,
}: {
  recordType: RecordType
  record: LeadRecord | ContactRecord
}) {
  const isContact = recordType === "contact"
  const contactRecord = record as ContactRecord
  const leadRecord = record as LeadRecord

  return (
    <div className="border-b border-border bg-card px-4 py-3">
      <div className="flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 text-sm font-bold text-primary">
          {record.name
            .split(" ")
            .map((n) => n[0])
            .join("")
            .slice(0, 2)}
        </div>
        <div className="min-w-0 flex-1">
          <h2 className="truncate text-base font-semibold text-foreground">
            {record.name}
          </h2>
          <span className="inline-flex items-center gap-1 rounded-full bg-primary/10 px-2 py-0.5 text-[11px] font-medium text-primary">
            {isContact ? "Contact" : "Lead"}
          </span>
        </div>
      </div>
      <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1.5">
        <InfoItem icon={Mail} label={record.email} />
        <InfoItem icon={Phone} label={record.phone} />
        <InfoItem icon={Building2} label={record.company} />
        {isContact ? (
          <InfoItem icon={Briefcase} label={contactRecord.title} />
        ) : (
          <InfoItem icon={Tag} label={leadRecord.status} />
        )}
      </div>
    </div>
  )
}

function InfoItem({
  icon: Icon,
  label,
}: {
  icon: typeof Mail
  label: string
}) {
  return (
    <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
      <Icon size={12} className="shrink-0" />
      <span className="truncate">{label}</span>
    </span>
  )
}
