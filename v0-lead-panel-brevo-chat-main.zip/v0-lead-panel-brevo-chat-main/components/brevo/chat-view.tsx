"use client"

import { useRef, useEffect, useMemo } from "react"
import {
  type Conversation,
  type Message,
  type VisitorIdentification,
  formatMessageTime,
  identifyVisitor,
} from "@/lib/brevo-data"
import { ChannelBadge } from "./channel-badge"
import { StatusBadge } from "./status-badge"
import { MessageComposer } from "./message-composer"
import { cn } from "@/lib/utils"
import { User, ArrowLeft, ExternalLink, UserPlus, UserCheck } from "lucide-react"

function IdentificationBanner({ identification, conversationId }: { identification: VisitorIdentification; conversationId: string }) {
  if (identification.status === "loading") {
    return (
      <div className="flex items-center gap-2 rounded-lg bg-muted px-3 py-2">
        <div className="h-4 w-4 animate-spin rounded-full border-2 border-muted-foreground border-t-transparent" />
        <span className="text-xs text-muted-foreground">Identificando visitante...</span>
      </div>
    )
  }

  if (identification.status === "lead") {
    return (
      <div className="flex items-center gap-2 rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 dark:border-amber-800 dark:bg-amber-950/30">
        <div className="flex h-5 w-5 items-center justify-center rounded bg-amber-100 dark:bg-amber-900/50">
          <UserCheck size={12} className="text-amber-700 dark:text-amber-400" />
        </div>
        <span className="text-xs font-medium text-amber-800 dark:text-amber-300">Lead:</span>
        <button className="flex items-center gap-1 text-xs font-semibold text-amber-900 underline decoration-amber-400 underline-offset-2 transition-colors hover:text-amber-700 dark:text-amber-200">
          {identification.recordName}
          <ExternalLink size={10} />
        </button>
      </div>
    )
  }

  if (identification.status === "contact") {
    return (
      <div className="flex items-center gap-2 rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2 dark:border-emerald-800 dark:bg-emerald-950/30">
        <div className="flex h-5 w-5 items-center justify-center rounded bg-emerald-100 dark:bg-emerald-900/50">
          <UserCheck size={12} className="text-emerald-700 dark:text-emerald-400" />
        </div>
        <span className="text-xs font-medium text-emerald-800 dark:text-emerald-300">Contacto:</span>
        <button className="flex items-center gap-1 text-xs font-semibold text-emerald-900 underline decoration-emerald-400 underline-offset-2 transition-colors hover:text-emerald-700 dark:text-emerald-200">
          {identification.recordName}
          <ExternalLink size={10} />
        </button>
      </div>
    )
  }

  // Unidentified
  return (
    <div className="flex flex-wrap items-center gap-2 rounded-lg border border-orange-200 bg-orange-50 px-3 py-2 dark:border-orange-800 dark:bg-orange-950/30">
      <div className="flex h-5 w-5 items-center justify-center rounded bg-orange-100 dark:bg-orange-900/50">
        <User size={12} className="text-orange-600 dark:text-orange-400" />
      </div>
      <span className="text-xs font-semibold text-orange-800 dark:text-orange-300">Sin identificar</span>
      <div className="ml-auto flex items-center gap-1.5">
        <button className="flex items-center gap-1 rounded-md bg-primary px-2.5 py-1 text-[11px] font-medium text-primary-foreground transition-colors hover:bg-primary/90">
          <UserPlus size={11} />
          Crear Lead
        </button>
        <button className="flex items-center gap-1 rounded-md border border-border bg-card px-2.5 py-1 text-[11px] font-medium text-foreground transition-colors hover:bg-muted">
          <UserPlus size={11} />
          Crear Contacto
        </button>
      </div>
    </div>
  )
}

function MessageBubble({ message }: { message: Message }) {
  const isAgent = message.sender === "agent"

  return (
    <div
      className={cn(
        "flex w-full",
        isAgent ? "justify-end" : "justify-start"
      )}
    >
      <div
        className={cn(
          "max-w-[75%] rounded-2xl px-4 py-2.5",
          isAgent
            ? "rounded-br-md bg-primary text-primary-foreground"
            : "rounded-bl-md bg-muted text-foreground"
        )}
      >
        {isAgent && message.agentName && (
          <p className="mb-0.5 text-[11px] font-medium opacity-75">
            {message.agentName}
          </p>
        )}
        <p className="text-sm leading-relaxed">{message.text}</p>
        <p
          className={cn(
            "mt-1 text-right text-[10px]",
            isAgent ? "opacity-60" : "text-muted-foreground"
          )}
        >
          {formatMessageTime(message.timestamp)}
        </p>
      </div>
    </div>
  )
}

export function ChatView({
  conversation,
  onSend,
  onBack,
  onStatusChange,
}: {
  conversation: Conversation | null
  onSend: (conversationId: string, text: string) => void
  onBack?: () => void
  onStatusChange?: (conversationId: string, status: Conversation["status"]) => void
}) {
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const identification = useMemo(() => {
    if (!conversation) return null
    return identifyVisitor(conversation.visitorEmail, conversation.visitorPhone)
  }, [conversation?.id, conversation?.visitorEmail, conversation?.visitorPhone])

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [conversation?.messages.length])

  if (!conversation) {
    return (
      <div className="flex h-full flex-col items-center justify-center bg-background text-muted-foreground">
        <div className="flex h-16 w-16 items-center justify-center rounded-full bg-muted">
          <User size={28} className="opacity-40" />
        </div>
        <p className="mt-4 text-sm">Selecciona una conversacion para empezar</p>
      </div>
    )
  }

  return (
    <div className="flex h-full flex-col bg-background">
      {/* Chat Header */}
      <div className="border-b border-border bg-card px-4 py-3">
        <div className="flex items-center gap-3">
          {onBack && (
            <button
              onClick={onBack}
              className="rounded-md p-1.5 transition-colors hover:bg-muted lg:hidden"
              aria-label="Volver a la lista"
            >
              <ArrowLeft size={18} />
            </button>
          )}
          <div className="flex h-9 w-9 items-center justify-center rounded-full bg-primary/10 text-sm font-semibold text-primary">
            {conversation.visitorName
              .split(" ")
              .map((n) => n[0])
              .join("")
              .slice(0, 2)}
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <h3 className="truncate text-sm font-semibold text-foreground">
                {conversation.visitorName}
              </h3>
              <ChannelBadge channel={conversation.channel} showLabel={false} size="sm" />
            </div>
            <p className="truncate text-xs text-muted-foreground">
              {conversation.visitorEmail}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <StatusBadge status={conversation.status} />
            {onStatusChange && conversation.status !== "resolved" && (
              <button
                onClick={() => onStatusChange(conversation.id, "resolved")}
                className="rounded-md bg-accent/10 px-2.5 py-1 text-xs font-medium text-accent transition-colors hover:bg-accent/20"
              >
                Resolver
              </button>
            )}
          </div>
        </div>

        {/* Identification Banner */}
        {identification && (
          <div className="mt-2">
            <IdentificationBanner identification={identification} conversationId={conversation.id} />
          </div>
        )}
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto px-4 py-4">
        <div className="mx-auto flex max-w-2xl flex-col gap-3">
          {/* Date separator */}
          <div className="flex items-center gap-3 py-2">
            <div className="h-px flex-1 bg-border" />
            <span className="text-[11px] text-muted-foreground">
              {new Date(conversation.messages[0]?.timestamp).toLocaleDateString(
                "es-ES",
                { weekday: "long", day: "numeric", month: "long" }
              )}
            </span>
            <div className="h-px flex-1 bg-border" />
          </div>

          {conversation.messages.map((msg) => (
            <MessageBubble key={msg.id} message={msg} />
          ))}
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Composer */}
      <div className="mx-auto w-full max-w-2xl">
        <MessageComposer
          channel={conversation.channel}
          onSend={(text) => onSend(conversation.id, text)}
          disabled={conversation.status === "resolved"}
        />
      </div>
    </div>
  )
}
