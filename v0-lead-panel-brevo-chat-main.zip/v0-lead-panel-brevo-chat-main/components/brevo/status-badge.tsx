import { type ConversationStatus, getStatusLabel } from "@/lib/brevo-data"
import { cn } from "@/lib/utils"

const statusStyles: Record<ConversationStatus, string> = {
  open: "bg-accent/15 text-accent",
  pending: "bg-channel-webchat/15 text-channel-webchat",
  resolved: "bg-muted text-muted-foreground",
}

export function StatusBadge({ status }: { status: ConversationStatus }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium",
        statusStyles[status]
      )}
    >
      <span
        className={cn(
          "h-1.5 w-1.5 rounded-full",
          status === "open" && "bg-accent",
          status === "pending" && "bg-channel-webchat",
          status === "resolved" && "bg-muted-foreground"
        )}
      />
      {getStatusLabel(status)}
    </span>
  )
}
