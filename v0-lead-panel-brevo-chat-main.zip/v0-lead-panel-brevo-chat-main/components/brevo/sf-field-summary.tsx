"use client"

import {
  type RecordSummary,
  formatDate,
} from "@/lib/brevo-data"
import {
  MessageSquare,
  CircleAlert,
  CheckCircle2,
  Clock,
  CalendarDays,
} from "lucide-react"
import { cn } from "@/lib/utils"

/**
 * Simulates what a Salesforce custom field (populated by an Apex trigger)
 * would display on the Lead/Contact record. Shows at a glance:
 * - Unread indicator
 * - Open/pending status
 * - Last communication date
 * - First conversation date
 */
export function SfFieldSummary({
  summary,
}: {
  summary: RecordSummary
}) {
  return (
    <div className="rounded-lg border border-border bg-card">
      <div className="border-b border-border px-4 py-2.5">
        <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          Brevo Conversations - Resumen de campos
        </h4>
        <p className="mt-0.5 text-[11px] text-muted-foreground">
          Campos que se actualizarian via Apex Trigger en Salesforce
        </p>
      </div>

      <div className="grid grid-cols-1 gap-px bg-border sm:grid-cols-2 lg:grid-cols-4">
        {/* Unread status field */}
        <FieldCell
          label="Brevo_Sin_Leer__c"
          sfType="Checkbox"
          icon={CircleAlert}
          iconColor={summary.hasUnread ? "text-destructive" : "text-muted-foreground"}
        >
          <span
            className={cn(
              "flex items-center gap-1.5 text-sm font-medium",
              summary.hasUnread ? "text-destructive" : "text-muted-foreground"
            )}
          >
            <span
              className={cn(
                "h-2 w-2 rounded-full",
                summary.hasUnread ? "bg-destructive" : "bg-muted-foreground/30"
              )}
            />
            {summary.hasUnread
              ? `Si (${summary.unreadMessages} msg)`
              : "No"}
          </span>
        </FieldCell>

        {/* Open conversations field */}
        <FieldCell
          label="Brevo_Conv_Abiertas__c"
          sfType="Number"
          icon={MessageSquare}
          iconColor={summary.hasOpen ? "text-accent" : "text-muted-foreground"}
        >
          <span
            className={cn(
              "text-sm font-medium",
              summary.hasOpen ? "text-accent" : "text-muted-foreground"
            )}
          >
            {summary.openConversations + summary.pendingConversations}
            {summary.hasOpen && (
              <span className="ml-1.5 text-[11px] font-normal">
                ({summary.openConversations} abiertas, {summary.pendingConversations} pendientes)
              </span>
            )}
          </span>
        </FieldCell>

        {/* Last communication date field */}
        <FieldCell
          label="Brevo_Ultima_Comunicacion__c"
          sfType="DateTime"
          icon={Clock}
          iconColor="text-primary"
        >
          <span className="text-sm font-medium text-foreground">
            {summary.lastCommunicationDate
              ? formatDate(summary.lastCommunicationDate)
              : "-"}
          </span>
        </FieldCell>

        {/* First conversation date field */}
        <FieldCell
          label="Brevo_Primera_Conversacion__c"
          sfType="DateTime"
          icon={CalendarDays}
          iconColor="text-primary"
        >
          <span className="text-sm font-medium text-foreground">
            {summary.firstConversationDate
              ? formatDate(summary.firstConversationDate)
              : "-"}
          </span>
        </FieldCell>
      </div>

      {/* Status bar */}
      <div className="flex items-center gap-2 border-t border-border bg-muted/30 px-4 py-2">
        {summary.hasUnread ? (
          <>
            <CircleAlert size={14} className="text-destructive" />
            <span className="text-xs font-medium text-destructive">
              Tiene mensajes sin leer - Requiere atencion
            </span>
          </>
        ) : summary.hasOpen ? (
          <>
            <MessageSquare size={14} className="text-accent" />
            <span className="text-xs font-medium text-accent">
              Conversaciones abiertas activas
            </span>
          </>
        ) : (
          <>
            <CheckCircle2 size={14} className="text-muted-foreground" />
            <span className="text-xs font-medium text-muted-foreground">
              Sin conversaciones pendientes
            </span>
          </>
        )}
      </div>
    </div>
  )
}

function FieldCell({
  label,
  sfType,
  icon: Icon,
  iconColor,
  children,
}: {
  label: string
  sfType: string
  icon: typeof MessageSquare
  iconColor: string
  children: React.ReactNode
}) {
  return (
    <div className="flex flex-col gap-1.5 bg-card p-3">
      <div className="flex items-center gap-1.5">
        <Icon size={12} className={iconColor} />
        <span className="text-[11px] font-medium text-muted-foreground">
          {label}
        </span>
        <span className="rounded bg-muted px-1 py-0.5 text-[9px] font-medium text-muted-foreground">
          {sfType}
        </span>
      </div>
      {children}
    </div>
  )
}
