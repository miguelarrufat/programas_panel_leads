export type Channel = "whatsapp" | "email" | "instagram" | "webchat"

export type ConversationStatus = "open" | "pending" | "resolved"

export type RecordType = "lead" | "contact"

export interface Message {
  id: string
  conversationId: string
  sender: "agent" | "visitor"
  text: string
  timestamp: string
  agentName?: string
}

export interface Conversation {
  id: string
  visitorName: string
  visitorEmail: string
  visitorPhone?: string
  channel: Channel
  status: ConversationStatus
  lastMessage: string
  lastMessageTime: string
  unreadCount: number
  assignedAgent?: string
  recordType?: RecordType
  recordId?: string
  messages: Message[]
}

export type IdentificationStatus = "lead" | "contact" | "unidentified" | "loading"

export interface VisitorIdentification {
  status: IdentificationStatus
  recordType?: RecordType
  recordId?: string
  recordName?: string
}

export interface LeadRecord {
  id: string
  name: string
  email: string
  phone: string
  company: string
  status: string
}

export interface ContactRecord {
  id: string
  name: string
  email: string
  phone: string
  company: string
  title: string
}

// ── Mock Leads ──────────────────────────────────────────────────
export const mockLeads: LeadRecord[] = [
  {
    id: "lead-001",
    name: "Carlos Mendoza",
    email: "carlos.mendoza@empresa.com",
    phone: "+34 612 345 678",
    company: "Tech Solutions SL",
    status: "Qualified",
  },
  {
    id: "lead-002",
    name: "Laura Fernandez",
    email: "laura.f@startup.io",
    phone: "+34 655 987 321",
    company: "Startup Innovation",
    status: "New",
  },
  {
    id: "lead-003",
    name: "Miguel Torres",
    email: "m.torres@retail.es",
    phone: "+34 699 111 222",
    company: "Retail Express",
    status: "Working",
  },
]

// ── Mock Contacts ───────────────────────────────────────────────
export const mockContacts: ContactRecord[] = [
  {
    id: "contact-001",
    name: "Ana Garcia",
    email: "ana.garcia@corporacion.com",
    phone: "+34 611 222 333",
    company: "Corporacion Global",
    title: "Directora de Marketing",
  },
  {
    id: "contact-002",
    name: "Pedro Ruiz",
    email: "pedro.ruiz@finanzas.es",
    phone: "+34 622 333 444",
    company: "Finanzas Plus",
    title: "CFO",
  },
  {
    id: "contact-003",
    name: "Sofia Martinez",
    email: "sofia@designlab.com",
    phone: "+34 633 444 555",
    company: "Design Lab",
    title: "Lead Designer",
  },
]

// ── Mock Conversations ──────────────────────────────────────────
export const mockConversations: Conversation[] = [
  {
    id: "conv-001",
    visitorName: "Carlos Mendoza",
    visitorEmail: "carlos.mendoza@empresa.com",
    visitorPhone: "+34 612 345 678",
    channel: "whatsapp",
    status: "open",
    lastMessage: "Necesito informacion sobre el plan Enterprise",
    lastMessageTime: "2026-02-18T10:32:00Z",
    unreadCount: 2,
    assignedAgent: "Maria Lopez",
    recordType: "lead",
    recordId: "lead-001",
    messages: [
      {
        id: "msg-001",
        conversationId: "conv-001",
        sender: "visitor",
        text: "Hola, buenos dias. Me interesa el plan Enterprise para nuestra empresa.",
        timestamp: "2026-02-18T10:15:00Z",
      },
      {
        id: "msg-002",
        conversationId: "conv-001",
        sender: "agent",
        text: "Buenos dias Carlos! Encantada de ayudarte. El plan Enterprise incluye soporte dedicado, integraciones avanzadas y SLA garantizado. Podemos agendar una demo?",
        timestamp: "2026-02-18T10:20:00Z",
        agentName: "Maria Lopez",
      },
      {
        id: "msg-003",
        conversationId: "conv-001",
        sender: "visitor",
        text: "Si, me gustaria ver una demo. Somos un equipo de 50 personas.",
        timestamp: "2026-02-18T10:28:00Z",
      },
      {
        id: "msg-004",
        conversationId: "conv-001",
        sender: "visitor",
        text: "Necesito informacion sobre el plan Enterprise",
        timestamp: "2026-02-18T10:32:00Z",
      },
    ],
  },
  {
    id: "conv-002",
    visitorName: "Ana Garcia",
    visitorEmail: "ana.garcia@corporacion.com",
    visitorPhone: "+34 611 222 333",
    channel: "email",
    status: "open",
    lastMessage: "Adjunto el contrato firmado para su revision",
    lastMessageTime: "2026-02-18T09:45:00Z",
    unreadCount: 1,
    assignedAgent: "Juan Perez",
    recordType: "contact",
    recordId: "contact-001",
    messages: [
      {
        id: "msg-005",
        conversationId: "conv-002",
        sender: "visitor",
        text: "Hola Juan, te envio el contrato firmado como acordamos en la reunion del viernes.",
        timestamp: "2026-02-18T09:30:00Z",
      },
      {
        id: "msg-006",
        conversationId: "conv-002",
        sender: "agent",
        text: "Perfecto Ana, lo reviso y te confirmo. Gracias!",
        timestamp: "2026-02-18T09:35:00Z",
        agentName: "Juan Perez",
      },
      {
        id: "msg-007",
        conversationId: "conv-002",
        sender: "visitor",
        text: "Adjunto el contrato firmado para su revision",
        timestamp: "2026-02-18T09:45:00Z",
      },
    ],
  },
  {
    id: "conv-003",
    visitorName: "Laura Fernandez",
    visitorEmail: "laura.f@startup.io",
    visitorPhone: "+34 655 987 321",
    channel: "instagram",
    status: "pending",
    lastMessage: "Vi su publicacion sobre automatizacion y me encanto!",
    lastMessageTime: "2026-02-18T08:15:00Z",
    unreadCount: 0,
    assignedAgent: "Maria Lopez",
    recordType: "lead",
    recordId: "lead-002",
    messages: [
      {
        id: "msg-008",
        conversationId: "conv-003",
        sender: "visitor",
        text: "Hola! Vi su publicacion sobre automatizacion y me encanto. Tienen algun plan para startups?",
        timestamp: "2026-02-18T08:00:00Z",
      },
      {
        id: "msg-009",
        conversationId: "conv-003",
        sender: "agent",
        text: "Hola Laura! Si, tenemos un plan Startup con 60% de descuento el primer ano. Te interesa que te cuente mas?",
        timestamp: "2026-02-18T08:10:00Z",
        agentName: "Maria Lopez",
      },
      {
        id: "msg-010",
        conversationId: "conv-003",
        sender: "visitor",
        text: "Vi su publicacion sobre automatizacion y me encanto!",
        timestamp: "2026-02-18T08:15:00Z",
      },
    ],
  },
  {
    id: "conv-004",
    visitorName: "Pedro Ruiz",
    visitorEmail: "pedro.ruiz@finanzas.es",
    visitorPhone: "+34 622 333 444",
    channel: "webchat",
    status: "resolved",
    lastMessage: "Perfecto, queda resuelto. Muchas gracias!",
    lastMessageTime: "2026-02-17T16:20:00Z",
    unreadCount: 0,
    assignedAgent: "Juan Perez",
    recordType: "contact",
    recordId: "contact-002",
    messages: [
      {
        id: "msg-011",
        conversationId: "conv-004",
        sender: "visitor",
        text: "Tengo un problema con la facturacion del ultimo mes.",
        timestamp: "2026-02-17T15:30:00Z",
      },
      {
        id: "msg-012",
        conversationId: "conv-004",
        sender: "agent",
        text: "Hola Pedro, deja que revise tu cuenta... Ya lo encontre, hubo una duplicacion. Procedo a hacer el ajuste.",
        timestamp: "2026-02-17T15:45:00Z",
        agentName: "Juan Perez",
      },
      {
        id: "msg-013",
        conversationId: "conv-004",
        sender: "visitor",
        text: "Perfecto, queda resuelto. Muchas gracias!",
        timestamp: "2026-02-17T16:20:00Z",
      },
    ],
  },
  {
    id: "conv-005",
    visitorName: "Sofia Martinez",
    visitorEmail: "sofia@designlab.com",
    visitorPhone: "+34 633 444 555",
    channel: "whatsapp",
    status: "open",
    lastMessage: "Podemos hablar sobre la integracion con Figma?",
    lastMessageTime: "2026-02-18T11:00:00Z",
    unreadCount: 3,
    assignedAgent: "Maria Lopez",
    recordType: "contact",
    recordId: "contact-003",
    messages: [
      {
        id: "msg-014",
        conversationId: "conv-005",
        sender: "visitor",
        text: "Hola! Estoy interesada en integrar vuestra plataforma con Figma. Es posible?",
        timestamp: "2026-02-18T10:40:00Z",
      },
      {
        id: "msg-015",
        conversationId: "conv-005",
        sender: "visitor",
        text: "Tambien necesitaria exportar reportes en PDF.",
        timestamp: "2026-02-18T10:50:00Z",
      },
      {
        id: "msg-016",
        conversationId: "conv-005",
        sender: "visitor",
        text: "Podemos hablar sobre la integracion con Figma?",
        timestamp: "2026-02-18T11:00:00Z",
      },
    ],
  },
  {
    id: "conv-006",
    visitorName: "Miguel Torres",
    visitorEmail: "m.torres@retail.es",
    visitorPhone: "+34 699 111 222",
    channel: "email",
    status: "open",
    lastMessage: "Necesitamos una solucion de inventario urgente",
    lastMessageTime: "2026-02-18T07:30:00Z",
    unreadCount: 1,
    recordType: "lead",
    recordId: "lead-003",
    messages: [
      {
        id: "msg-017",
        conversationId: "conv-006",
        sender: "visitor",
        text: "Buenos dias, gestionamos 200 tiendas y necesitamos una solucion de inventario integrada. Que nos ofrecen?",
        timestamp: "2026-02-18T07:15:00Z",
      },
      {
        id: "msg-018",
        conversationId: "conv-006",
        sender: "visitor",
        text: "Necesitamos una solucion de inventario urgente",
        timestamp: "2026-02-18T07:30:00Z",
      },
    ],
  },
  {
    id: "conv-007",
    visitorName: "Ana Garcia",
    visitorEmail: "ana.garcia@corporacion.com",
    visitorPhone: "+34 611 222 333",
    channel: "whatsapp",
    status: "open",
    lastMessage: "Cuando podemos agendar la proxima reunion?",
    lastMessageTime: "2026-02-18T11:15:00Z",
    unreadCount: 1,
    recordType: "contact",
    recordId: "contact-001",
    messages: [
      {
        id: "msg-019",
        conversationId: "conv-007",
        sender: "visitor",
        text: "Hola Maria, queria confirmar lo de la reunion de la semana que viene.",
        timestamp: "2026-02-18T11:05:00Z",
      },
      {
        id: "msg-020",
        conversationId: "conv-007",
        sender: "visitor",
        text: "Cuando podemos agendar la proxima reunion?",
        timestamp: "2026-02-18T11:15:00Z",
      },
    ],
  },
  {
    id: "conv-008",
    visitorName: "Visitante Desconocido",
    visitorEmail: "nuevo.visitante@gmail.com",
    visitorPhone: "+34 677 888 999",
    channel: "webchat",
    status: "open",
    lastMessage: "Hola, me gustaria recibir informacion sobre sus servicios",
    lastMessageTime: "2026-02-18T11:30:00Z",
    unreadCount: 1,
    messages: [
      {
        id: "msg-021",
        conversationId: "conv-008",
        sender: "visitor",
        text: "Hola, me gustaria recibir informacion sobre sus servicios. Soy una empresa de logistica.",
        timestamp: "2026-02-18T11:25:00Z",
      },
      {
        id: "msg-022",
        conversationId: "conv-008",
        sender: "visitor",
        text: "Hola, me gustaria recibir informacion sobre sus servicios",
        timestamp: "2026-02-18T11:30:00Z",
      },
    ],
  },
]

// ── Identify visitor by email/phone ──────────────────────────────
export function identifyVisitor(email?: string, phone?: string): VisitorIdentification {
  if (email) {
    const lead = mockLeads.find(l => l.email.toLowerCase() === email.toLowerCase())
    if (lead) {
      return { status: "lead", recordType: "lead", recordId: lead.id, recordName: lead.name }
    }
    const contact = mockContacts.find(c => c.email.toLowerCase() === email.toLowerCase())
    if (contact) {
      return { status: "contact", recordType: "contact", recordId: contact.id, recordName: contact.name }
    }
  }
  if (phone) {
    const lead = mockLeads.find(l => l.phone === phone)
    if (lead) {
      return { status: "lead", recordType: "lead", recordId: lead.id, recordName: lead.name }
    }
    const contact = mockContacts.find(c => c.phone === phone)
    if (contact) {
      return { status: "contact", recordType: "contact", recordId: contact.id, recordName: contact.name }
    }
  }
  return { status: "unidentified" }
}

export function getConversationsForRecord(
  recordType: RecordType,
  recordId: string
): Conversation[] {
  return mockConversations.filter(
    (c) => c.recordType === recordType && c.recordId === recordId
  )
}

export function getChannelLabel(channel: Channel): string {
  const labels: Record<Channel, string> = {
    whatsapp: "WhatsApp",
    email: "Email",
    instagram: "Instagram",
    webchat: "Web Chat",
  }
  return labels[channel]
}

export function getStatusLabel(status: ConversationStatus): string {
  const labels: Record<ConversationStatus, string> = {
    open: "Abierta",
    pending: "Pendiente",
    resolved: "Resuelta",
  }
  return labels[status]
}

export function formatTime(isoString: string): string {
  const date = new Date(isoString)
  const now = new Date()
  const diff = now.getTime() - date.getTime()
  const hours = Math.floor(diff / (1000 * 60 * 60))

  if (hours < 1) {
    const minutes = Math.floor(diff / (1000 * 60))
    return minutes < 1 ? "Ahora" : `Hace ${minutes}m`
  }
  if (hours < 24) return `Hace ${hours}h`

  return date.toLocaleDateString("es-ES", { day: "numeric", month: "short" })
}

export function formatMessageTime(isoString: string): string {
  const date = new Date(isoString)
  return date.toLocaleTimeString("es-ES", {
    hour: "2-digit",
    minute: "2-digit",
  })
}

export function formatDate(isoString: string): string {
  const date = new Date(isoString)
  return date.toLocaleDateString("es-ES", {
    day: "numeric",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  })
}

export interface RecordSummary {
  recordType: RecordType
  recordId: string
  name: string
  email: string
  phone: string
  company: string
  extraLabel: string // status for lead, title for contact
  totalConversations: number
  openConversations: number
  pendingConversations: number
  unreadMessages: number
  hasUnread: boolean
  hasOpen: boolean
  lastCommunicationDate: string | null
  firstConversationDate: string | null
}

export function getRecordSummaries(): RecordSummary[] {
  const summaries: RecordSummary[] = []

  for (const lead of mockLeads) {
    const convs = mockConversations.filter(
      (c) => c.recordType === "lead" && c.recordId === lead.id
    )
    const allTimes = convs.map((c) => new Date(c.lastMessageTime).getTime())
    const firstTimes = convs.flatMap((c) =>
      c.messages.length ? [new Date(c.messages[0].timestamp).getTime()] : []
    )

    summaries.push({
      recordType: "lead",
      recordId: lead.id,
      name: lead.name,
      email: lead.email,
      phone: lead.phone,
      company: lead.company,
      extraLabel: lead.status,
      totalConversations: convs.length,
      openConversations: convs.filter((c) => c.status === "open").length,
      pendingConversations: convs.filter((c) => c.status === "pending").length,
      unreadMessages: convs.reduce((sum, c) => sum + c.unreadCount, 0),
      hasUnread: convs.some((c) => c.unreadCount > 0),
      hasOpen: convs.some((c) => c.status === "open" || c.status === "pending"),
      lastCommunicationDate: allTimes.length
        ? new Date(Math.max(...allTimes)).toISOString()
        : null,
      firstConversationDate: firstTimes.length
        ? new Date(Math.min(...firstTimes)).toISOString()
        : null,
    })
  }

  for (const contact of mockContacts) {
    const convs = mockConversations.filter(
      (c) => c.recordType === "contact" && c.recordId === contact.id
    )
    const allTimes = convs.map((c) => new Date(c.lastMessageTime).getTime())
    const firstTimes = convs.flatMap((c) =>
      c.messages.length ? [new Date(c.messages[0].timestamp).getTime()] : []
    )

    summaries.push({
      recordType: "contact",
      recordId: contact.id,
      name: contact.name,
      email: contact.email,
      phone: contact.phone,
      company: contact.company,
      extraLabel: contact.title,
      totalConversations: convs.length,
      openConversations: convs.filter((c) => c.status === "open").length,
      pendingConversations: convs.filter((c) => c.status === "pending").length,
      unreadMessages: convs.reduce((sum, c) => sum + c.unreadCount, 0),
      hasUnread: convs.some((c) => c.unreadCount > 0),
      hasOpen: convs.some((c) => c.status === "open" || c.status === "pending"),
      lastCommunicationDate: allTimes.length
        ? new Date(Math.max(...allTimes)).toISOString()
        : null,
      firstConversationDate: firstTimes.length
        ? new Date(Math.min(...firstTimes)).toISOString()
        : null,
    })
  }

  return summaries
}
