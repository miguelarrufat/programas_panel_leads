import { LightningElement, track } from 'lwc';
import { subscribe, onError } from 'lightning/empApi';
import { NavigationMixin } from 'lightning/navigation';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import getConversations from '@salesforce/apex/BrevoConversationsController.getConversations';
import getGroupedConversationMessages from '@salesforce/apex/BrevoConversationsController.getGroupedConversationMessages';
import markConversationAsRead from '@salesforce/apex/BrevoConversationsController.markConversationAsRead';
import linkConversationToRecord from '@salesforce/apex/BrevoConversationsController.linkConversationToRecord';
import sendMessage from '@salesforce/apex/BrevoConversationsController.sendMessage';
import sendMessageWithFile from '@salesforce/apex/BrevoConversationsController.sendMessageWithFile';
import sendTransactionalEmail from '@salesforce/apex/BrevoConversationsController.sendTransactionalEmail';
import sendTransactionalEmailWithAttachment from '@salesforce/apex/BrevoConversationsController.sendTransactionalEmailWithAttachment';
import getEmailTemplates from '@salesforce/apex/BrevoConversationsController.getEmailTemplates';
import getWhatsAppTemplates from '@salesforce/apex/BrevoConversationsController.getWhatsAppTemplates';
import sendWhatsAppMessage from '@salesforce/apex/BrevoConversationsController.sendWhatsAppMessage';
import sendTransactionalSMS from '@salesforce/apex/BrevoConversationsController.sendTransactionalSMS';
import webhookDiagnostic from '@salesforce/apex/BrevoConversationsController.webhookDiagnostic';
import closeConversation from '@salesforce/apex/BrevoConversationsController.closeConversation';
import getSavedResponses from '@salesforce/apex/BrevoConversationsController.getSavedResponses';
import getAccountUsage from '@salesforce/apex/BrevoConversationsController.getAccountUsage';
import getInboxCounts from '@salesforce/apex/BrevoConversationsController.getInboxCounts';
import getNewLeads from '@salesforce/apex/BrevoConversationsController.getNewLeads';
import getNewLeadsPaginated from '@salesforce/apex/BrevoConversationsController.getNewLeadsPaginated';
import getAccessibleSchools from '@salesforce/apex/BrevoConversationsController.getAccessibleSchools';
import getDashboardStats from '@salesforce/apex/BrevoConversationsController.getDashboardStats';

const CHANNEL = '/event/Brevo_Message_Event__e';

const EMOJI_LIST = [
    { cat: 'Faces', items: ['😊','😂','🤣','😍','🥰','😘','😜','🤔','😢','😭','😡','🤯','🥳','😎','🙄','😴','🤗','🤮','😷','🤓'] },
    { cat: 'Hands', items: ['👍','👎','👏','🙏','🤝','💪','👋','🤲','✌️','🤞','👌','🫶','🫡','✋','🤙'] },
    { cat: 'Hearts', items: ['❤️','🧡','💛','💚','💙','💜','🖤','🤍','💔','❤️‍🔥','💕','💗','💖','💝'] },
    { cat: 'Symbols', items: ['✅','❌','⚠️','🔥','⭐','💡','📌','🎯','💬','📎','📝','🔔','🕐','📊','🚀'] }
];

export default class BrevoInbox extends NavigationMixin(LightningElement) {
    // ─── Tab State ───────────────────────────────────────────
    @track activeTab = 'leads'; // 'summary' | 'leads' | 'conversations'
    @track newLeadCount = 0;
    @track unreadConvCount = 0;
    @track leads = [];
    @track isLoadingLeads = false;
    
    // ─── Summary Tab State ───────────────────────────────────
    @track summarySubtab = 'leads'; // 'leads' | 'conversations'
    @track summaryYear = '2026_2027';
    @track summarySchool = '';
    @track isLoadingSummary = false;
    @track summaryStats = {
        totalLeads: 0,
        newCount: 0,
        enrolledCount: 0,
        lostCount: 0,
        leadsByStatus: [],
        leadsByStage: [],
        leadsByGrade: [],
        weeklyLeads: [],
        weeklyLabels: [],
        lastContactDist: [],
        openConvs: 0,
        closedConvs: 0,
        unlinkedConvs: 0,
        totalConvs: 0,
        convByStatus: [],
        convBySource: [],
        weeklyConvs: [],
        weeklyConvLabels: []
    };
    _pinnedFilters = null;
    @track schoolOptions = [];
    @track selectedSchoolId = '';
    @track selectedYear = '';  // Default to All
    @track selectedStatus = '';
    @track searchTerm = '';
    
    // Pagination for Leads tab
    @track currentPage = 1;
    @track pageSize = 100;
    @track totalLeadsCount = 0;
    @track isLoadingMoreLeads = false;
    
    @track showLegendPopup = false;
    @track showLeadConversationsModal = false;
    @track convSchoolFilter = ''; // School filter for conversations tab
    
    // Related records modal (siblings/duplicates/contacts)
    @track showRelatedModal = false;
    @track relatedModalTitle = '';
    @track relatedRecords = [];
    
    // Flow modal for Lead Status update
    @track showFlowModal = false;
    @track flowLeadId = null;
    
    // Filter options - values use API Names (underscore format)
    yearOptions = [
      { label: 'All', value: '' },
      { label: '2021-2022', value: '2021_2022' },
      { label: '2022-2023', value: '2022_2023' },
      { label: '2023-2024', value: '2023_2024' },
      { label: '2024-2025', value: '2024_2025' },
      { label: '2025-2026', value: '2025_2026' },
      { label: '2026-2027', value: '2026_2027' },
      { label: '2027-2028', value: '2027_2028' },
      { label: '2028-2029', value: '2028_2029' },
      { label: '2029-2030', value: '2029_2030' },
      { label: '2030-2031', value: '2030_2031' }
    ];
    statusOptions = [
      { label: 'All', value: '' },
      { label: 'New', value: 'New' },
      { label: 'First Contact', value: '1er Contacto' },
      { label: 'School Visit', value: 'School Visit' },
      { label: 'Interview', value: 'Entrevista1' },
      { label: 'Application for Place', value: 'Solicitud de Plaza' },
      { label: 'Entry Test', value: 'Prueba de Acceso' },
      { label: 'Test Week', value: 'Test Week' },
      { label: 'Pre-Enrollment', value: 'Pre-Enrollment' },
      { label: 'Enrollment', value: 'Convertido' },
      { label: 'Barn', value: 'Granero' },
      { label: 'Lost', value: 'Perdido' }
    ];
    @track leadConvModalRecordId = null;
    @track leadConvModalName = '';

    // ─── Conversation State ──────────────────────────────────
    @track conversations = [];
    @track selectedConv = null;
    @track messages = [];
    @track isLoading = true;
    @track isLoadingMessages = false;
    @track error = null;
    @track isSending = false;

    // Modals
    @track showEmailModal = false;
    @track showWhatsAppModal = false;
    @track showSmsModal = false;
    @track showLinkModal = false;

    // Email form
    @track emailTo = '';
    @track emailSubject = '';
    @track emailBody = '';
    @track isSendingEmail = false;
    @track emailTemplateId = null;
    @track emailTemplateOptions = [];
    @track emailFile = null;
    _emailTemplatesData = [];

    // WhatsApp form
    @track waPhone = '';
    @track waTemplateId = null;
    @track waTemplates = [];
    @track waTemplatesLoading = false;
    _waTemplateDataMap = {};
    @track isSendingWa = false;

    // SMS form
    @track smsPhone = '';
    @track smsContent = '';
    @track isSendingSms = false;

    // Link record
    @track linkRecordId = '';
    @track isLinking = false;

    // Diagnostic
    @track showDiagnosticModal = false;
    @track diagPhone = '';
    @track diagEmail = '';
    @track diagResult = null;
    @track isDiagRunning = false;

    // Emoji picker
    @track showEmojiPicker = false;
    @track emojiCategories = EMOJI_LIST;

    // Saved responses
    @track showSavedResponses = false;
    @track savedResponses = [];
    @track savedResponsesFilter = '';

    // Account usage
    @track showUsageModal = false;
    @track usageData = null;
    @track isLoadingUsage = false;

    // Close conversation
    @track isClosing = false;

    // Timer
    @track windowTimerText = '';
    @track isWindowExpired = false;

    // File attachment
    @track pendingFile = null;  // { name, base64, size, type }

    searchTerm = '';
    filterStatus = 'In Progress';
    messageText = '';
    
    // Conversation status filter options
    convStatusOptions = [
      { label: 'All', value: 'All' },
      { label: 'In Progress', value: 'In Progress' },
      { label: 'Closed', value: 'Closed' },
      { label: 'Unlinked', value: 'Unlinked' }
    ];
    subscription = null;
    _timerInterval = null;

  connectedCallback() {
    this.loadInboxCounts();
    this.loadConversations();
    this.subscribeToPlatformEvents();
    this.loadSavedResponses();
    // Load leads and school options since default tab is now 'leads'
    this.loadSchoolOptions();
    this.loadLeads();
  }

  disconnectedCallback() {
    this.clearWindowTimer();
  }

  // ─── Tab Getters ─────────────────────────────────────────
  get isSummaryTab() { return this.activeTab === 'summary'; }
  get isLeadsTab() { return this.activeTab === 'leads'; }
  get isConversationsTab() { return this.activeTab === 'conversations'; }
  get summaryTabClass() {
    return this.activeTab === 'summary'
      ? 'slds-tabs_default__item slds-is-active'
      : 'slds-tabs_default__item';
  }
  get leadsTabClass() {
    return this.activeTab === 'leads'
      ? 'slds-tabs_default__item slds-is-active'
      : 'slds-tabs_default__item';
  }
  get conversationsTabClass() {
    return this.activeTab === 'conversations'
      ? 'slds-tabs_default__item slds-is-active'
      : 'slds-tabs_default__item';
  }
  
  // Summary sub-tab getters
  get showLeadsSummary() { return !this.isLoadingSummary && this.summarySubtab === 'leads'; }
  get showConvsSummary() { return !this.isLoadingSummary && this.summarySubtab === 'conversations'; }
  get showYearStatusTable() { return this.selectedYear === '' && this.summaryStats?.leadsByYearStatus?.hasData; }
  get summaryLeadsSubtabClass() {
    return this.summarySubtab === 'leads'
      ? 'slds-tabs_scoped__item slds-is-active'
      : 'slds-tabs_scoped__item';
  }
  get summaryConvsSubtabClass() {
    return this.summarySubtab === 'conversations'
      ? 'slds-tabs_scoped__item slds-is-active'
      : 'slds-tabs_scoped__item';
  }
  get isPinned() { return this._pinnedFilters ? 'brand' : 'border'; }
  
  get hasLeads() { return !this.isLoadingLeads && this.leads.length > 0; }
  get noLeads() { return !this.isLoadingLeads && this.leads.length === 0; }
  get leadColumns() {
    return [
      { label: 'Contact Name', fieldName: 'Name', type: 'button', wrapText: true,
        typeAttributes: { label: { fieldName: 'Name' }, name: 'viewLead', variant: 'base' }
      },
      { label: 'Student Name', fieldName: 'Full_Name_formula__c', type: 'text', wrapText: true },
      { label: 'Related', fieldName: 'SiblingsDisplay', type: 'button',
        typeAttributes: { label: { fieldName: 'SiblingsDisplay' }, name: 'viewRelated', variant: 'base', disabled: { fieldName: 'NoRelated' } }
      },
      { label: 'Stage', fieldName: 'Etapa__c', type: 'text' },
      { label: 'Grade', fieldName: 'CursoName', type: 'text' },
      { label: 'Year', fieldName: 'A_o_de_Incorporaci_n__c', type: 'text' },
      { label: 'Status', fieldName: 'Status', type: 'button',
        typeAttributes: { label: { fieldName: 'Status' }, name: 'updateStatus', variant: 'base' }
      },
      { label: 'Last Contact', fieldName: 'LastContactFormatted', type: 'text' },
      { label: 'Contact', type: 'button-icon',
        typeAttributes: { iconName: 'utility:chat', name: 'viewConversations', title: 'View Conversations', variant: 'bare', alternativeText: 'Chat' }
      },
      { label: 'Phone', fieldName: 'Phone', type: 'phone' },
      { label: 'Entry Date', fieldName: 'Fecha_de_Entrada_del_Lead__c', type: 'date', 
        typeAttributes: { day: '2-digit', month: '2-digit', year: 'numeric' } },
      { label: 'School', fieldName: 'ColegioName', type: 'text', wrapText: true },
      {
        type: 'action',
        typeAttributes: {
          rowActions: [
            { label: 'View Lead', name: 'view' },
            { label: 'View Conversations', name: 'viewConversations' }
          ]
        }
      }
    ];
  }

  handleTabSummary() {
    this.activeTab = 'summary';
    if (this.schoolOptions.length === 0) {
      this.loadSchoolOptions();
    }
    // Apply pinned filters if available
    if (this._pinnedFilters) {
      this.summaryYear = this._pinnedFilters.year || '2026_2027';
      this.summarySchool = this._pinnedFilters.school || '';
    }
    this.loadDashboardStats();
  }
  handleTabLeads() {
    this.activeTab = 'leads';
    if (this.schoolOptions.length === 0) {
      this.loadSchoolOptions();
    }
    this.loadLeads();
  }
  handleTabConversations() {
    if (this.schoolOptions.length === 0) {
      this.loadSchoolOptions();
    }
    this.activeTab = 'conversations';
  }

  // Summary sub-tab handlers
  handleSummarySubtabLeads() {
    this.summarySubtab = 'leads';
  }
  handleSummarySubtabConvs() {
    this.summarySubtab = 'conversations';
  }
  handleSummaryYearChange(event) {
    this.summaryYear = event.detail.value;
    this.loadDashboardStats();
  }
  handleSummarySchoolChange(event) {
    this.summarySchool = event.detail.value;
    this.loadDashboardStats();
  }
  handleRefreshSummary() {
    this.loadDashboardStats();
  }
  handlePinFilters() {
    if (this._pinnedFilters) {
      this._pinnedFilters = null;
      this.showToast('Unpinned', 'Filters unpinned', 'info');
    } else {
      this._pinnedFilters = {
        year: this.summaryYear,
        school: this.summarySchool
      };
      this.showToast('Pinned', 'Filters pinned as default', 'success');
    }
  }

  async loadDashboardStats() {
    this.isLoadingSummary = true;
    try {
      const result = await getDashboardStats({
        schoolId: this.summarySchool || null,
        yearFilter: this.summaryYear || '2026_2027'
      });
      const data = JSON.parse(result);
      
      // Calculate max values for bar widths
      const maxStatus = Math.max(...data.leadsByStatus.map(i => i.count), 1);
      const maxStage = Math.max(...data.leadsByStage.map(i => i.count), 1);
      const maxGrade = Math.max(...data.leadsByGrade.map(i => i.count), 1);
      const maxContact = Math.max(...data.lastContactDist.map(i => i.count), 1);
      const maxConvStatus = Math.max(...data.convByStatus.map(i => i.count), 1);
      const maxConvSource = Math.max(...data.convBySource.map(i => i.count), 1);
      
      // Process leads by status with bar styles
      const leadsByStatus = data.leadsByStatus.map(item => ({
        status: item.status || 'Unknown',
        count: item.count,
        barStyle: `width: ${(item.count / maxStatus) * 100}%`
      }));
      
      // Process leads by stage
      const leadsByStage = data.leadsByStage.map(item => ({
        stage: item.stage || 'Unknown',
        count: item.count,
        barStyle: `width: ${(item.count / maxStage) * 100}%`
      }));
      
      // Process leads by grade
      const leadsByGrade = data.leadsByGrade.map(item => ({
        grade: item.grade || 'Unknown',
        count: item.count,
        barStyle: `width: ${(item.count / maxGrade) * 100}%`
      }));
      
      // Process last contact distribution
      const lastContactDist = data.lastContactDist.map(item => ({
        bucket: item.bucket,
        count: item.count,
        barStyle: `width: ${(item.count / maxContact) * 100}%`
      }));
      
      // Process weekly leads for line chart with Y-axis values
      const maxWeekly = Math.max(...data.weeklyLeads.map(i => i.count), 1);
      const weeklyMax = Math.ceil(maxWeekly / 5) * 5 || 5; // Round up to nearest 5
      const weeklyMid = Math.round(weeklyMax / 2);
      const weeklyLeads = data.weeklyLeads.map((item, idx) => ({
        label: `W${item.week}`,
        count: item.count,
        style: `bottom: ${(item.count / weeklyMax) * 100}%; left: ${(idx / Math.max(data.weeklyLeads.length - 1, 1)) * 100}%;`,
        tooltip: `Week ${item.week}: ${item.count} leads`
      }));
      const weeklyLabels = data.weeklyLeads.map(item => `W${item.week}`);
      
      // Extract KPI counts from status data (using API Names)
      let newCount = 0, enrolledCount = 0, interviewCount = 0, lostCount = 0;
      for (const item of data.leadsByStatus) {
        if (item.status === 'New') newCount += item.count;
        if (item.status === 'Convertido') enrolledCount += item.count;
        if (item.status === 'Entrevista1') interviewCount += item.count;
        if (item.status === 'Perdido') lostCount += item.count;
      }
      
      // Process conversation stats
      const convByStatus = data.convByStatus.map(item => ({
        status: item.status || 'Unknown',
        count: item.count,
        barStyle: `width: ${(item.count / maxConvStatus) * 100}%`
      }));
      
      const convBySource = data.convBySource.map(item => ({
        source: item.source || 'Unknown',
        count: item.count,
        barStyle: `width: ${(item.count / maxConvSource) * 100}%`
      }));
      
      // Process weekly conversations
      const maxWeeklyConv = Math.max(...data.weeklyConvs.map(i => i.count), 1);
      const weeklyConvs = data.weeklyConvs.map((item, idx) => ({
        label: `W${item.week}`,
        count: item.count,
        style: `height: ${(item.count / maxWeeklyConv) * 130}px;`,
        tooltip: `Week ${item.week}: ${item.count} conversations`
      }));
      const weeklyConvLabels = data.weeklyConvs.map(item => `W${item.week}`);
      
      // Process conversion funnel with step and total rates
      const maxFunnel = data.conversionFunnel?.length > 0 ? data.conversionFunnel[0].count : 1;
      const conversionFunnel = (data.conversionFunnel || []).map((item, idx) => ({
        stage: item.stage,
        count: item.count,
        stepRate: item.stepRate,
        totalRate: item.totalRate,
        barStyle: `width: ${(item.count / maxFunnel) * 100}%`,
        isFirst: idx === 0
      }));
      
      // Lost and Granero stats
      const lostGraneroStats = data.lostGraneroStats || {};
      
      this.summaryStats = {
        totalLeads: data.totalLeads,
        newCount,
        enrolledCount,
        interviewCount,
        lostCount,
        newRate: data.totalLeads > 0 ? (newCount * 100 / data.totalLeads).toFixed(1) : 0,
        enrolledRate: data.totalLeads > 0 ? (enrolledCount * 100 / data.totalLeads).toFixed(1) : 0,
        interviewRate: data.totalLeads > 0 ? (interviewCount * 100 / data.totalLeads).toFixed(1) : 0,
        leadsByStatus,
        leadsByStage,
        leadsByGrade,
        weeklyLeads,
        weeklyLabels,
        weeklyMax,
        weeklyMid,
        lastContactDist,
        openConvs: data.openConvs,
        closedConvs: data.closedConvs,
        unlinkedConvs: data.unlinkedConvs,
        totalConvs: data.openConvs + data.closedConvs,
        convByStatus,
        convBySource,
        weeklyConvs,
        weeklyConvLabels,
        conversionFunnel,
        lostGraneroStats,
        leadsByYearStatus: this.processLeadsByYearStatus(data.leadsByYearStatus || [])
      };
    } catch (err) {
      this.showToast('Error', 'Could not load dashboard statistics', 'error');
    } finally {
      this.isLoadingSummary = false;
    }
  }

  // Process leads by year and status into table format
  processLeadsByYearStatus(rawData) {
    if (!rawData || rawData.length === 0) return { years: [], statuses: [], rows: [], hasData: false };
    
    // Get unique years and statuses
    const yearsSet = new Set();
    const statusesSet = new Set();
    const dataMap = {};
    
    rawData.forEach(item => {
      const year = item.year || 'Unknown';
      const status = item.status || 'Unknown';
      yearsSet.add(year);
      statusesSet.add(status);
      if (!dataMap[year]) dataMap[year] = { total: 0 };
      dataMap[year][status] = item.count;
      dataMap[year].total += item.count;
    });
    
    const years = Array.from(yearsSet).sort().reverse();
    const statuses = Array.from(statusesSet).sort();
    
    // Build rows with year data
    const rows = years.map(year => {
      const yearData = dataMap[year] || {};
      const statusCounts = statuses.map(status => ({
        status,
        count: yearData[status] || 0
      }));
      return {
        year,
        total: yearData.total || 0,
        statusCounts
      };
    });
    
    return { years, statuses, rows, hasData: rows.length > 0 };
  }

  async loadInboxCounts() {
    try {
      const result = await getInboxCounts();
      const parsed = JSON.parse(result);
      this.newLeadCount = parsed.newLeadCount || 0;
      this.unreadConvCount = parsed.unreadConvCount || 0;
    } catch (err) {
      // Silently ignore count errors
    }
  }

  async loadSchoolOptions() {
    try {
      const result = await getAccessibleSchools();
      this.schoolOptions = JSON.parse(result);
    } catch (err) {
      this.schoolOptions = [{ value: '', label: 'All Schools' }];
    }
  }

  handleSchoolFilterChange(event) {
    this.selectedSchoolId = event.detail.value;
    this.loadLeads();
  }

  handleYearFilterChange(event) {
    this.selectedYear = event.detail.value;
    this.loadLeads();
  }

  handleStatusFilterChange(event) {
    this.selectedStatus = event.detail.value;
    this.loadLeads();
  }

  toggleLegendPopup() {
    this.showLegendPopup = !this.showLegendPopup;
  }

  closeLegendPopup() {
    this.showLegendPopup = false;
  }

  // Search handlers
  handleSearchChange(event) {
    this.searchTerm = event.target.value;
  }

  handleSearchKeyUp(event) {
    // Trigger search on Enter key
    if (event.keyCode === 13) {
      this.loadLeads();
    }
  }

  handleSearchClick() {
    this.loadLeads();
  }

  handleClearSearch() {
    this.searchTerm = '';
    this.loadLeads();
  }

  // New Lead - opens the Screen Flow
  handleNewLead() {
    // Navigate to the Screen Flow for creating new leads
    this[NavigationMixin.Navigate]({
      type: 'standard__webPage',
      attributes: {
        url: '/flow/Lead_Proceso_nueva_creacion'
      }
    });
  }

  // Returns CSS class for row coloring based on lead status and age
  getRowColorClass(lead) {
    const status = lead.Status || '';
    const convCount = lead.ConversationCount || 0;
    
    // Calculate days since creation
    let daysSinceCreation = 999;
    if (lead.CreatedDate) {
      const created = new Date(lead.CreatedDate);
      const now = new Date();
      daysSinceCreation = Math.floor((now - created) / (1000 * 60 * 60 * 24));
    }
    
    // Enrollment/Pre-Enrollment (Convertido) - green
    if (['Convertido', 'Pre-Enrollment'].includes(status)) {
      return 'row-won';
    }
    // Perdido - gray
    if (['Perdido'].includes(status)) {
      return 'row-lost';
    }
    // Granero - slate
    if (['Granero'].includes(status)) {
      return 'row-granero';
    }
    // New without call (4-6 days) - orange
    if (status === 'New' && convCount === 0 && daysSinceCreation >= 4 && daysSinceCreation <= 6) {
      return 'row-new-nocall';
    }
    // New (0-3 days) - blue
    if (status === 'New' && daysSinceCreation <= 3) {
      return 'row-new';
    }
    return '';
  }

  async loadLeads(append = false) {
    if (append) {
      this.isLoadingMoreLeads = true;
    } else {
      this.isLoadingLeads = true;
      this.currentPage = 1;
    }
    try {
      const offsetVal = append ? this.leads.length : 0;
      const result = await getNewLeadsPaginated({ 
        schoolId: this.selectedSchoolId || '',
        yearFilter: this.selectedYear || '',
        statusFilter: this.selectedStatus || '',
        searchTerm: this.searchTerm || '',
        limitSize: this.pageSize,
        offsetVal: offsetVal
      });
      const parsed = JSON.parse(result);
      
      // Handle new paginated response format
      const leadsData = parsed.leads || parsed;  // Fallback for backwards compatibility
      this.totalLeadsCount = parsed.totalCount || leadsData.length;
      
      // Format LastContactFormatted as "date (count)" and calculate row color
      const formattedLeads = leadsData.map(lead => {
        let lastContactFormatted = '-';
        if (lead.LastContactDate) {
          const d = new Date(lead.LastContactDate);
          const dateStr = d.toLocaleDateString('es-ES', { day: '2-digit', month: '2-digit', year: 'numeric' });
          lastContactFormatted = lead.ConversationCount > 0 
            ? dateStr + ' (' + lead.ConversationCount + ')'
            : dateStr;
        }
        // Calculate row color class based on status and days
        const rowColorClass = this.getRowColorClass(lead);
        // NoRelated flag to disable the button when no related records
        const NoRelated = !lead.SiblingsDisplay || lead.SiblingsDisplay === '';
        return { ...lead, LastContactFormatted: lastContactFormatted, rowColorClass, NoRelated };
      });
      
      if (append) {
        this.leads = [...this.leads, ...formattedLeads];
      } else {
        this.leads = formattedLeads;
      }
    } catch (err) {
      if (!append) this.leads = [];
      this.dispatchEvent(new ShowToastEvent({
        title: 'Error cargando leads',
        message: err.body?.message || err.message || 'Error desconocido',
        variant: 'error'
      }));
    } finally {
      this.isLoadingLeads = false;
      this.isLoadingMoreLeads = false;
    }
  }
  
  get hasMoreLeads() {
    return this.leads.length < this.totalLeadsCount;
  }
  
  get leadsShownText() {
    return `Showing ${this.leads.length} of ${this.totalLeadsCount} leads`;
  }
  
  handleLoadMoreLeads() {
    if (this.hasMoreLeads && !this.isLoadingMoreLeads) {
      this.currentPage++;
      this.loadLeads(true);
    }
  }

  handleLeadRowAction(event) {
  const actionName = event.detail.action.name;
  const row = event.detail.row;
  if (actionName === 'view') {
  this[NavigationMixin.Navigate]({
  type: 'standard__recordPage',
  attributes: { recordId: row.Id, objectApiName: 'Lead', actionName: 'view' }
  });
  } else if (actionName === 'viewConversations') {
  // Open conversations modal for this lead
  this.leadConvModalRecordId = row.Id;
  this.leadConvModalName = row.Name || row.Full_Name_formula__c || 'Lead';
  this.showLeadConversationsModal = true;
  } else if (actionName === 'updateStatus') {
  // Open Lead_Update_stage flow in popup modal
  this.flowLeadId = row.Id;
  this.showFlowModal = true;
  } else if (actionName === 'viewLead') {
  // Open Lead record in new tab
  window.open('/' + row.Id, '_blank');
  } else if (actionName === 'viewRelated') {
  // Show related records modal (siblings/duplicates/contacts)
  this.relatedModalTitle = 'Related Records for ' + row.Name;
  this.relatedRecords = row.RelatedRecords || [];
  this.showRelatedModal = true;
  }
  }

  // Close lead conversations modal
  handleCloseLeadConvModal() {
    this.showLeadConversationsModal = false;
    this.leadConvModalRecordId = null;
  }
  
  // Close related records modal
  handleCloseRelatedModal() {
    this.showRelatedModal = false;
    this.relatedRecords = [];
  }
  
  // Navigate to related record from modal - open in new tab
  handleViewRelatedRecord(event) {
    const recordId = event.target.dataset.id;
    // Open in new tab using window.open
    window.open('/' + recordId, '_blank');
  }
  
  // Close flow modal
  handleCloseFlowModal() {
    this.showFlowModal = false;
    this.flowLeadId = null;
  }
  
  // Handle flow status change (finish/error)
  handleFlowStatusChange(event) {
    if (event.detail.status === 'FINISHED' || event.detail.status === 'FINISHED_SCREEN') {
      this.showFlowModal = false;
      this.flowLeadId = null;
      // Refresh leads to show updated status
      this.loadLeads();
    }
  }

  async loadConversations() {
        this.isLoading = true;
        try {
            const result = await getConversations({
                filterStatus: this.filterStatus || null,
                searchTerm: this.searchTerm || null,
                schoolId: this.convSchoolFilter || null
            });
            const parsed = JSON.parse(result);
            this.conversations = parsed.map(conv => ({
                ...conv,
                sourceIcon: this.getSourceIcon(conv.source),
                sourceLabel: conv.source || 'web',
                statusClass: conv.status === 'Abierta' ? 'slds-badge_inverse'
                    : conv.status === 'Cerrada' ? 'slds-badge' : 'slds-badge',
                statusStyle: conv.status === 'Cerrada' ? 'font-size:0.65rem; background-color:#e0e0e0; color:#666;' : 'font-size:0.65rem;',
                recordTypeIcon: conv.linkedRecordType === 'Lead' ? 'standard:lead'
                    : conv.linkedRecordType === 'Contact' ? 'standard:contact'
                    : 'standard:person_account',
                isLinked: conv.linkedRecordType !== 'Unmatched',
                isUnlinked: conv.linkedRecordType === 'Unmatched',
                formattedDate: this.formatDate(conv.lastMessageDate),
                unreadBadge: conv.unreadCount > 0 ? String(conv.unreadCount) : null
            }));
            this.error = null;
        } catch (err) {
            this.error = err.body?.message || 'Error cargando conversaciones';
        } finally {
            this.isLoading = false;
        }
    }

    getSourceIcon(source) {
        const map = {
            'whatsapp': 'utility:comments',
            'facebook': 'utility:socialshare',
            'instagram': 'utility:photo',
            'email': 'utility:email',
            'widget': 'utility:chat'
        };
        return map[source] || 'utility:chat';
    }

    formatDate(dateStr) {
        if (!dateStr) return '';
        const d = new Date(dateStr);
        const now = new Date();
        const time = d.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' });
        const isToday = d.toDateString() === now.toDateString();
        if (isToday) {
            return time;
        }
        const date = d.toLocaleDateString('es-ES', { day: '2-digit', month: 'short' });
        return date + ' ' + time;
    }

    // ─── SELECT CONVERSATION (group) ─────────────────────────────
    async handleSelectConversation(event) {
        const groupKey = event.currentTarget.dataset.groupkey || event.currentTarget.dataset.id;
        this.selectedConv = this.conversations.find(c => c.groupKey === groupKey || c.id === groupKey);
        if (!this.selectedConv) return;

        // Load messages from ALL conversations in the group
        this.isLoadingMessages = true;
        this.messages = [];
        const convIds = this.selectedConv.conversationIds || [this.selectedConv.id];
        try {
            const result = await getGroupedConversationMessages({
                conversationRecordIdsJson: JSON.stringify(convIds)
            });
            this.messages = JSON.parse(result).map(msg => ({
                ...msg,
                isVisitor: msg.senderType === 'visitor',
                isAgent: msg.senderType === 'agent',
                bubbleClass: msg.senderType === 'visitor' ? 'message-visitor' : 'message-agent',
                innerClass: msg.senderType === 'visitor' ? 'bubble-visitor' : 'bubble-agent',
                formattedTime: this.formatDate(msg.createdAt),
                hasFile: !!msg.fileUrl,
                subject: msg.subject || null,
                isPushed: msg.isPushed,
                isTrigger: msg.isTrigger,
                isMissed: msg.isMissed
            }));
        } catch (err) {
            this.showToast('Error', 'Could not load messages', 'error');
        } finally {
            this.isLoadingMessages = false;
        }

        // Mark all conversations in group as read
        if (this.selectedConv.unreadCount > 0) {
            try {
                await markConversationAsRead({ conversationIdsJson: JSON.stringify(convIds) });
                this.selectedConv = { ...this.selectedConv, unreadCount: 0, unreadBadge: null };
                this.conversations = this.conversations.map(c =>
                    c.groupKey === this.selectedConv.groupKey ? { ...c, unreadCount: 0, unreadBadge: null } : c
                );
            } catch (err) {
                console.error('Error marking as read:', err);
            }
        }

        // Start 24h window timer for WhatsApp
        this.startWindowTimer();

        // Scroll to bottom after render
        // eslint-disable-next-line @lwc/lwc/no-async-operation
        setTimeout(() => { this.scrollChatToBottom(); }, 100);
    }

    // ─── 24H WINDOW TIMER ────────────────────────────��─────────
    startWindowTimer() {
        this.clearWindowTimer();
        this.windowTimerText = '';
        this.isWindowExpired = false;

        if (!this.selectedConv) return;
        // Only for WhatsApp conversations
        if (this.selectedConv.source !== 'whatsapp') return;

        const lastVisitor = this.selectedConv.lastVisitorMessageDate || this.selectedConv.lastMessageDate;
        if (!lastVisitor) {
            // No dates at all — cannot compute window, do not block
            return;
        }

        this.updateWindowTimer();
        // eslint-disable-next-line @lwc/lwc/no-async-operation
        this._timerInterval = setInterval(() => { this.updateWindowTimer(); }, 60000);
    }

    updateWindowTimer() {
        const dateStr = this.selectedConv?.lastVisitorMessageDate || this.selectedConv?.lastMessageDate;
        if (!dateStr) return;
        const lastMsg = new Date(dateStr);
        const now = new Date();
        const diffMs = (lastMsg.getTime() + 24 * 60 * 60 * 1000) - now.getTime();

        if (diffMs <= 0) {
            this.isWindowExpired = true;
            this.windowTimerText = 'Window expired';
            this.clearWindowTimer();
            return;
        }

        const hours = Math.floor(diffMs / (1000 * 60 * 60));
        const minutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
        this.windowTimerText = hours + 'h ' + minutes + 'm remaining';
        this.isWindowExpired = false;
    }

    clearWindowTimer() {
        if (this._timerInterval) {
            clearInterval(this._timerInterval);
            this._timerInterval = null;
        }
    }

    scrollChatToBottom() {
        const chatDiv = this.template.querySelector('.chat-messages');
        if (chatDiv) chatDiv.scrollTop = chatDiv.scrollHeight;
    }

    // ─── NAVIGATION ─────────────────────────────────────────────
    handleNavigateToRecord() {
        if (!this.selectedConv?.linkedRecordId) return;
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: { recordId: this.selectedConv.linkedRecordId, actionName: 'view' }
        });
    }

    handleOpenInBrevo() {
        if (this.selectedConv?.threadLink) {
            window.open(this.selectedConv.threadLink, '_blank');
        } else {
            window.open('https://conversations-app.brevo.com/', '_blank');
        }
    }

    handleOpenBrevoApp() {
        window.open('https://conversations-app.brevo.com/', '_blank');
    }

    handleCreateLead() {
        const defaults = {};
        if (this.selectedConv?.visitorEmail) defaults.Email = this.selectedConv.visitorEmail;
        if (this.selectedConv?.visitorPhone) defaults.Phone = this.selectedConv.visitorPhone;
        if (this.selectedConv?.visitorName) {
            const parts = this.selectedConv.visitorName.trim().split(/\s+/);
            defaults.FirstName = parts[0] || '';
            defaults.LastName = parts.slice(1).join(' ') || parts[0] || '';
        }
        if (this.selectedConv?.visitorId) defaults.Brevo_Visitor_Id__c = this.selectedConv.visitorId;

        this[NavigationMixin.Navigate]({
            type: 'standard__objectPage',
            attributes: { objectApiName: 'Lead', actionName: 'new' },
            state: { defaultFieldValues: Object.entries(defaults).map(([k,v]) => `${k}=${encodeURIComponent(v)}`).join(',') }
        });
    }

    handleCreateContact() {
        const defaults = {};
        if (this.selectedConv?.visitorEmail) defaults.Email = this.selectedConv.visitorEmail;
        if (this.selectedConv?.visitorPhone) defaults.Phone = this.selectedConv.visitorPhone;
        if (this.selectedConv?.visitorName) {
            const parts = this.selectedConv.visitorName.trim().split(/\s+/);
            defaults.FirstName = parts[0] || '';
            defaults.LastName = parts.slice(1).join(' ') || parts[0] || '';
        }
        if (this.selectedConv?.visitorId) defaults.Brevo_Visitor_Id__c = this.selectedConv.visitorId;

        this[NavigationMixin.Navigate]({
            type: 'standard__objectPage',
            attributes: { objectApiName: 'Contact', actionName: 'new' },
            state: { defaultFieldValues: Object.entries(defaults).map(([k,v]) => `${k}=${encodeURIComponent(v)}`).join(',') }
        });
    }

    // ─── LINK TO RECORD ─────────────────────────────────────────
    handleOpenLinkModal() {
        this.linkRecordId = '';
        this.showLinkModal = true;
    }
    handleCloseLinkModal() { this.showLinkModal = false; }
    handleLinkRecordIdChange(event) { this.linkRecordId = event.detail.value || event.target.value; }

    async handleLinkRecord() {
        if (!this.linkRecordId || !this.selectedConv) return;
        this.isLinking = true;
        try {
            const convIds = this.selectedConv.conversationIds || [this.selectedConv.id];
            await linkConversationToRecord({
                conversationIdsJson: JSON.stringify(convIds),
                recordId: this.linkRecordId
            });
            this.showToast('Linked', 'Conversation linked successfully', 'success');
            this.showLinkModal = false;
            this.loadConversations();
        } catch (err) {
            this.showToast('Error', err.body?.message || 'Could not link', 'error');
        } finally {
            this.isLinking = false;
        }
    }

    // ─── FILE ATTACHMENT ────────────────��───────────────────────
    handleAttachClick() {
        const fileInput = this.template.querySelector('input[data-id="fileInput"]');
        if (fileInput) fileInput.click();
    }

    handleFileSelected(event) {
        const file = event.target.files[0];
        if (!file) return;

        // Max 20MB
        if (file.size > 20 * 1024 * 1024) {
            this.showToast('Error', 'File cannot exceed 20 MB', 'error');
            event.target.value = '';
            return;
        }

        const reader = new FileReader();
        reader.onload = () => {
            // result is "data:<mime>;base64,<data>" — extract just the base64 part
            const base64 = reader.result.split(',')[1];
            this.pendingFile = {
                name: file.name,
                base64: base64,
                size: file.size,
                type: file.type
            };
        };
        reader.readAsDataURL(file);
        event.target.value = '';
    }

    handleRemoveFile() {
        this.pendingFile = null;
    }

    get hasPendingFile() {
        return this.pendingFile != null;
    }

    get pendingFileLabel() {
        if (!this.pendingFile) return '';
        const kb = Math.round(this.pendingFile.size / 1024);
        return this.pendingFile.name + ' (' + kb + ' KB)';
    }

    // ─── CONVERSATION SEND ──────────────────────────────────────
    async handleSendMessage() {
        const hasText = this.messageText?.trim();
        const hasFile = this.pendingFile != null;
        if ((!hasText && !hasFile) || !this.selectedConv?.visitorId) return;
        this.isSending = true;
        const sentText = this.messageText || '';
        const sentFile = this.pendingFile;
        try {
            if (sentFile) {
                await sendMessageWithFile({
                    visitorId: this.selectedConv.visitorId,
                    text: sentText,
                    agentName: null,
                    fileBase64: sentFile.base64,
                    fileName: sentFile.name
                });
            } else {
                await sendMessage({
                    visitorId: this.selectedConv.visitorId,
                    text: sentText,
                    agentName: null
                });
            }
            // Add optimistic message to chat
            const optimisticText = sentFile ? (sentText || sentFile.name) : sentText;
            this.messages = [...this.messages, {
                id: 'temp-' + Date.now(),
                senderType: 'agent',
                senderName: 'Agente',
                text: optimisticText,
                createdAt: new Date().toISOString(),
                isVisitor: false,
                isAgent: true,
                bubbleClass: 'message-agent',
                innerClass: 'bubble-agent',
                formattedTime: new Date().toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' }),
                hasFile: !!sentFile,
                fileName: sentFile ? sentFile.name : null
            }];
            this.messageText = '';
            this.pendingFile = null;
            // Optimistically change status to 'Resuelta' (server also does it)
            if (this.selectedConv.status === 'Abierta') {
                this.selectedConv = { ...this.selectedConv, status: 'Resuelta' };
                this.conversations = this.conversations.map(c =>
                    c.groupKey === this.selectedConv.groupKey ? { ...c, status: 'Resuelta', statusStyle: 'font-size:0.65rem;' } : c
                );
            }
            // eslint-disable-next-line @lwc/lwc/no-async-operation
            setTimeout(() => { this.scrollChatToBottom(); }, 50);
        } catch (err) {
            this.showToast('Error', err.body?.message || 'Could not send the message', 'error');
        } finally {
            this.isSending = false;
        }
    }

    // ─── EMAIL MODAL ────────────────────────────────────────────
    handleOpenEmailModal() {
        this.emailTo = this.selectedConv?.visitorEmail || '';
        this.emailSubject = '';
        this.emailBody = '';
        this.emailTemplateId = null;
        this.emailFile = null;
        this.showEmailModal = true;
        this.loadEmailTemplates();
    }
    handleCloseEmailModal() { this.showEmailModal = false; }
    handleEmailToChange(event) { this.emailTo = event.detail.value || event.target.value; }
    handleEmailSubjectChange(event) { this.emailSubject = event.detail.value || event.target.value; }
    handleEmailBodyChange(event) { this.emailBody = event.detail.value; }

    get emailRichTextFormats() {
        return ['font', 'size', 'bold', 'italic', 'underline', 'strike', 'list', 'indent', 'align', 'link', 'clean', 'table', 'header'];
    }

    async loadEmailTemplates() {
        try {
            const acctId = this.selectedConv?.linkedAccountId || null;
            const result = await getEmailTemplates({ accountId: acctId });
            this._emailTemplatesData = JSON.parse(result);
            this.emailTemplateOptions = [
                { label: '-- Sin plantilla --', value: '' },
                ...this._emailTemplatesData.map(t => ({
                    label: (t.folder ? t.folder + ' / ' : '') + t.name,
                    value: t.id
                }))
            ];
        } catch (err) {
            this._emailTemplatesData = [];
            this.emailTemplateOptions = [];
        }
    }

    handleEmailTemplateChange(event) {
        this.emailTemplateId = event.detail.value;
        if (!this.emailTemplateId) return;
        const tmpl = this._emailTemplatesData.find(t => t.id === this.emailTemplateId);
        if (tmpl) {
            if (tmpl.subject) this.emailSubject = tmpl.subject;
            this.emailBody = tmpl.htmlBody || tmpl.textBody || '';
        }
    }

    // Email file attachment
    handleEmailAttachClick() {
        const input = this.template.querySelector('input[data-id="emailFileInput"]');
        if (input) input.click();
    }

    handleEmailFileSelected(event) {
        const file = event.target.files[0];
        if (!file) return;
        if (file.size > 20 * 1024 * 1024) {
            this.showToast('Error', 'File cannot exceed 20 MB', 'error');
            event.target.value = '';
            return;
        }
        const reader = new FileReader();
        reader.onload = () => {
            this.emailFile = { name: file.name, base64: reader.result.split(',')[1], size: file.size };
        };
        reader.readAsDataURL(file);
        event.target.value = '';
    }

    handleRemoveEmailFile() { this.emailFile = null; }
    get hasEmailFile() { return this.emailFile != null; }
    get emailFileLabel() {
        if (!this.emailFile) return '';
        return this.emailFile.name + ' (' + Math.round(this.emailFile.size / 1024) + ' KB)';
    }

    async handleSendEmail() {
        if (!this.emailTo || !this.emailSubject) return;
        this.isSendingEmail = true;
        try {
            if (this.emailFile) {
                await sendTransactionalEmailWithAttachment({
                    toEmail: this.emailTo,
                    toName: this.selectedConv?.displayName || '',
                    subject: this.emailSubject,
                    htmlContent: this.emailBody || '<p></p>',
                    fileBase64: this.emailFile.base64,
                    fileName: this.emailFile.name
                });
            } else {
                await sendTransactionalEmail({
                    toEmail: this.emailTo,
                    toName: this.selectedConv?.displayName || '',
                    subject: this.emailSubject,
                    htmlContent: this.emailBody || '<p></p>'
                });
            }
            this.showToast('Email Sent', 'Email sent successfully via Brevo', 'success');
            this.showEmailModal = false;
        } catch (err) {
            this.showToast('Error', err.body?.message || 'Could not send the email', 'error');
        } finally {
            this.isSendingEmail = false;
        }
    }

    // ─── WHATSAPP MODAL ─────────────────────────────────────────
    async handleOpenWhatsAppModal() {
        this.waPhone = this.selectedConv?.visitorPhone || '';
        this.waTemplateId = null;
        this.showWhatsAppModal = true;
        this.loadWhatsAppTemplates();
    }
    handleCloseWhatsAppModal() { this.showWhatsAppModal = false; }
    handleWaPhoneChange(event) { this.waPhone = event.detail.value || event.target.value; }
    handleWaTemplateChange(event) { this.waTemplateId = event.detail.value; }
    get waTemplatePreview() {
        if (!this.waTemplateId || !this._waTemplateDataMap[this.waTemplateId]) return '';
        return this._waTemplateDataMap[this.waTemplateId].bodyText;
    }
    get hasWaTemplatePreview() { return !!this.waTemplatePreview; }

    async loadWhatsAppTemplates() {
        this.waTemplatesLoading = true;
        try {
            const result = await getWhatsAppTemplates();
            const parsed = JSON.parse(result);
            const templates = parsed.templates || parsed || [];
            const approved = templates.filter(t => t.status === 'approved');
            const dataMap = {};
            this.waTemplates = approved.map(t => {
                const val = String(t.id);
                let bodyText = t.bodyText || t.body || '';
                if (!bodyText && t.components && Array.isArray(t.components)) {
                    const bodyComp = t.components.find(c => c.type === 'BODY' || c.type === 'body');
                    if (bodyComp) bodyText = bodyComp.text || '';
                }
                if (!bodyText && t.htmlBody) bodyText = t.htmlBody;
                dataMap[val] = { bodyText: bodyText };
                return {
                    label: t.name + (t.language ? ' (' + t.language + ')' : ''),
                    value: val
                };
            });
            this._waTemplateDataMap = dataMap;
        } catch (err) {
            this.waTemplates = [];
        } finally {
            this.waTemplatesLoading = false;
        }
    }

    async handleSendWhatsApp() {
        if (!this.waPhone || !this.waTemplateId) return;
        this.isSendingWa = true;
        try {
            await sendWhatsAppMessage({
                phone: this.waPhone,
                templateId: parseInt(this.waTemplateId, 10),
                params: null
            });
            this.showToast('WhatsApp enviado', 'Mensaje de WhatsApp enviado correctamente', 'success');
            this.showWhatsAppModal = false;
        } catch (err) {
            this.showToast('Error', err.body?.message || 'No se pudo enviar el WhatsApp', 'error');
        } finally {
            this.isSendingWa = false;
        }
    }

    // ─── SMS MODAL ───────────────────────────���──────────────────
    handleOpenSmsModal() {
        this.smsPhone = this.selectedConv?.visitorPhone || '';
        this.smsContent = '';
        this.showSmsModal = true;
    }
    handleCloseSmsModal() { this.showSmsModal = false; }
    handleSmsPhoneChange(event) { this.smsPhone = event.detail.value || event.target.value; }
    handleSmsContentChange(event) { this.smsContent = event.target.value; }

    async handleSendSms() {
        if (!this.smsPhone || !this.smsContent) return;
        this.isSendingSms = true;
        try {
            await sendTransactionalSMS({ phone: this.smsPhone, content: this.smsContent });
            this.showToast('SMS enviado', 'SMS enviado correctamente via Brevo', 'success');
            this.showSmsModal = false;
        } catch (err) {
            this.showToast('Error', err.body?.message || 'No se pudo enviar el SMS', 'error');
        } finally {
            this.isSendingSms = false;
        }
    }

    // ─── DIAGNOSTIC MODAL ──────────────────────��───────────────
    handleOpenDiagnostic() {
        this.diagPhone = '';
        this.diagEmail = '';
        this.diagResult = null;
        this.showDiagnosticModal = true;
    }
    handleCloseDiagnostic() { this.showDiagnosticModal = false; }
    handleDiagPhoneChange(event) { this.diagPhone = event.detail.value; }
    handleDiagEmailChange(event) { this.diagEmail = event.detail.value; }

    async handleRunDiagnostic() {
        if (!this.diagPhone && !this.diagEmail) {
            this.showToast('Error', 'Introduce un telefono o email para diagnosticar', 'error');
            return;
        }
        this.isDiagRunning = true;
        this.diagResult = null;
        try {
            const result = await webhookDiagnostic({
                testPhone: this.diagPhone || null,
                testEmail: this.diagEmail || null
            });
            this.diagResult = JSON.parse(result);
        } catch (err) {
            this.showToast('Error', err.body?.message || 'Error ejecutando diagnostico', 'error');
        } finally {
            this.isDiagRunning = false;
        }
    }

    get diagResultJson() {
        return this.diagResult ? JSON.stringify(this.diagResult, null, 2) : '';
    }
    get diagHasResult() { return !!this.diagResult; }
    get diagFoundSomething() {
        if (!this.diagResult) return false;
        return (this.diagResult.phoneLeadMatchCount > 0 || this.diagResult.phoneContactMatchCount > 0
            || this.diagResult.emailLeadMatchCount > 0 || this.diagResult.emailContactMatchCount > 0);
    }

    // ─── EMOJI PICKER ──────────────────────────────────────────
    handleToggleEmoji() {
        this.showEmojiPicker = !this.showEmojiPicker;
        this.showSavedResponses = false;
    }

    handleSelectEmoji(event) {
        const emoji = event.currentTarget.dataset.emoji;
        this.messageText = (this.messageText || '') + emoji;
        this.showEmojiPicker = false;
    }

    // ─── SAVED RESPONSES ──────────��────────────────────────────
    async loadSavedResponses() {
        try {
            const result = await getSavedResponses();
            this.savedResponses = JSON.parse(result);
        } catch (err) {
            this.savedResponses = [];
        }
    }

    handleToggleSavedResponses() {
        this.showSavedResponses = !this.showSavedResponses;
        this.showEmojiPicker = false;
        this.savedResponsesFilter = '';
    }

    handleSavedResponseFilter(event) {
        this.savedResponsesFilter = event.target.value;
    }

    handleSelectSavedResponse(event) {
        const responseId = event.currentTarget.dataset.id;
        const response = this.savedResponses.find(r => r.id === responseId);
        if (response) {
            this.messageText = (this.messageText || '') + response.text;
        }
        this.showSavedResponses = false;
    }

    get filteredSavedResponses() {
        if (!this.savedResponsesFilter) return this.savedResponses;
        const term = this.savedResponsesFilter.toLowerCase();
        return this.savedResponses.filter(r =>
            r.name.toLowerCase().includes(term) || (r.text || '').toLowerCase().includes(term)
        );
    }

    get hasSavedResponses() { return this.savedResponses.length > 0; }

    // ─── CLOSE CONVERSATION GROUP ────────────────────────────────
    async handleCloseConversation() {
        if (!this.selectedConv) return;
        this.isClosing = true;
        try {
            const convIds = this.selectedConv.conversationIds || [this.selectedConv.id];
            await closeConversation({ conversationRecordIdsJson: JSON.stringify(convIds) });
            this.selectedConv = { ...this.selectedConv, status: 'Cerrada' };
            this.conversations = this.conversations.map(c =>
                c.groupKey === this.selectedConv.groupKey ? { ...c, status: 'Cerrada', statusStyle: 'font-size:0.65rem; background-color:#e0e0e0; color:#666;' } : c
            );
            this.showToast('Cerrada', 'Conversacion cerrada correctamente', 'success');
        } catch (err) {
            this.showToast('Error', err.body?.message || 'No se pudo cerrar', 'error');
        } finally {
            this.isClosing = false;
        }
    }

    get canCloseConversation() {
        return this.selectedConv && this.selectedConv.status !== 'Cerrada' && !this.isClosing;
    }

    get isConversationClosed() {
        return this.selectedConv?.status === 'Cerrada';
    }

    // ─── ACCOUNT USAGE ─────────────────────────────────────────
    async handleOpenUsage() {
        this.showUsageModal = true;
        this.isLoadingUsage = true;
        this.usageData = null;
        try {
            const result = await getAccountUsage();
            this.usageData = JSON.parse(result);
        } catch (err) {
            this.showToast('Error', err.body?.message || 'No se pudo obtener el consumo', 'error');
        } finally {
            this.isLoadingUsage = false;
        }
    }

    handleCloseUsage() { this.showUsageModal = false; }

    get usagePlans() {
        if (!this.usageData?.plan) return [];
        return this.usageData.plan.map(p => ({
            ...p,
            label: p.type + ' - ' + p.creditsType,
            creditsUsed: (p.credits - (p.remainingCredits || 0)),
            percentUsed: p.credits > 0 ? Math.round(((p.credits - (p.remainingCredits || 0)) / p.credits) * 100) : 0,
            barStyle: 'height:8px; border-radius:4px; background:#0176d3; width:' + (p.credits > 0 ? Math.round(((p.credits - (p.remainingCredits || 0)) / p.credits) * 100) : 0) + '%;'
        }));
    }

    get hasUsagePlans() { return this.usagePlans.length > 0; }

    get usageCompanyName() { return this.usageData?.companyName || ''; }

    // ─── GENERAL HANDLERS ─────────────────���─────────────────────
    handleRefresh() {
        const previousGroupKey = this.selectedConv?.groupKey;
        this.loadConversations().then(() => {
            if (previousGroupKey) {
                const refreshed = this.conversations.find(c => c.groupKey === previousGroupKey);
                if (refreshed) {
                    this.handleSelectConversation({ currentTarget: { dataset: { groupkey: refreshed.groupKey } } });
                }
            }
        });
    }

    handleSearchChange(event) {
        this.searchTerm = event.target.value;
        this.loadConversations();
    }

    handleStatusFilter(event) {
        this.filterStatus = event.detail.value;
        this.loadConversations();
    }

    handleConvSchoolFilterChange(event) {
        this.convSchoolFilter = event.detail.value;
        this.loadConversations();
    }

    handleMessageInput(event) { this.messageText = event.target.value; }
    handleKeyPress(event) {
        if (event.key === 'Enter' && !event.shiftKey) {
            event.preventDefault();
            this.handleSendMessage();
        }
    }

    subscribeToPlatformEvents() {
        const messageCallback = () => {
            const previousGroupKey = this.selectedConv?.groupKey;
            this.loadConversations().then(() => {
                if (previousGroupKey) {
                    const refreshed = this.conversations.find(c => c.groupKey === previousGroupKey);
                    if (refreshed) {
                        this.handleSelectConversation({ currentTarget: { dataset: { groupkey: refreshed.groupKey } } });
                    }
                }
            });
        };
        subscribe(CHANNEL, -1, messageCallback).then(response => {
            this.subscription = response;
        });
        onError(error => { console.error('EMP API error:', error); });
    }

    // ─── COMPUTED ───────────────────────────────────────────────
    get hasConversations() { return this.conversations.length > 0; }
    get noConversations() { return !this.hasConversations && !this.isLoading; }
    get hasSelectedConv() { return !!this.selectedConv; }
    get noSelectedConv() { return !this.selectedConv; }
    get hasMessages() { return this.messages.length > 0; }
    get noMessages() { return !this.hasMessages && !this.isLoadingMessages; }

    get selectedIsLinked() { return this.selectedConv?.isLinked; }
    get selectedIsUnlinked() { return this.selectedConv?.isUnlinked; }
    get selectedHasVisitorId() { return !!this.selectedConv?.visitorId; }
    get selectedNoVisitorId() { return !this.selectedHasVisitorId; }
    get selectedHasEmail() { return !!this.selectedConv?.visitorEmail; }
    get selectedHasPhone() { return !!this.selectedConv?.visitorPhone; }
    get selectedNoEmail() { return !this.selectedHasEmail; }
    get selectedNoPhone() { return !this.selectedHasPhone; }

    // ─── CROSS-CHANNEL ALERT ──────────────────────────────────
    get hasOtherChannels() {
        return this.selectedConv?.otherChannelGroups?.length > 0;
    }

    get otherChannelAlerts() {
        if (!this.selectedConv?.otherChannelGroups) return [];
        return this.selectedConv.otherChannelGroups.map(ch => ({
            groupKey: ch.groupKey,
            source: ch.source,
            status: ch.status,
            unreadCount: ch.unreadCount || 0,
            label: ch.source + (ch.unreadCount > 0 ? ' (' + ch.unreadCount + ' sin leer)' : ''),
            sourceIcon: this.getSourceIcon(ch.source)
        }));
    }

    handleNavigateToOtherChannel(event) {
        const targetGroupKey = event.currentTarget.dataset.groupkey;
        const target = this.conversations.find(c => c.groupKey === targetGroupKey);
        if (target) {
            this.handleSelectConversation({ currentTarget: { dataset: { groupkey: targetGroupKey } } });
        } else {
            // If the target group is not in the current filter, reload with 'Todas' and navigate
            this.filterStatus = 'Todas';
            this.loadConversations().then(() => {
                const found = this.conversations.find(c => c.groupKey === targetGroupKey);
                if (found) {
                    this.handleSelectConversation({ currentTarget: { dataset: { groupkey: targetGroupKey } } });
                }
            });
        }
    }

    get windowTimerStyle() {
        return this.isWindowExpired
            ? 'background:#fde8e8; color:#b91c1c;'
            : 'background:#fef9c3; color:#854d0e;';
    }

    get isWhatsAppSource() { return this.selectedConv?.source === 'whatsapp'; }
    get showWindowTimer() { return this.isWhatsAppSource && this.windowTimerText && !this.isWindowExpired; }
    get isWindowExpiredWhatsApp() { return this.isWhatsAppSource && this.isWindowExpired; }
    get disableSend() { return this.isSending || (!this.messageText?.trim() && !this.pendingFile) || !this.selectedHasVisitorId || (this.isWhatsAppSource && this.isWindowExpired); }
    get disableSendEmail() { return this.isSendingEmail || !this.emailTo || !this.emailSubject; }
    get disableSendWa() { return this.isSendingWa || !this.waPhone || !this.waTemplateId; }
    get disableSendSms() { return this.isSendingSms || !this.smsPhone || !this.smsContent?.trim(); }
    get smsCharCount() { return (this.smsContent || '').length; }
    get smsCharLabel() { return this.smsCharCount + ' / 160'; }
    get disableLink() { return this.isLinking || !this.linkRecordId; }

    // DEPRECATED: Use convStatusOptions instead (already defined at top of class)
    // This getter kept for backward compatibility
    get statusOptionsDeprecated() {
        return [
            { label: 'In Progress', value: 'In Progress' },
            { label: 'All', value: 'All' },
            { label: 'Open', value: 'Abierta' },
            { label: 'Resolved', value: 'Resuelta' },
            { label: 'Closed', value: 'Closed' },
            { label: 'Unlinked', value: 'Unlinked' }
        ];
    }

    get selectedRecordIcon() {
        if (!this.selectedConv) return 'standard:person_account';
        return this.selectedConv.recordTypeIcon;
    }

    get selectedDisplayName() {
        return this.selectedConv?.displayName || 'Visitor';
    }
    
    get selectedLeadStatus() {
        // Only show Lead Status if it's a Lead record
        if (this.selectedConv?.linkedRecordType === 'Lead') {
            return this.selectedConv?.leadStatus || null;
        }
        return null;
    }
    
    get flowInputVariables() {
        return [
            { name: 'recordId', type: 'String', value: this.flowLeadId }
        ];
    }

    get selectedStatusBadge() {
        return this.selectedConv?.status || 'Open';
    }

    get selectedSource() {
        return this.selectedConv?.source || 'web';
    }

    get selectedMessageCount() {
        return this.selectedConv?.messageCount || 0;
    }

    showToast(title, message, variant) {
        this.dispatchEvent(new ShowToastEvent({ title, message, variant }));
    }
}
