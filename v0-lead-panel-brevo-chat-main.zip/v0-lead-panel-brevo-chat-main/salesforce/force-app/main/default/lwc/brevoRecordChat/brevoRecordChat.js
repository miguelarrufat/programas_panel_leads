import { LightningElement, api, track } from 'lwc';
import { subscribe, onError } from 'lightning/empApi';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import getRecordInfo from '@salesforce/apex/BrevoConversationsController.getRecordInfo';
import getConversationsForRecord from '@salesforce/apex/BrevoConversationsController.getConversationsForRecord';
import getGroupedConversationMessages from '@salesforce/apex/BrevoConversationsController.getGroupedConversationMessages';
import markConversationAsRead from '@salesforce/apex/BrevoConversationsController.markConversationAsRead';
import sendMessage from '@salesforce/apex/BrevoConversationsController.sendMessage';
import sendMessageWithFile from '@salesforce/apex/BrevoConversationsController.sendMessageWithFile';
import sendTransactionalEmail from '@salesforce/apex/BrevoConversationsController.sendTransactionalEmail';
import sendTransactionalEmailWithAttachment from '@salesforce/apex/BrevoConversationsController.sendTransactionalEmailWithAttachment';
import getEmailTemplates from '@salesforce/apex/BrevoConversationsController.getEmailTemplates';
import getWhatsAppTemplates from '@salesforce/apex/BrevoConversationsController.getWhatsAppTemplates';
import sendWhatsAppMessage from '@salesforce/apex/BrevoConversationsController.sendWhatsAppMessage';
import sendTransactionalSMS from '@salesforce/apex/BrevoConversationsController.sendTransactionalSMS';
import closeConversation from '@salesforce/apex/BrevoConversationsController.closeConversation';
import getSavedResponses from '@salesforce/apex/BrevoConversationsController.getSavedResponses';
import getRecordActivities from '@salesforce/apex/BrevoConversationsController.getRecordActivities';
import getUnifiedMessagesForRecord from '@salesforce/apex/BrevoConversationsController.getUnifiedMessagesForRecord';

const CHANNEL = '/event/Brevo_Message_Event__e';

const EMOJI_LIST = [
    { cat: 'Caras', items: ['😊','😂','🤣','😍','🥰','😘','😜','🤔','😢','😭','😡','🤯','🥳','😎','🙄','😴','🤗','🤮','😷','🤓'] },
    { cat: 'Manos', items: ['👍','👎','👏','🙏','🤝','💪','👋','🤲','✌️','🤞','👌','🫶','🫡','✋','🤙'] },
    { cat: 'Corazones', items: ['❤️','🧡','💛','💚','💙','💜','🖤','🤍','💔','❤️‍🔥','💕','💗','💖','💝'] },
    { cat: 'Simbolos', items: ['✅','❌','⚠️','🔥','⭐','💡','📌','🎯','💬','📎','📝','🔔','🕐','📊','🚀'] }
];

export default class BrevoRecordChat extends LightningElement {
    @api recordId;
    @api objectApiName;

    @track recordInfo = null;
    @track conversations = [];
    @track selectedConv = null;
    @track messages = [];
    @track isLoading = true;
    @track isLoadingMessages = false;
    @track error = null;
    @track isSending = false;

    // Modals
    @track showEmailModal = false;
    @track showWhatsAppModal = false;
    @track showSmsModal = false;

    // Email form
    @track emailTo = '';
    @track emailSubject = '';
    @track emailBody = '';
    @track isSendingEmail = false;
    @track emailTemplateId = null;
    @track emailTemplateOptions = [];
    @track emailFile = null;
    _emailTemplatesData = [];

    // WhatsApp form
    @track waPhone = '';
    @track waTemplateId = null;
    @track waTemplates = [];
    @track waTemplatesLoading = false;
    _waTemplateDataMap = {};
    @track isSendingWa = false;

    // SMS form
    @track smsPhone = '';
    @track smsContent = '';
    @track isSendingSms = false;

    // Tabs
    @track activeTab = 'conversations';
    @track activities = [];
    @track isLoadingActivities = false;
    @track openTaskCount = 0;

    // Emoji picker
    @track showEmojiPicker = false;
    @track emojiCategories = EMOJI_LIST;

    // Saved responses
    @track showSavedResponses = false;
    @track savedResponses = [];
    @track savedResponsesFilter = '';

    // Close conversation
    @track isClosing = false;

    // Unified view
    @track unifiedViewEnabled = true; // Default to unified view
    @track unifiedMessages = []; // All messages with closure markers
    @track closures = []; // Closure events for visual markers
    @track totalConversations = 0;

    // Timer
    @track windowTimerText = '';
    @track isWindowExpired = false;

    // File attachment
    @track pendingFile = null;

    messageText = '';
    subscription = null;
    _timerInterval = null;

    connectedCallback() {
        this.loadData();
        this.subscribeToPlatformEvents();
        this.loadSavedResponses();
    }

    disconnectedCallback() {
        this.clearWindowTimer();
    }

    async loadData() {
        this.isLoading = true;
        try {
            // Load record info
            const infoResult = await getRecordInfo({ recordId: this.recordId });
            this.recordInfo = JSON.parse(infoResult);

            if (this.unifiedViewEnabled) {
                // Load unified messages for the entire record
                await this.loadUnifiedMessages();
            } else {
                // Load grouped conversations (legacy mode)
                const convsResult = await getConversationsForRecord({ recordId: this.recordId });
                this.conversations = JSON.parse(convsResult).map(conv => ({
                    ...conv,
                    sourceIcon: this.getSourceIcon(conv.source),
                    sourceLabel: conv.source || 'web',
                    formattedDate: this.formatDate(conv.lastMessageDate),
                    unreadBadge: conv.unreadCount > 0 ? String(conv.unreadCount) : null
                }));

                // Auto-select first conversation group if available
                if (this.conversations.length > 0 && !this.selectedConv) {
                    this.selectConversation(this.conversations[0].groupKey || this.conversations[0].id);
                }
            }
            this.error = null;
        } catch (err) {
            this.error = err.body?.message || 'Error cargando datos del registro.';
        } finally {
            this.isLoading = false;
        }
    }

    async loadUnifiedMessages() {
        try {
            const result = await getUnifiedMessagesForRecord({ recordId: this.recordId });
            const data = JSON.parse(result);
            
            this.totalConversations = data.totalConversations || 0;
            this.closures = data.closures || [];
            
            // Build unified message list with closure markers inserted
            const allItems = [];
            const messages = data.messages || [];
            const closureMap = new Map();
            
            // Index closures by conversationId for quick lookup
            for (const closure of this.closures) {
                closureMap.set(closure.conversationId, closure);
            }
            
            // Track which conversations we've seen closed
            const seenClosures = new Set();
            let lastConvId = null;
            
            for (let i = 0; i < messages.length; i++) {
                const msg = messages[i];
                const currentConvId = msg.conversationId;
                
                // If conversation changed and previous one was closed, insert closure marker
                if (lastConvId && lastConvId !== currentConvId && closureMap.has(lastConvId) && !seenClosures.has(lastConvId)) {
                    const closure = closureMap.get(lastConvId);
                    allItems.push({
                        isClosure: true,
                        closureDate: this.formatClosureDate(closure.closedAt),
                        closureSource: closure.source,
                        closureStatus: closure.status,
                        key: 'closure-' + lastConvId
                    });
                    seenClosures.add(lastConvId);
                }
                
                // Add the message
                const isVisitor = msg.senderType === 'visitor';
                allItems.push({
                    ...msg,
                    isClosure: false,
                    isVisitor: isVisitor,
                    isAgent: msg.senderType === 'agent' || msg.senderType === 'operator',
                    bubbleClass: isVisitor ? 'message-visitor' : 'message-agent',
                    innerClass: isVisitor ? 'bubble-visitor' : 'bubble-agent',
                    formattedTime: this.formatMessageTime(msg.createdAt),
                    hasFile: !!msg.fileUrl,
                    displayContent: msg.text || msg.html || '',
                    sourceIcon: this.getSourceIcon(msg.source),
                    key: 'msg-' + msg.id
                });
                
                lastConvId = currentConvId;
            }
            
            // Add final closure if last conversation was closed
            if (lastConvId && closureMap.has(lastConvId) && !seenClosures.has(lastConvId)) {
                const closure = closureMap.get(lastConvId);
                allItems.push({
                    isClosure: true,
                    closureDate: this.formatClosureDate(closure.closedAt),
                    closureSource: closure.source,
                    closureStatus: closure.status,
                    key: 'closure-' + lastConvId
                });
            }
            
            this.unifiedMessages = allItems;
            this.messages = allItems.filter(item => !item.isClosure); // For backward compat
            
        } catch (err) {
            console.error('Error loading unified messages:', err);
            this.unifiedMessages = [];
        }
    }

    formatClosureDate(dateStr) {
        if (!dateStr) return '';
        const d = new Date(dateStr);
        return d.toLocaleDateString('es-ES', { day: '2-digit', month: 'short', year: 'numeric' }) + 
               ' ' + d.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' });
    }

    formatMessageTime(dateStr) {
        if (!dateStr) return '';
        const d = new Date(dateStr);
        const now = new Date();
        const time = d.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' });
        if (d.toDateString() === now.toDateString()) {
            return time;
        }
        return d.toLocaleDateString('es-ES', { day: '2-digit', month: 'short' }) + ' ' + time;
    }

    getSourceIcon(source) {
        const map = {
            'whatsapp': 'utility:comments',
            'facebook': 'utility:socialshare',
            'instagram': 'utility:photo',
            'email': 'utility:email',
            'widget': 'utility:chat'
        };
        return map[source] || 'utility:chat';
    }

    formatDate(dateStr) {
        if (!dateStr) return '';
        const d = new Date(dateStr);
        const now = new Date();
        const time = d.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' });
        if (d.toDateString() === now.toDateString()) {
            return time;
        }
        const date = d.toLocaleDateString('es-ES', { day: '2-digit', month: 'short' });
        return date + ' ' + time;
    }

    // ─── SELECT CONVERSATION (group) ─────────────────────────────
    handleSelectConversation(event) {
        const groupKey = event.currentTarget.dataset.groupkey || event.currentTarget.dataset.id;
        this.selectConversation(groupKey);
    }

    async selectConversation(groupKey) {
        this.selectedConv = this.conversations.find(c => c.groupKey === groupKey || c.id === groupKey);
        if (!this.selectedConv) return;

        // Load messages from ALL conversations in the group
        this.isLoadingMessages = true;
        this.messages = [];
        const convIds = this.selectedConv.conversationIds || [this.selectedConv.id];
        try {
            const result = await getGroupedConversationMessages({
                conversationRecordIdsJson: JSON.stringify(convIds)
            });
            this.messages = JSON.parse(result).map(msg => ({
                ...msg,
                isVisitor: msg.senderType === 'visitor',
                isAgent: msg.senderType === 'agent',
                bubbleClass: msg.senderType === 'visitor' ? 'message-visitor' : 'message-agent',
                innerClass: msg.senderType === 'visitor' ? 'bubble-visitor' : 'bubble-agent',
                formattedTime: this.formatDate(msg.createdAt),
                hasFile: !!msg.fileUrl,
                subject: msg.subject || null,
                isPushed: msg.isPushed,
                isTrigger: msg.isTrigger,
                isMissed: msg.isMissed
            }));
        } catch (err) {
            this.showToast('Error', 'No se pudieron cargar los mensajes', 'error');
        } finally {
            this.isLoadingMessages = false;
        }

        // Mark all conversations in group as read
        if (this.selectedConv.unreadCount > 0) {
            try {
                await markConversationAsRead({ conversationIdsJson: JSON.stringify(convIds) });
                this.selectedConv = { ...this.selectedConv, unreadCount: 0, unreadBadge: null };
                this.conversations = this.conversations.map(c =>
                    c.groupKey === this.selectedConv.groupKey ? { ...c, unreadCount: 0, unreadBadge: null } : c
                );
            } catch (err) { /* ignore */ }
        }

        // Start 24h window timer for WhatsApp
        this.startWindowTimer();

        // eslint-disable-next-line @lwc/lwc/no-async-operation
        setTimeout(() => { this.scrollChatToBottom(); }, 100);
    }

    // ─── 24H WINDOW TIMER ──────────────────────────────────────
    startWindowTimer() {
        this.clearWindowTimer();
        this.windowTimerText = '';
        this.isWindowExpired = false;

        if (!this.selectedConv) return;
        if (this.selectedConv.source !== 'whatsapp') return;

        const lastVisitor = this.selectedConv.lastVisitorMessageDate || this.selectedConv.lastMessageDate;
        if (!lastVisitor) {
            // No dates at all — cannot compute window, do not block
            return;
        }

        this.updateWindowTimer();
        // eslint-disable-next-line @lwc/lwc/no-async-operation
        this._timerInterval = setInterval(() => { this.updateWindowTimer(); }, 60000);
    }

    updateWindowTimer() {
        const dateStr = this.selectedConv?.lastVisitorMessageDate || this.selectedConv?.lastMessageDate;
        if (!dateStr) return;
        const lastMsg = new Date(dateStr);
        const now = new Date();
        const diffMs = (lastMsg.getTime() + 24 * 60 * 60 * 1000) - now.getTime();

        if (diffMs <= 0) {
            this.isWindowExpired = true;
            this.windowTimerText = 'Ventana expirada';
            this.clearWindowTimer();
            return;
        }

        const hours = Math.floor(diffMs / (1000 * 60 * 60));
        const minutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
        this.windowTimerText = hours + 'h ' + minutes + 'm restantes';
        this.isWindowExpired = false;
    }

    clearWindowTimer() {
        if (this._timerInterval) {
            clearInterval(this._timerInterval);
            this._timerInterval = null;
        }
    }

    scrollChatToBottom() {
        const chatDiv = this.template.querySelector('.chat-messages');
        if (chatDiv) chatDiv.scrollTop = chatDiv.scrollHeight;
    }

    // ─── FILE ATTACHMENT ────────────────────────────────────────
    handleAttachClick() {
        const fileInput = this.template.querySelector('input[data-id="fileInput"]');
        if (fileInput) fileInput.click();
    }

    handleFileSelected(event) {
        const file = event.target.files[0];
        if (!file) return;
        if (file.size > 20 * 1024 * 1024) {
            this.showToast('Error', 'El archivo no puede superar 20 MB', 'error');
            event.target.value = '';
            return;
        }
        const reader = new FileReader();
        reader.onload = () => {
            this.pendingFile = { name: file.name, base64: reader.result.split(',')[1], size: file.size, type: file.type };
        };
        reader.readAsDataURL(file);
        event.target.value = '';
    }

    handleRemoveFile() { this.pendingFile = null; }
    get hasPendingFile() { return this.pendingFile != null; }
    get pendingFileLabel() {
        if (!this.pendingFile) return '';
        return this.pendingFile.name + ' (' + Math.round(this.pendingFile.size / 1024) + ' KB)';
    }

    // ─── SEND MESSAGE ───────────────────────────────────────────
    async handleSendMessage() {
        const visitorId = this.selectedConv?.visitorId || this.recordInfo?.visitorId;
        const hasText = this.messageText?.trim();
        const hasFile = this.pendingFile != null;
        if ((!hasText && !hasFile) || !visitorId) return;
        this.isSending = true;
        const sentText = this.messageText || '';
        const sentFile = this.pendingFile;
        try {
            if (sentFile) {
                await sendMessageWithFile({ visitorId, text: sentText, agentName: null, fileBase64: sentFile.base64, fileName: sentFile.name });
            } else {
                await sendMessage({ visitorId, text: sentText, agentName: null });
            }
            const optimisticText = sentFile ? (sentText || sentFile.name) : sentText;
            this.messages = [...this.messages, {
                id: 'temp-' + Date.now(),
                senderType: 'agent',
                senderName: 'Agente',
                text: optimisticText,
                isVisitor: false,
                isAgent: true,
                bubbleClass: 'message-agent',
                innerClass: 'bubble-agent',
                formattedTime: new Date().toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' }),
                hasFile: !!sentFile,
                fileName: sentFile ? sentFile.name : null
            }];
            this.messageText = '';
            this.pendingFile = null;
            // Optimistically change status to 'Resuelta'
            if (this.selectedConv?.status === 'Abierta') {
                this.selectedConv = { ...this.selectedConv, status: 'Resuelta' };
                this.conversations = this.conversations.map(c =>
                    c.groupKey === this.selectedConv.groupKey ? { ...c, status: 'Resuelta' } : c
                );
            }
            // eslint-disable-next-line @lwc/lwc/no-async-operation
            setTimeout(() => { this.scrollChatToBottom(); }, 50);
        } catch (err) {
            this.showToast('Error', err.body?.message || 'No se pudo enviar el mensaje', 'error');
        } finally {
            this.isSending = false;
        }
    }

    handleMessageInput(event) { this.messageText = event.target.value; }
    handleKeyPress(event) {
        if (event.key === 'Enter' && !event.shiftKey) {
            event.preventDefault();
            this.handleSendMessage();
        }
    }

    // ─── EMAIL MODAL ────────────────────────────────────────────
    handleOpenEmailModal() {
        this.emailTo = this.recordInfo?.email || '';
        this.emailSubject = '';
        this.emailBody = '';
        this.emailTemplateId = null;
        this.emailFile = null;
        this.showEmailModal = true;
        this.loadEmailTemplates();
    }
    handleCloseEmailModal() { this.showEmailModal = false; }
    handleEmailToChange(event) { this.emailTo = event.detail.value || event.target.value; }
    handleEmailSubjectChange(event) { this.emailSubject = event.detail.value || event.target.value; }
    handleEmailBodyChange(event) { this.emailBody = event.detail.value; }

    get emailRichTextFormats() {
        return ['font', 'size', 'bold', 'italic', 'underline', 'strike', 'list', 'indent', 'align', 'link', 'clean', 'table', 'header'];
    }

    async loadEmailTemplates() {
        try {
            const acctId = this.recordInfo?.accountId || null;
            const result = await getEmailTemplates({ accountId: acctId });
            this._emailTemplatesData = JSON.parse(result);
            this.emailTemplateOptions = [
                { label: '-- Sin plantilla --', value: '' },
                ...this._emailTemplatesData.map(t => ({
                    label: (t.folder ? t.folder + ' / ' : '') + t.name,
                    value: t.id
                }))
            ];
        } catch (err) {
            this._emailTemplatesData = [];
            this.emailTemplateOptions = [];
        }
    }

    handleEmailTemplateChange(event) {
        this.emailTemplateId = event.detail.value;
        if (!this.emailTemplateId) return;
        const tmpl = this._emailTemplatesData.find(t => t.id === this.emailTemplateId);
        if (tmpl) {
            if (tmpl.subject) this.emailSubject = tmpl.subject;
            this.emailBody = tmpl.htmlBody || tmpl.textBody || '';
        }
    }

    handleEmailAttachClick() {
        const input = this.template.querySelector('input[data-id="emailFileInput"]');
        if (input) input.click();
    }

    handleEmailFileSelected(event) {
        const file = event.target.files[0];
        if (!file) return;
        if (file.size > 20 * 1024 * 1024) {
            this.showToast('Error', 'El archivo no puede superar 20 MB', 'error');
            event.target.value = '';
            return;
        }
        const reader = new FileReader();
        reader.onload = () => {
            this.emailFile = { name: file.name, base64: reader.result.split(',')[1], size: file.size };
        };
        reader.readAsDataURL(file);
        event.target.value = '';
    }

    handleRemoveEmailFile() { this.emailFile = null; }
    get hasEmailFile() { return this.emailFile != null; }
    get emailFileLabel() {
        if (!this.emailFile) return '';
        return this.emailFile.name + ' (' + Math.round(this.emailFile.size / 1024) + ' KB)';
    }

    async handleSendEmail() {
        if (!this.emailTo || !this.emailSubject) return;
        this.isSendingEmail = true;
        try {
            if (this.emailFile) {
                await sendTransactionalEmailWithAttachment({
                    toEmail: this.emailTo,
                    toName: this.recordInfo?.name || '',
                    subject: this.emailSubject,
                    htmlContent: this.emailBody || '<p></p>',
                    fileBase64: this.emailFile.base64,
                    fileName: this.emailFile.name
                });
            } else {
                await sendTransactionalEmail({
                    toEmail: this.emailTo,
                    toName: this.recordInfo?.name || '',
                    subject: this.emailSubject,
                    htmlContent: this.emailBody || '<p></p>'
                });
            }
            this.showToast('Email enviado', 'Se envio el email correctamente via Brevo', 'success');
            this.showEmailModal = false;
        } catch (err) {
            this.showToast('Error', err.body?.message || 'No se pudo enviar el email', 'error');
        } finally {
            this.isSendingEmail = false;
        }
    }

    // ─── WHATSAPP MODAL ─────────────────────────────────────────
    async handleOpenWhatsAppModal() {
        this.waPhone = this.recordInfo?.phone || '';
        this.waTemplateId = null;
        this.showWhatsAppModal = true;
        this.loadWhatsAppTemplates();
    }
    handleCloseWhatsAppModal() { this.showWhatsAppModal = false; }
    handleWaPhoneChange(event) { this.waPhone = event.detail.value || event.target.value; }
    handleWaTemplateChange(event) { this.waTemplateId = event.detail.value; }
    get waTemplatePreview() {
        if (!this.waTemplateId || !this._waTemplateDataMap[this.waTemplateId]) return '';
        return this._waTemplateDataMap[this.waTemplateId].bodyText;
    }
    get hasWaTemplatePreview() { return !!this.waTemplatePreview; }

    async loadWhatsAppTemplates() {
        this.waTemplatesLoading = true;
        try {
            const result = await getWhatsAppTemplates();
            const parsed = JSON.parse(result);
            const templates = parsed.templates || parsed || [];
            const approved = templates.filter(t => t.status === 'approved');
            const dataMap = {};
            this.waTemplates = approved.map(t => {
                const val = String(t.id);
                // Brevo API may return body text in different fields
                let bodyText = t.bodyText || t.body || '';
                // Some templates store body in components array
                if (!bodyText && t.components && Array.isArray(t.components)) {
                    const bodyComp = t.components.find(c => c.type === 'BODY' || c.type === 'body');
                    if (bodyComp) bodyText = bodyComp.text || '';
                }
                // Also check htmlBody
                if (!bodyText && t.htmlBody) bodyText = t.htmlBody;
                dataMap[val] = { bodyText: bodyText };
                return { label: t.name + (t.language ? ' (' + t.language + ')' : ''), value: val };
            });
            this._waTemplateDataMap = dataMap;
        } catch (err) {
            this.waTemplates = [];
        } finally {
            this.waTemplatesLoading = false;
        }
    }

    async handleSendWhatsApp() {
        if (!this.waPhone || !this.waTemplateId) return;
        this.isSendingWa = true;
        try {
            await sendWhatsAppMessage({ phone: this.waPhone, templateId: parseInt(this.waTemplateId, 10), params: null });
            this.showToast('WhatsApp enviado', 'Mensaje enviado correctamente', 'success');
            this.showWhatsAppModal = false;
        } catch (err) {
            this.showToast('Error', err.body?.message || 'No se pudo enviar el WhatsApp', 'error');
        } finally {
            this.isSendingWa = false;
        }
    }

    // ─── SMS MODAL ──────────────────────────────────────────────
    handleOpenSmsModal() {
        this.smsPhone = this.recordInfo?.phone || '';
        this.smsContent = '';
        this.showSmsModal = true;
    }
    handleCloseSmsModal() { this.showSmsModal = false; }
    handleSmsPhoneChange(event) { this.smsPhone = event.detail.value || event.target.value; }
    handleSmsContentChange(event) { this.smsContent = event.target.value; }

    async handleSendSms() {
        if (!this.smsPhone || !this.smsContent) return;
        this.isSendingSms = true;
        try {
            await sendTransactionalSMS({ phone: this.smsPhone, content: this.smsContent });
            this.showToast('SMS enviado', 'SMS enviado correctamente', 'success');
            this.showSmsModal = false;
        } catch (err) {
            this.showToast('Error', err.body?.message || 'No se pudo enviar el SMS', 'error');
        } finally {
            this.isSendingSms = false;
        }
    }

    // ─── EMOJI PICKER ──────────────────────────────────────────
    handleToggleEmoji() {
        this.showEmojiPicker = !this.showEmojiPicker;
        this.showSavedResponses = false;
    }

    handleSelectEmoji(event) {
        const emoji = event.currentTarget.dataset.emoji;
        this.messageText = (this.messageText || '') + emoji;
        this.showEmojiPicker = false;
    }

    // ─── SAVED RESPONSES ───────────────────────────────────────
    async loadSavedResponses() {
        try {
            const result = await getSavedResponses();
            this.savedResponses = JSON.parse(result);
        } catch (err) {
            this.savedResponses = [];
        }
    }

    handleToggleSavedResponses() {
        this.showSavedResponses = !this.showSavedResponses;
        this.showEmojiPicker = false;
        this.savedResponsesFilter = '';
    }

    handleSavedResponseFilter(event) {
        this.savedResponsesFilter = event.target.value;
    }

    handleSelectSavedResponse(event) {
        const responseId = event.currentTarget.dataset.id;
        const response = this.savedResponses.find(r => r.id === responseId);
        if (response) {
            this.messageText = (this.messageText || '') + response.text;
        }
        this.showSavedResponses = false;
    }

    get filteredSavedResponses() {
        if (!this.savedResponsesFilter) return this.savedResponses;
        const term = this.savedResponsesFilter.toLowerCase();
        return this.savedResponses.filter(r =>
            r.name.toLowerCase().includes(term) || (r.text || '').toLowerCase().includes(term)
        );
    }

    get hasSavedResponses() { return this.savedResponses.length > 0; }

    // ─── CLOSE CONVERSATION GROUP ────────────────────────────────
    async handleCloseConversation() {
        if (!this.selectedConv) return;
        this.isClosing = true;
        try {
            const convIds = this.selectedConv.conversationIds || [this.selectedConv.id];
            await closeConversation({ conversationRecordIdsJson: JSON.stringify(convIds) });
            this.selectedConv = { ...this.selectedConv, status: 'Cerrada' };
            this.conversations = this.conversations.map(c =>
                c.groupKey === this.selectedConv.groupKey ? { ...c, status: 'Cerrada' } : c
            );
            this.showToast('Cerrada', 'Conversacion cerrada correctamente', 'success');
        } catch (err) {
            this.showToast('Error', err.body?.message || 'No se pudo cerrar', 'error');
        } finally {
            this.isClosing = false;
        }
    }

    get canCloseConversation() {
        return this.selectedConv && this.selectedConv.status !== 'Cerrada' && !this.isClosing;
    }

    get isConversationClosed() {
        return this.selectedConv?.status === 'Cerrada';
    }

    get isWhatsAppSource() { return this.selectedConv?.source === 'whatsapp'; }
    get showWindowTimer() { return this.isWhatsAppSource && this.windowTimerText && !this.isWindowExpired; }
    get isWindowExpiredWhatsApp() { return this.isWhatsAppSource && this.isWindowExpired; }

    get windowTimerStyle() {
        return this.isWindowExpired
            ? 'background:#fde8e8; color:#b91c1c;'
            : 'background:#fef9c3; color:#854d0e;';
    }

    // ─── TABS ────────────────────────────────────────────────────
    get isConversationsTab() { return this.activeTab === 'conversations'; }
    get isActivitiesTab() { return this.activeTab === 'activities'; }
    get conversationsTabClass() {
        return 'slds-tabs_default__item' + (this.isConversationsTab ? ' slds-is-active' : '');
    }
    get activitiesTabClass() {
        return 'slds-tabs_default__item' + (this.isActivitiesTab ? ' slds-is-active' : '');
    }
    get activitiesBadge() { return this.openTaskCount > 0 ? String(this.openTaskCount) : ''; }
    get hasActivitiesBadge() { return this.openTaskCount > 0; }

    handleTabClick(event) {
        const tab = event.currentTarget.dataset.tab;
        this.activeTab = tab;
        if (tab === 'activities' && this.activities.length === 0) {
            this.loadActivities();
        }
    }

    async loadActivities() {
        this.isLoadingActivities = true;
        try {
            const result = await getRecordActivities({ recordId: this.recordId });
            const parsed = JSON.parse(result);
            this.activities = parsed.activities || [];
            this.openTaskCount = parsed.openTaskCount || 0;
        } catch (err) {
            this.activities = [];
        } finally {
            this.isLoadingActivities = false;
        }
    }

    get hasActivities() { return this.activities.length > 0 && !this.isLoadingActivities; }
    get noActivitiesContent() { return !this.isLoadingActivities && this.activities.length === 0; }
    get totalUnreadStr() { return String(this.totalUnread); }

    get formattedActivities() {
        return this.activities.map(a => ({
            ...a,
            iconName: a.type === 'task' ? (a.isClosed ? 'utility:check' : 'utility:task') : 'utility:event',
            iconVariant: a.isClosed ? 'success' : (a.priority === 'High' ? 'warning' : ''),
            dueDateLabel: a.dueDate || 'Sin fecha',
            statusBadge: a.status,
            statusVariant: a.isClosed ? 'success' : 'default'
        }));
    }

    // ─── NAV / REFRESH ──────────────────────────────────────────
    handleOpenInBrevo() {
        if (this.selectedConv?.threadLink) {
            window.open(this.selectedConv.threadLink, '_blank');
        } else {
            window.open('https://conversations-app.brevo.com/', '_blank');
        }
    }
    handleRefresh() {
        this.loadData();
    }

    subscribeToPlatformEvents() {
        const messageCallback = () => { this.loadData(); };
        subscribe(CHANNEL, -1, messageCallback).then(response => {
            this.subscription = response;
        });
        onError(error => { console.error('EMP API error:', error); });
    }

    // ─── COMPUTED ───────────────────────────────────────────────
  get hasConversations() { return this.conversations.length > 0; }
  get noConversations() { return !this.hasConversations && !this.isLoading; }
  get showLegacyView() { return !this.unifiedViewEnabled; }
  get noConversationsLegacy() { return this.showLegacyView && this.noConversations; }
    get hasSelectedConv() { return !!this.selectedConv; }
    get noSelectedConv() { return !this.selectedConv; }
  get hasMessages() { 
    return this.unifiedViewEnabled ? this.unifiedMessages.length > 0 : this.messages.length > 0; 
  }
  get noMessages() { return !this.hasMessages && !this.isLoadingMessages && !this.isLoading; }

    get hasVisitorId() {
        return !!(this.selectedConv?.visitorId || this.recordInfo?.visitorId);
    }
    get noVisitorId() { return !this.hasVisitorId; }

    get hasEmail() { return !!this.recordInfo?.email; }
    get hasPhone() { return !!this.recordInfo?.phone; }
    get noEmail() { return !this.hasEmail; }
    get noPhone() { return !this.hasPhone; }

    get disableSend() { return this.isSending || (!this.messageText?.trim() && !this.pendingFile) || !this.hasVisitorId || (this.isWhatsAppSource && this.isWindowExpired); }
    get disableSendEmail() { return this.isSendingEmail || !this.emailTo || !this.emailSubject; }
    get disableSendWa() { return this.isSendingWa || !this.waPhone || !this.waTemplateId; }
    get disableSendSms() { return this.isSendingSms || !this.smsPhone || !this.smsContent?.trim(); }
    get smsCharCount() { return (this.smsContent || '').length; }
    get smsCharLabel() { return this.smsCharCount + ' / 160'; }

    get cardTitle() {
        return 'Brevo Conversations' + (this.recordInfo?.name ? ' - ' + this.recordInfo.name : '');
    }

    get totalUnread() {
        return this.conversations.reduce((sum, c) => sum + (c.unreadCount || 0), 0);
    }

    get conversationCount() {
        return this.conversations.length;
    }

    showToast(title, message, variant) {
        this.dispatchEvent(new ShowToastEvent({ title, message, variant }));
    }
}
