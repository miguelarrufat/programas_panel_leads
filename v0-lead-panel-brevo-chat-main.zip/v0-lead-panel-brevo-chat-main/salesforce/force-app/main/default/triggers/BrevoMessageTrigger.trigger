trigger BrevoMessageTrigger on Brevo_Message__c (after insert) {
    if (Trigger.isAfter && Trigger.isInsert) {
        BrevoMessageTriggerHandler.handleAfterInsert(Trigger.new);
    }
}
