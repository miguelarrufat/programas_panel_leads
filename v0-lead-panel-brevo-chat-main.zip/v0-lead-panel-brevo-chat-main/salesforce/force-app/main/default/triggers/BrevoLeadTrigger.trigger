trigger BrevoLeadTrigger on Lead (after insert) {
    if (Trigger.isAfter && Trigger.isInsert) {
        BrevoLeadTriggerHandler.handleAfterInsert(Trigger.new);
    }
}
