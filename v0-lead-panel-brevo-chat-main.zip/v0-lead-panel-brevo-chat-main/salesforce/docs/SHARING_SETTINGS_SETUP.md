# Configuracion de Sharing Settings para Brevo Inbox

## Objetivo
Configurar la visibilidad de Leads y Conversaciones por Colegio (Account), donde:
- **Admin**: Ve todos los registros
- **Usuarios**: Solo ven registros de su(s) colegio(s) asignado(s)

---

## 1. Organization-Wide Defaults (OWD)

Ve a: **Setup > Sharing Settings**

### Lead
- **Default Internal Access**: `Private`
- **Default External Access**: `Private`

### Brevo_Conversation__c
- **Default Internal Access**: `Private`
- **Default External Access**: `Private`

### Account
- **Default Internal Access**: `Private` (o Read Only segun necesidad)

---

## 2. Crear Rol de Usuario por Colegio

Ve a: **Setup > Roles**

Estructura sugerida:
```
CEO (Admin)
├── Director Regional
│   ├── Director Colegio Los Pinos
│   ├── Director Colegio San Jose
│   └── Director Colegio Academia Central
```

---

## 3. Sharing Rules para Leads

Ve a: **Setup > Sharing Settings > Lead Sharing Rules > New**

### Opcion A: Por Rol (recomendado)
- **Rule Name**: `Leads_Colegio_LosPinos`
- **Rule Type**: Based on criteria
- **Criteria**: `Colegio_Relacionado__c EQUALS [Id del Account Los Pinos]`
- **Share with**: Role: `Director Colegio Los Pinos`
- **Access Level**: Read/Write

Repetir para cada colegio.

### Opcion B: Por Propietario del Account
Si el Account (Colegio) tiene un Owner que es el director:
- **Rule Type**: Based on record owner
- **Records owned by**: Role `Director Colegio X`
- **Share with**: Role `Director Colegio X`

---

## 4. Sharing Rules para Brevo_Conversation__c

Ve a: **Setup > Sharing Settings > Brevo_Conversation__c Sharing Rules > New**

### Por Lead Relacionado (usar Apex Sharing si es necesario)
Dado que Brevo_Conversation__c tiene lookup a Lead__c, la visibilidad deberia seguir al Lead.

**Opcion 1: Master-Detail**
Si cambias `Lead__c` a Master-Detail, la conversacion heredara automaticamente el sharing del Lead.

**Opcion 2: Apex Managed Sharing**
Crear un trigger que asigne sharing cuando se crea la conversacion:

```apex
// BrevoConversationSharingTrigger.trigger
trigger BrevoConversationSharingTrigger on Brevo_Conversation__c (after insert) {
    BrevoConversationSharingHandler.shareWithLeadOwner(Trigger.new);
}

// BrevoConversationSharingHandler.cls
public class BrevoConversationSharingHandler {
    public static void shareWithLeadOwner(List<Brevo_Conversation__c> convs) {
        List<Brevo_Conversation__Share> shares = new List<Brevo_Conversation__Share>();
        
        Set<Id> leadIds = new Set<Id>();
        for (Brevo_Conversation__c c : convs) {
            if (c.Lead__c != null) leadIds.add(c.Lead__c);
        }
        
        Map<Id, Lead> leadMap = new Map<Id, Lead>([
            SELECT Id, OwnerId FROM Lead WHERE Id IN :leadIds
        ]);
        
        for (Brevo_Conversation__c c : convs) {
            if (c.Lead__c != null && leadMap.containsKey(c.Lead__c)) {
                Brevo_Conversation__Share share = new Brevo_Conversation__Share();
                share.ParentId = c.Id;
                share.UserOrGroupId = leadMap.get(c.Lead__c).OwnerId;
                share.AccessLevel = 'Edit';
                share.RowCause = Schema.Brevo_Conversation__Share.RowCause.Manual;
                shares.add(share);
            }
        }
        
        if (!shares.isEmpty()) {
            Database.insert(shares, false);
        }
    }
}
```

---

## 5. Asignar Usuarios a Roles

1. Ve a: **Setup > Users**
2. Edita cada usuario
3. Asigna el **Role** correspondiente a su colegio

---

## 6. Verificacion

1. Inicia sesion como usuario de un colegio especifico
2. Abre el LWC Brevo Inbox
3. Verifica que solo ve los leads de su colegio en el dropdown
4. Verifica que las conversaciones mostradas corresponden a esos leads

---

## 7. Permisos Adicionales (Permission Sets)

Crea un Permission Set para acceso a Brevo:

- **Name**: `Brevo_Inbox_User`
- **Object Permissions**:
  - Brevo_Conversation__c: Read, Edit
  - Brevo_Message__c: Read, Edit, Create
  - Lead: Read, Edit
- **Apex Class Access**:
  - BrevoConversationsController

---

## Notas

- El filtro de colegio en el LWC funciona sobre los registros que el usuario ya puede ver (respeta OWD + Sharing Rules)
- Los Admins con perfil "System Administrator" ignoran las Sharing Rules por defecto
- Para testing, usa "Login as" para verificar la vista de cada rol
