"use client"

import { use } from "react"
import {
  mockContacts,
  getConversationsForRecord,
  getRecordSummaries,
} from "@/lib/brevo-data"
import { InboxLayout } from "@/components/brevo/inbox-layout"
import { RecordInfoPanel } from "@/components/brevo/record-info-panel"
import { SfFieldSummary } from "@/components/brevo/sf-field-summary"
import { AppNav } from "@/components/brevo/app-nav"
import Link from "next/link"
import { ArrowLeft, AlertTriangle } from "lucide-react"

export default function ContactRecordLWC({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = use(params)
  const contact = mockContacts.find((c) => c.id === id)

  if (!contact) {
    return (
      <div className="flex h-screen flex-col">
        <AppNav />
        <div className="flex flex-1 flex-col items-center justify-center gap-3 text-muted-foreground">
          <AlertTriangle size={32} className="opacity-50" />
          <p className="text-sm">Contacto no encontrado</p>
          <Link
            href="/"
            className="mt-2 rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90"
          >
            Volver al Inbox
          </Link>
        </div>
      </div>
    )
  }

  const conversations = getConversationsForRecord("contact", id)
  const summaries = getRecordSummaries()
  const summary = summaries.find(
    (s) => s.recordType === "contact" && s.recordId === id
  )

  return (
    <div className="flex h-screen flex-col">
      <AppNav />

      {/* Breadcrumb */}
      <div className="flex items-center gap-2 border-b border-border bg-card px-4 py-2">
        <Link
          href="/"
          className="flex items-center gap-1.5 rounded-md px-2 py-1 text-xs font-medium text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
        >
          <ArrowLeft size={14} />
          Volver al Inbox Global
        </Link>
      </div>

      {/* Record info header */}
      <RecordInfoPanel recordType="contact" record={contact} />

      {/* Salesforce field summary (simulated trigger output) */}
      {summary && (
        <div className="border-b border-border bg-background px-4 py-3">
          <SfFieldSummary summary={summary} />
        </div>
      )}

      {/* Conversations inbox for this contact */}
      <InboxLayout
        conversations={conversations}
        title={`Conversaciones de ${contact.name}`}
        compact
      />
    </div>
  )
}
