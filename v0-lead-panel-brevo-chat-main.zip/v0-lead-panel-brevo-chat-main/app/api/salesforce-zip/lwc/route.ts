import { NextResponse } from 'next/server';
import JSZip from 'jszip';
import { readdir, stat, readFile } from 'fs/promises';
import { join, relative } from 'path';

const SOURCE_DIR = process.cwd() + '/salesforce/force-app/main/default';

// Folders to include in LWC ZIP
const LWC_FOLDERS = ['lwc'];

async function getAllFiles(dir: string, fileList: string[] = []): Promise<string[]> {
    try {
        const files = await readdir(dir);
        for (const file of files) {
            const filePath = join(dir, file);
            const fileStat = await stat(filePath);
            if (fileStat.isDirectory()) {
                await getAllFiles(filePath, fileList);
            } else {
                fileList.push(filePath);
            }
        }
    } catch {
        // Folder doesn't exist
    }
    return fileList;
}

export async function GET() {
    try {
        const zip = new JSZip();
        
        // Add LWC files
        for (const folder of LWC_FOLDERS) {
            const folderPath = join(SOURCE_DIR, folder);
            const files = await getAllFiles(folderPath);
            for (const file of files) {
                const relativePath = relative(SOURCE_DIR, file);
                const content = await readFile(file);
                zip.file(relativePath, content);
            }
        }
        
        // Add package.xml for LWC
        const packageXml = `<?xml version="1.0" encoding="UTF-8"?>
<Package xmlns="http://soap.sforce.com/2006/04/metadata">
    <types>
        <members>brevoInbox</members>
        <members>brevoRecordChat</members>
        <name>LightningComponentBundle</name>
    </types>
    <version>62.0</version>
</Package>`;
        zip.file('package.xml', packageXml);
        
        // Generate ZIP
        const zipContent = await zip.generateAsync({ 
            type: 'nodebuffer',
            compression: 'DEFLATE',
            compressionOptions: { level: 9 }
        });
        
        return new NextResponse(zipContent, {
            headers: {
                'Content-Type': 'application/zip',
                'Content-Disposition': 'attachment; filename="3-brevo-lwc.zip"',
                'Content-Length': String(zipContent.length),
            },
        });
    } catch (error) {
        console.error('Error generating ZIP:', error);
        return NextResponse.json({ error: 'Failed to generate ZIP' }, { status: 500 });
    }
}
