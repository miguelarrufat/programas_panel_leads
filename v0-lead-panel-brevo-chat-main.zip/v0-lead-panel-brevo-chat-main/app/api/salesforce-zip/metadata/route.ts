import { NextResponse } from 'next/server';
import JSZip from 'jszip';
import { readdir, readFile } from 'fs/promises';
import { join } from 'path';

const SOURCE_DIR = process.cwd() + '/salesforce/force-app/main/default';

// Helper to read field files and convert to MDAPI format
async function readFieldsForObject(objectName: string): Promise<string[]> {
    const fieldsDir = join(SOURCE_DIR, 'objects', objectName, 'fields');
    const fieldXmls: string[] = [];
    try {
        const files = await readdir(fieldsDir);
        for (const file of files) {
            if (file.endsWith('.field-meta.xml')) {
                const content = await readFile(join(fieldsDir, file), 'utf-8');
                // Extract inner content (remove xml declaration and outer tag)
                const match = content.match(/<CustomField[^>]*>([\s\S]*?)<\/CustomField>/);
                if (match) {
                    // Convert <CustomField> to <fields> tag for MDAPI format
                    fieldXmls.push(`    <fields>${match[1]}    </fields>`);
                }
            }
        }
    } catch {
        // No fields folder
    }
    return fieldXmls;
}

export async function GET() {
    try {
        const zip = new JSZip();
        
        // Custom objects to include (with their fields)
        const customObjects = [
            'Brevo_Conversation__c',
            'Brevo_Message__c', 
            'Brevo_Message_Event__e',
            'Brevo_Saved_Response__c',
            'Brevo_Settings__c',
            'Email_Template_Colegio__c'
        ];
        
        // Standard objects - only include fields, not the object itself
        const standardObjectFields = ['Lead', 'Contact'];
        
        // Build custom objects with their fields in MDAPI format
        for (const objName of customObjects) {
            const objMetaPath = join(SOURCE_DIR, 'objects', objName, `${objName}.object-meta.xml`);
            try {
                let objContent = await readFile(objMetaPath, 'utf-8');
                const fields = await readFieldsForObject(objName);
                
                // Insert fields before closing tag
                if (fields.length > 0) {
                    objContent = objContent.replace('</CustomObject>', fields.join('\n') + '\n</CustomObject>');
                }
                
                zip.file(`objects/${objName}.object`, objContent);
            } catch {
                // Object doesn't exist
            }
        }
        
        // For standard objects (Lead, Contact), create .object file with embedded fields
        // This is the classic MDAPI format that Workbench expects
        for (const objName of standardObjectFields) {
            const fields = await readFieldsForObject(objName);
            if (fields.length > 0) {
                const objContent = `<?xml version="1.0" encoding="UTF-8"?>
<CustomObject xmlns="http://soap.sforce.com/2006/04/metadata">
${fields.join('\n')}
</CustomObject>`;
                zip.file(`objects/${objName}.object`, objContent);
            }
        }
        
        // Add Named Credentials
        try {
            const ncDir = join(SOURCE_DIR, 'namedCredentials');
            const ncFiles = await readdir(ncDir);
            for (const file of ncFiles) {
                if (file.endsWith('.namedCredential-meta.xml')) {
                    const content = await readFile(join(ncDir, file), 'utf-8');
                    const name = file.replace('.namedCredential-meta.xml', '');
                    zip.file(`namedCredentials/${name}.namedCredential`, content);
                }
            }
        } catch { /* no named credentials */ }
        
        // Add Remote Site Settings
        try {
            const rssDir = join(SOURCE_DIR, 'remoteSiteSettings');
            const rssFiles = await readdir(rssDir);
            for (const file of rssFiles) {
                if (file.endsWith('.remoteSite-meta.xml')) {
                    const content = await readFile(join(rssDir, file), 'utf-8');
                    const name = file.replace('.remoteSite-meta.xml', '');
                    zip.file(`remoteSiteSettings/${name}.remoteSite`, content);
                }
            }
        } catch { /* no remote site settings */ }
        
        // Add BrevoDeployValidator test class (no dependencies)
        const deployValidatorClass = `/**
 * Minimal test class with no dependencies for deploying metadata to Production.
 * This class intentionally has no references to custom objects or other Apex classes.
 */
@IsTest
public class BrevoDeployValidator {
    @IsTest
    static void validateDeployment() {
        // Simple assertion that always passes
        System.assertEquals(true, true, 'Deployment validation passed');
        System.assertNotEquals(null, Date.today(), 'Date should not be null');
        System.assert(1 + 1 == 2, 'Basic math validation');
    }
    
    @IsTest
    static void validateStringOperations() {
        String testStr = 'Brevo Integration';
        System.assertEquals(17, testStr.length(), 'String length check');
        System.assert(testStr.contains('Brevo'), 'String contains check');
        System.assertEquals('brevo integration', testStr.toLowerCase(), 'Lowercase check');
    }
    
    @IsTest
    static void validateCollections() {
        List<String> items = new List<String>{'A', 'B', 'C'};
        System.assertEquals(3, items.size(), 'List size check');
        
        Map<String, Integer> mapping = new Map<String, Integer>();
        mapping.put('one', 1);
        mapping.put('two', 2);
        System.assertEquals(2, mapping.size(), 'Map size check');
        System.assertEquals(1, mapping.get('one'), 'Map get check');
        
        Set<Integer> numbers = new Set<Integer>{1, 2, 3, 2, 1};
        System.assertEquals(3, numbers.size(), 'Set removes duplicates');
    }
}`;
        zip.file('classes/BrevoDeployValidator.cls', deployValidatorClass);
        
        const deployValidatorMeta = `<?xml version="1.0" encoding="UTF-8"?>
<ApexClass xmlns="http://soap.sforce.com/2006/04/metadata">
    <apiVersion>62.0</apiVersion>
    <status>Active</status>
</ApexClass>`;
        zip.file('classes/BrevoDeployValidator.cls-meta.xml', deployValidatorMeta);
        
        // Add package.xml for metadata
        // All fields are embedded in .object files, so we only list CustomObject
        // Lead and Contact are listed to deploy the custom fields we added to them
        const packageXml = `<?xml version="1.0" encoding="UTF-8"?>
<Package xmlns="http://soap.sforce.com/2006/04/metadata">
    <types>
        <members>BrevoDeployValidator</members>
        <name>ApexClass</name>
    </types>
    <types>
        <members>Brevo_Conversation__c</members>
        <members>Brevo_Message__c</members>
        <members>Brevo_Message_Event__e</members>
        <members>Brevo_Saved_Response__c</members>
        <members>Brevo_Settings__c</members>
        <members>Email_Template_Colegio__c</members>
        <members>Lead</members>
        <members>Contact</members>
        <name>CustomObject</name>
    </types>
    <types>
        <members>Brevo_API</members>
        <name>NamedCredential</name>
    </types>
    <types>
        <members>Brevo_API</members>
        <name>RemoteSiteSetting</name>
    </types>
    <version>62.0</version>
</Package>`;
        zip.file('package.xml', packageXml);
        
        // Generate ZIP
        const zipContent = await zip.generateAsync({ 
            type: 'nodebuffer',
            compression: 'DEFLATE',
            compressionOptions: { level: 9 }
        });
        
        return new NextResponse(zipContent, {
            headers: {
                'Content-Type': 'application/zip',
                'Content-Disposition': 'attachment; filename="1-brevo-metadata.zip"',
                'Content-Length': String(zipContent.length),
            },
        });
    } catch (error) {
        console.error('Error generating ZIP:', error);
        return NextResponse.json({ error: 'Failed to generate ZIP' }, { status: 500 });
    }
}
