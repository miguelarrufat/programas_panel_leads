import { NextResponse } from 'next/server';
import JSZip from 'jszip';
import { readdir, stat, readFile } from 'fs/promises';
import { join, relative } from 'path';

const SOURCE_DIR = process.cwd() + '/salesforce/force-app/main/default';

async function getAllFiles(dir: string, fileList: string[] = []): Promise<string[]> {
    const files = await readdir(dir);
    for (const file of files) {
        const filePath = join(dir, file);
        const fileStat = await stat(filePath);
        if (fileStat.isDirectory()) {
            await getAllFiles(filePath, fileList);
        } else {
            fileList.push(filePath);
        }
    }
    return fileList;
}

export async function GET() {
    try {
        const zip = new JSZip();
        const files = await getAllFiles(SOURCE_DIR);
        
        // Add files to archive
        for (const file of files) {
            const relativePath = relative(SOURCE_DIR, file);
            const content = await readFile(file);
            zip.file(relativePath, content);
        }
        
        // Generate ZIP
        const zipContent = await zip.generateAsync({ 
            type: 'nodebuffer',
            compression: 'DEFLATE',
            compressionOptions: { level: 9 }
        });
        
        return new NextResponse(zipContent, {
            headers: {
                'Content-Type': 'application/zip',
                'Content-Disposition': 'attachment; filename="brevo-salesforce-lwc.zip"',
                'Content-Length': String(zipContent.length),
            },
        });
    } catch (error) {
        console.error('Error generating ZIP:', error);
        return NextResponse.json({ error: 'Failed to generate ZIP' }, { status: 500 });
    }
}
