import { NextRequest, NextResponse } from "next/server"
import JSZip from "jszip"
import fs from "fs"
import path from "path"

/**
 * Converts SFDX decomposed field files into a single Metadata API .object file.
 * Workbench expects: objects/Lead.object (with <fields> inside)
 * SFDX has: objects/Lead/fields/MyField__c.field-meta.xml (individual files)
 */
function buildObjectXmlFromFields(fieldsDir: string): string {
  const fieldFiles = fs.readdirSync(fieldsDir).filter((f) => f.endsWith(".field-meta.xml"))
  let fieldsXml = ""

  for (const file of fieldFiles) {
    const content = fs.readFileSync(path.join(fieldsDir, file), "utf-8")
    // Extract the inner content of <CustomField>, strip the root tag and xmlns
    const innerMatch = content.match(/<CustomField[^>]*>([\s\S]*)<\/CustomField>/)
    if (innerMatch) {
      fieldsXml += `    <fields>${innerMatch[1]}    </fields>\n`
    }
  }

  return `<?xml version="1.0" encoding="UTF-8"?>
<CustomObject xmlns="http://soap.sforce.com/2006/04/metadata">
${fieldsXml}</CustomObject>`
}

/**
 * Builds a Platform Event .object file by merging the object-meta.xml with its field files
 */
function buildPlatformEventObjectXml(objectDir: string): string {
  const objectMetaPath = fs.readdirSync(objectDir).find((f) => f.endsWith(".object-meta.xml"))
  if (!objectMetaPath) return ""

  const objectContent = fs.readFileSync(path.join(objectDir, objectMetaPath), "utf-8")
  // Read field files
  const fieldsDir = path.join(objectDir, "fields")
  let fieldsXml = ""

  if (fs.existsSync(fieldsDir)) {
    const fieldFiles = fs.readdirSync(fieldsDir).filter((f) => f.endsWith(".field-meta.xml"))
    for (const file of fieldFiles) {
      const content = fs.readFileSync(path.join(fieldsDir, file), "utf-8")
      const innerMatch = content.match(/<CustomField[^>]*>([\s\S]*)<\/CustomField>/)
      if (innerMatch) {
        fieldsXml += `    <fields>${innerMatch[1]}    </fields>\n`
      }
    }
  }

  // Insert fields before </CustomObject>
  return objectContent.replace("</CustomObject>", `${fieldsXml}</CustomObject>`)
}

function addFolderToZip(zip: JSZip, folderPath: string, zipFolderPath: string) {
  if (!fs.existsSync(folderPath)) return
  const items = fs.readdirSync(folderPath)
  for (const item of items) {
    const fullPath = path.join(folderPath, item)
    const zipPath = zipFolderPath ? `${zipFolderPath}/${item}` : item
    const stat = fs.statSync(fullPath)
    if (stat.isDirectory()) {
      addFolderToZip(zip, fullPath, zipPath)
    } else {
      zip.file(zipPath, fs.readFileSync(fullPath))
    }
  }
}

export async function GET(request: NextRequest) {
  try {
    const phase = request.nextUrl.searchParams.get("phase") || "1"
    const baseDir = path.join(process.cwd(), "salesforce/force-app/main/default")
    const salesforceDir = path.join(process.cwd(), "salesforce")

    if (!fs.existsSync(baseDir)) {
      return NextResponse.json({ error: "Salesforce directory not found" }, { status: 404 })
    }

    const zip = new JSZip()

    if (phase === "1") {
      // Phase 1: Fields, Platform Event, Named Credential, Remote Site
      const packageXml = fs.readFileSync(path.join(salesforceDir, "phase1-package.xml"), "utf-8")
      zip.file("package.xml", packageXml)

      // Standard objects: convert SFDX decomposed fields -> single .object file
      const leadFieldsDir = path.join(baseDir, "objects/Lead/fields")
      if (fs.existsSync(leadFieldsDir)) {
        zip.file("objects/Lead.object", buildObjectXmlFromFields(leadFieldsDir))
      }

      const contactFieldsDir = path.join(baseDir, "objects/Contact/fields")
      if (fs.existsSync(contactFieldsDir)) {
        zip.file("objects/Contact.object", buildObjectXmlFromFields(contactFieldsDir))
      }

      // Platform Event: merge object + fields into single .object file
      const peDir = path.join(baseDir, "objects/Brevo_Message_Event__e")
      if (fs.existsSync(peDir)) {
        zip.file(
          "objects/Brevo_Message_Event__e.object",
          buildPlatformEventObjectXml(peDir)
        )
      }

      // Named Credential (rename from .namedCredential-meta.xml to .namedCredential)
      const ncFile = path.join(baseDir, "namedCredentials/Brevo_API.namedCredential-meta.xml")
      if (fs.existsSync(ncFile)) {
        zip.file("namedCredentials/Brevo_API.namedCredential", fs.readFileSync(ncFile))
      }

      // Remote Site Setting (rename from .remoteSite-meta.xml to .remoteSite)
      const rsFile = path.join(baseDir, "remoteSiteSettings/Brevo_API.remoteSite-meta.xml")
      if (fs.existsSync(rsFile)) {
        zip.file("remoteSiteSettings/Brevo_API.remoteSite", fs.readFileSync(rsFile))
      }

      // Deploy validator test class (needed for RunSpecifiedTests in production)
      const validatorCls = path.join(baseDir, "classes/BrevoDeployValidator.cls")
      const validatorMeta = path.join(baseDir, "classes/BrevoDeployValidator.cls-meta.xml")
      if (fs.existsSync(validatorCls)) {
        zip.file("classes/BrevoDeployValidator.cls", fs.readFileSync(validatorCls))
      }
      if (fs.existsSync(validatorMeta)) {
        zip.file("classes/BrevoDeployValidator.cls-meta.xml", fs.readFileSync(validatorMeta))
      }
    } else if (phase === "2") {
      // Phase 2: Apex + LWC
      const packageXml = fs.readFileSync(path.join(salesforceDir, "phase2-package.xml"), "utf-8")
      zip.file("package.xml", packageXml)

      // Apex classes: only include the 4 classes listed in phase2-package.xml
      const phase2Classes = [
        "BrevoConversationsController",
        "BrevoConversationsControllerTest",
        "BrevoFieldUpdater",
        "BrevoFieldUpdaterTest",
      ]
      const classesDir = path.join(baseDir, "classes")
      if (fs.existsSync(classesDir)) {
        for (const className of phase2Classes) {
          const clsFile = path.join(classesDir, `${className}.cls`)
          const metaFile = path.join(classesDir, `${className}.cls-meta.xml`)
          if (fs.existsSync(clsFile)) {
            zip.file(`classes/${className}.cls`, fs.readFileSync(clsFile))
          }
          if (fs.existsSync(metaFile)) {
            zip.file(`classes/${className}.cls-meta.xml`, fs.readFileSync(metaFile))
          }
        }
      }

      // LWC components: keep folder structure
      const lwcDir = path.join(baseDir, "lwc")
      if (fs.existsSync(lwcDir)) {
        addFolderToZip(zip, lwcDir, "lwc")
      }
    } else if (phase === "3") {
      // Phase 3: Custom Setting + Updated Apex Controller
      const packageXml = fs.readFileSync(path.join(salesforceDir, "phase3-package.xml"), "utf-8")
      zip.file("package.xml", packageXml)

      // Custom Setting: build single .object file with field inside
      const csDir = path.join(baseDir, "objects/Brevo_Settings__c")
      if (fs.existsSync(csDir)) {
        const objectMetaPath = path.join(csDir, "Brevo_Settings__c.object-meta.xml")
        let objectContent = fs.readFileSync(objectMetaPath, "utf-8")

        const fieldsDir = path.join(csDir, "fields")
        if (fs.existsSync(fieldsDir)) {
          let fieldsXml = ""
          const fieldFiles = fs.readdirSync(fieldsDir).filter((f: string) => f.endsWith(".field-meta.xml"))
          for (const file of fieldFiles) {
            const content = fs.readFileSync(path.join(fieldsDir, file), "utf-8")
            const innerMatch = content.match(/<CustomField[^>]*>([\s\S]*)<\/CustomField>/)
            if (innerMatch) {
              fieldsXml += `    <fields>${innerMatch[1]}    </fields>\n`
            }
          }
          objectContent = objectContent.replace("</CustomObject>", `${fieldsXml}</CustomObject>`)
        }

        zip.file("objects/Brevo_Settings__c.object", objectContent)
      }

      // Updated Apex Controller + Test + Validator
      const phase3Classes = ["BrevoConversationsController", "BrevoConversationsControllerTest", "BrevoFieldUpdater", "BrevoFieldUpdaterTest", "BrevoDeployValidator"]
      const classesDir = path.join(baseDir, "classes")
      for (const className of phase3Classes) {
        const clsFile = path.join(classesDir, `${className}.cls`)
        const metaFile = path.join(classesDir, `${className}.cls-meta.xml`)
        if (fs.existsSync(clsFile)) {
          zip.file(`classes/${className}.cls`, fs.readFileSync(clsFile))
        }
        if (fs.existsSync(metaFile)) {
          zip.file(`classes/${className}.cls-meta.xml`, fs.readFileSync(metaFile))
        }
      }

      // LWC components (updated brevoInbox + brevoRecordChat)
      const lwcDir = path.join(baseDir, "lwc")
      if (fs.existsSync(lwcDir)) {
        const lwcComponents = ["brevoInbox", "brevoRecordChat"]
        for (const comp of lwcComponents) {
          const compDir = path.join(lwcDir, comp)
          if (fs.existsSync(compDir)) {
            addFolderToZip(zip, compDir, `lwc/${comp}`)
          }
        }
      }
    } else if (phase === "4") {
      // Phase 4: Email/WhatsApp/SMS sending + CRM check
      const packageXml = fs.readFileSync(path.join(salesforceDir, "phase4-package.xml"), "utf-8")
      zip.file("package.xml", packageXml)

      // Custom Setting: build single .object file with ALL fields (including new sender fields)
      const csDir = path.join(baseDir, "objects/Brevo_Settings__c")
      if (fs.existsSync(csDir)) {
        const objectMetaPath = path.join(csDir, "Brevo_Settings__c.object-meta.xml")
        let objectContent = fs.readFileSync(objectMetaPath, "utf-8")

        const fieldsDir = path.join(csDir, "fields")
        if (fs.existsSync(fieldsDir)) {
          let fieldsXml = ""
          const fieldFiles = fs.readdirSync(fieldsDir).filter((f: string) => f.endsWith(".field-meta.xml"))
          for (const file of fieldFiles) {
            const content = fs.readFileSync(path.join(fieldsDir, file), "utf-8")
            const innerMatch = content.match(/<CustomField[^>]*>([\s\S]*)<\/CustomField>/)
            if (innerMatch) {
              fieldsXml += `    <fields>${innerMatch[1]}    </fields>\n`
            }
          }
          objectContent = objectContent.replace("</CustomObject>", `${fieldsXml}</CustomObject>`)
        }

        zip.file("objects/Brevo_Settings__c.object", objectContent)
      }

      // Apex classes (updated controller + test + updater + validator)
      const phase4Classes = ["BrevoConversationsController", "BrevoConversationsControllerTest", "BrevoFieldUpdater", "BrevoFieldUpdaterTest", "BrevoDeployValidator"]
      const classesDir4 = path.join(baseDir, "classes")
      for (const className of phase4Classes) {
        const clsFile = path.join(classesDir4, `${className}.cls`)
        const metaFile = path.join(classesDir4, `${className}.cls-meta.xml`)
        if (fs.existsSync(clsFile)) {
          zip.file(`classes/${className}.cls`, fs.readFileSync(clsFile))
        }
        if (fs.existsSync(metaFile)) {
          zip.file(`classes/${className}.cls-meta.xml`, fs.readFileSync(metaFile))
        }
      }

      // LWC components (updated brevoInbox + brevoRecordChat with send modals)
      const lwcDir4 = path.join(baseDir, "lwc")
      if (fs.existsSync(lwcDir4)) {
        const lwcComponents = ["brevoInbox", "brevoRecordChat"]
        for (const comp of lwcComponents) {
          const compDir = path.join(lwcDir4, comp)
          if (fs.existsSync(compDir)) {
            addFolderToZip(zip, compDir, `lwc/${comp}`)
          }
        }
      }
    } else if (phase === "5") {
      // Phase 5: Webhook handler (Brevo -> Salesforce)
      const packageXml = fs.readFileSync(path.join(salesforceDir, "phase5-package.xml"), "utf-8")
      zip.file("package.xml", packageXml)

      // Apex classes: webhook handler + test + field updater + validator
      const phase5Classes = ["BrevoWebhookHandler", "BrevoWebhookHandlerTest", "BrevoFieldUpdater", "BrevoFieldUpdaterTest", "BrevoDeployValidator"]
      const classesDir5 = path.join(baseDir, "classes")
      for (const className of phase5Classes) {
        const clsFile = path.join(classesDir5, `${className}.cls`)
        const metaFile = path.join(classesDir5, `${className}.cls-meta.xml`)
        if (fs.existsSync(clsFile)) {
          zip.file(`classes/${className}.cls`, fs.readFileSync(clsFile))
        }
        if (fs.existsSync(metaFile)) {
          zip.file(`classes/${className}.cls-meta.xml`, fs.readFileSync(metaFile))
        }
      }
    }

    if (phase === "6") {
      // Phase 6: UNIFIED - Custom objects + Apex + LWCs (single deploy for production)
      const packageXml = fs.readFileSync(path.join(salesforceDir, "phase6-package.xml"), "utf-8")
      zip.file("package.xml", packageXml)

      // Custom Objects + Custom Settings
      const customObjects6 = ["Brevo_Conversation__c", "Brevo_Message__c", "Brevo_Settings__c"]
      for (const objName of customObjects6) {
        const objDir = path.join(baseDir, `objects/${objName}`)
        if (fs.existsSync(objDir)) {
          zip.file(
            `objects/${objName}.object`,
            buildPlatformEventObjectXml(objDir)
          )
        }
      }

      // All Apex classes
      const phase6AllClasses = [
        "BrevoConversationsController",
        "BrevoConversationsControllerTest",
        "BrevoFieldUpdater",
        "BrevoFieldUpdaterTest",
        "BrevoWebhookHandler",
        "BrevoWebhookHandlerTest",
        "BrevoDeployValidator",
      ]
      const classesDir6All = path.join(baseDir, "classes")
      for (const className of phase6AllClasses) {
        const clsFile = path.join(classesDir6All, `${className}.cls`)
        const metaFile = path.join(classesDir6All, `${className}.cls-meta.xml`)
        if (fs.existsSync(clsFile)) {
          zip.file(`classes/${className}.cls`, fs.readFileSync(clsFile))
        }
        if (fs.existsSync(metaFile)) {
          zip.file(`classes/${className}.cls-meta.xml`, fs.readFileSync(metaFile))
        }
      }

      // LWC components
      const lwcDir6All = path.join(baseDir, "lwc")
      if (fs.existsSync(lwcDir6All)) {
        const lwcComponents = ["brevoInbox", "brevoRecordChat"]
        for (const comp of lwcComponents) {
          const compDir = path.join(lwcDir6All, comp)
          if (fs.existsSync(compDir)) {
            addFolderToZip(zip, compDir, `lwc/${comp}`)
          }
        }
      }
    }

    if (phase === "6a") {
      // Phase 6a: Custom objects + Settings + validator (deploy first, production-safe)
      const packageXml = fs.readFileSync(path.join(salesforceDir, "phase6a-package.xml"), "utf-8")
      zip.file("package.xml", packageXml)

      const customObjects6a = ["Brevo_Conversation__c", "Brevo_Message__c", "Brevo_Settings__c"]
      for (const objName of customObjects6a) {
        const objDir = path.join(baseDir, `objects/${objName}`)
        if (fs.existsSync(objDir)) {
          zip.file(
            `objects/${objName}.object`,
            buildPlatformEventObjectXml(objDir)
          )
        }
      }

      // BrevoDeployValidator (minimal test class for RunSpecifiedTests in production)
      const validatorCls6a = path.join(baseDir, "classes/BrevoDeployValidator.cls")
      const validatorMeta6a = path.join(baseDir, "classes/BrevoDeployValidator.cls-meta.xml")
      if (fs.existsSync(validatorCls6a)) {
        zip.file("classes/BrevoDeployValidator.cls", fs.readFileSync(validatorCls6a))
      }
      if (fs.existsSync(validatorMeta6a)) {
        zip.file("classes/BrevoDeployValidator.cls-meta.xml", fs.readFileSync(validatorMeta6a))
      }
    }

    if (phase === "6b") {
      // Phase 6b: Apex classes + LWCs (deploy AFTER 6a)
      const packageXml = fs.readFileSync(path.join(salesforceDir, "phase6b-package.xml"), "utf-8")
      zip.file("package.xml", packageXml)

      // All Apex classes
      const phase6Classes = [
        "BrevoConversationsController",
        "BrevoConversationsControllerTest",
        "BrevoFieldUpdater",
        "BrevoFieldUpdaterTest",
        "BrevoWebhookHandler",
        "BrevoWebhookHandlerTest",
        "BrevoDeployValidator",
      ]
      const classesDir6 = path.join(baseDir, "classes")
      for (const className of phase6Classes) {
        const clsFile = path.join(classesDir6, `${className}.cls`)
        const metaFile = path.join(classesDir6, `${className}.cls-meta.xml`)
        if (fs.existsSync(clsFile)) {
          zip.file(`classes/${className}.cls`, fs.readFileSync(clsFile))
        }
        if (fs.existsSync(metaFile)) {
          zip.file(`classes/${className}.cls-meta.xml`, fs.readFileSync(metaFile))
        }
      }

      // LWC components
      const lwcDir6 = path.join(baseDir, "lwc")
      if (fs.existsSync(lwcDir6)) {
        const lwcComponents = ["brevoInbox", "brevoRecordChat"]
        for (const comp of lwcComponents) {
          const compDir = path.join(lwcDir6, comp)
          if (fs.existsSync(compDir)) {
            addFolderToZip(zip, compDir, `lwc/${comp}`)
          }
        }
      }
    }

    if (phase === "7a") {
      // Phase 7a: New objects + fields (deploy BEFORE 7b)
      const phase7aPackage = `<?xml version="1.0" encoding="UTF-8"?>
<Package xmlns="http://soap.sforce.com/2006/04/metadata">
    <types>
        <members>BrevoDeployValidator</members>
        <name>ApexClass</name>
    </types>
    <types>
        <members>Brevo_Conversation__c</members>
        <members>Brevo_Saved_Response__c</members>
        <name>CustomObject</name>
    </types>
    <version>62.0</version>
</Package>`
      zip.file("package.xml", phase7aPackage)

      // BrevoDeployValidator (test class for RunSpecifiedTests in production)
      const validatorCls = path.join(baseDir, "classes/BrevoDeployValidator.cls")
      const validatorMeta = path.join(baseDir, "classes/BrevoDeployValidator.cls-meta.xml")
      if (fs.existsSync(validatorCls)) {
        zip.file("classes/BrevoDeployValidator.cls", fs.readFileSync(validatorCls))
      }
      if (fs.existsSync(validatorMeta)) {
        zip.file("classes/BrevoDeployValidator.cls-meta.xml", fs.readFileSync(validatorMeta))
      }

      // Brevo_Conversation__c (includes new Last_Visitor_Message_Date__c)
      const convObjDir = path.join(baseDir, "objects/Brevo_Conversation__c")
      if (fs.existsSync(convObjDir)) {
        zip.file("objects/Brevo_Conversation__c.object", buildPlatformEventObjectXml(convObjDir))
      }

      // Brevo_Saved_Response__c (new object)
      const srObjDir = path.join(baseDir, "objects/Brevo_Saved_Response__c")
      if (fs.existsSync(srObjDir)) {
        zip.file("objects/Brevo_Saved_Response__c.object", buildPlatformEventObjectXml(srObjDir))
      }
    }

    if (phase === "7b") {
      // Phase 7b: Apex classes + LWCs (deploy AFTER 7a)
      const phase7bPackage = `<?xml version="1.0" encoding="UTF-8"?>
<Package xmlns="http://soap.sforce.com/2006/04/metadata">
    <types>
        <members>BrevoConversationsController</members>
        <members>BrevoConversationsControllerTest</members>
        <members>BrevoFieldUpdater</members>
        <members>BrevoFieldUpdaterTest</members>
        <members>BrevoWebhookHandler</members>
        <members>BrevoWebhookHandlerTest</members>
        <members>BrevoDeployValidator</members>
        <name>ApexClass</name>
    </types>
    <types>
        <members>brevoInbox</members>
        <members>brevoRecordChat</members>
        <name>LightningComponentBundle</name>
    </types>
    <version>62.0</version>
</Package>`
      zip.file("package.xml", phase7bPackage)

      const phase7Classes = [
        "BrevoConversationsController",
        "BrevoConversationsControllerTest",
        "BrevoFieldUpdater",
        "BrevoFieldUpdaterTest",
        "BrevoWebhookHandler",
        "BrevoWebhookHandlerTest",
        "BrevoDeployValidator",
      ]
      const classesDir7 = path.join(baseDir, "classes")
      for (const className of phase7Classes) {
        const clsFile = path.join(classesDir7, `${className}.cls`)
        const metaFile = path.join(classesDir7, `${className}.cls-meta.xml`)
        if (fs.existsSync(clsFile)) {
          zip.file(`classes/${className}.cls`, fs.readFileSync(clsFile))
        }
        if (fs.existsSync(metaFile)) {
          zip.file(`classes/${className}.cls-meta.xml`, fs.readFileSync(metaFile))
        }
      }

      // LWC components
      const lwcDir7 = path.join(baseDir, "lwc")
      if (fs.existsSync(lwcDir7)) {
        const lwcComponents7 = ["brevoInbox", "brevoRecordChat"]
        for (const comp of lwcComponents7) {
          const compDir = path.join(lwcDir7, comp)
          if (fs.existsSync(compDir)) {
            addFolderToZip(zip, compDir, `lwc/${comp}`)
          }
        }
      }
    }

    // ─── Phase 8: Lead auto-conversation + migration ─────────────
    if (phase === "8") {
      const phase8Package = `<?xml version="1.0" encoding="UTF-8"?>
<Package xmlns="http://soap.sforce.com/2006/04/metadata">
    <types>
        <members>BrevoLeadTriggerHandler</members>
        <members>BrevoLeadTriggerHandlerTest</members>
        <name>ApexClass</name>
    </types>
    <types>
        <members>BrevoLeadTrigger</members>
        <name>ApexTrigger</name>
    </types>
    <version>62.0</version>
</Package>`
      zip.file("package.xml", phase8Package)

      // Apex classes
      const phase8Classes = [
        "BrevoLeadTriggerHandler",
        "BrevoLeadTriggerHandlerTest",
      ]
      const classesDir8 = path.join(baseDir, "classes")
      for (const className of phase8Classes) {
        const clsFile = path.join(classesDir8, `${className}.cls`)
        const metaFile = path.join(classesDir8, `${className}.cls-meta.xml`)
        if (fs.existsSync(clsFile)) {
          zip.file(`classes/${className}.cls`, fs.readFileSync(clsFile))
        }
        if (fs.existsSync(metaFile)) {
          zip.file(`classes/${className}.cls-meta.xml`, fs.readFileSync(metaFile))
        }
      }

      // Trigger
      const triggersDir = path.join(baseDir, "triggers")
      const triggerFile = path.join(triggersDir, "BrevoLeadTrigger.trigger")
      const triggerMeta = path.join(triggersDir, "BrevoLeadTrigger.trigger-meta.xml")
      if (fs.existsSync(triggerFile)) {
        zip.file("triggers/BrevoLeadTrigger.trigger", fs.readFileSync(triggerFile))
      }
      if (fs.existsSync(triggerMeta)) {
        zip.file("triggers/BrevoLeadTrigger.trigger-meta.xml", fs.readFileSync(triggerMeta))
      }
    }

    // ─── Phase 9a: Apex controller update (getEmailTemplates) ───
    if (phase === "9a") {
      const phase9aPackage = `<?xml version="1.0" encoding="UTF-8"?>
<Package xmlns="http://soap.sforce.com/2006/04/metadata">
    <types>
        <members>BrevoConversationsController</members>
        <members>BrevoConversationsControllerTest</members>
        <name>ApexClass</name>
    </types>
    <version>62.0</version>
</Package>`
      zip.file("package.xml", phase9aPackage)

      const classesDir9 = path.join(baseDir, "classes")
      for (const cls of ["BrevoConversationsController", "BrevoConversationsControllerTest"]) {
        const clsFile = path.join(classesDir9, `${cls}.cls`)
        const metaFile = path.join(classesDir9, `${cls}.cls-meta.xml`)
        if (fs.existsSync(clsFile)) zip.file(`classes/${cls}.cls`, fs.readFileSync(clsFile))
        if (fs.existsSync(metaFile)) zip.file(`classes/${cls}.cls-meta.xml`, fs.readFileSync(metaFile))
      }
    }

    // ─── Phase 9b: LWC improvements (modals, email editor, tabs) ─
    if (phase === "9b") {
      const phase9bPackage = `<?xml version="1.0" encoding="UTF-8"?>
<Package xmlns="http://soap.sforce.com/2006/04/metadata">
    <types>
        <members>brevoInbox</members>
        <members>brevoRecordChat</members>
        <name>LightningComponentBundle</name>
    </types>
    <version>62.0</version>
</Package>`
      zip.file("package.xml", phase9bPackage)

      const lwcDir9 = path.join(baseDir, "lwc")
      for (const comp of ["brevoInbox", "brevoRecordChat"]) {
        const compDir = path.join(lwcDir9, comp)
        if (fs.existsSync(compDir)) {
          addFolderToZip(zip, compDir, `lwc/${comp}`)
        }
      }
    }

    // ─── Phase 10a: Bridge object Email_Template_Colegio__c ─────
    if (phase === "10a") {
      const phase10aPackage = `<?xml version="1.0" encoding="UTF-8"?>
<Package xmlns="http://soap.sforce.com/2006/04/metadata">
    <types>
        <members>Email_Template_Colegio__c</members>
        <name>CustomObject</name>
    </types>
    <types>
        <members>BrevoLeadTriggerHandlerTest</members>
        <name>ApexClass</name>
    </types>
    <version>62.0</version>
</Package>`
      zip.file("package.xml", phase10aPackage)

      // Build combined .object XML from SFDX folder structure
      const objDir10 = path.join(baseDir, "objects", "Email_Template_Colegio__c")
      if (fs.existsSync(objDir10)) {
        zip.file("objects/Email_Template_Colegio__c.object", buildPlatformEventObjectXml(objDir10))
      }

      // Include test class for production deployment
      const classesDir10a = path.join(baseDir, "classes")
      const testCls = path.join(classesDir10a, "BrevoLeadTriggerHandlerTest.cls")
      const testMeta = path.join(classesDir10a, "BrevoLeadTriggerHandlerTest.cls-meta.xml")
      if (fs.existsSync(testCls)) zip.file("classes/BrevoLeadTriggerHandlerTest.cls", fs.readFileSync(testCls))
      if (fs.existsSync(testMeta)) zip.file("classes/BrevoLeadTriggerHandlerTest.cls-meta.xml", fs.readFileSync(testMeta))
    }

    // ─── Phase 10b: Apex controller (getEmailTemplates with accountId) ─
    if (phase === "10b") {
      const phase10bPackage = `<?xml version="1.0" encoding="UTF-8"?>
<Package xmlns="http://soap.sforce.com/2006/04/metadata">
    <types>
        <members>BrevoConversationsController</members>
        <members>BrevoConversationsControllerTest</members>
        <name>ApexClass</name>
    </types>
    <version>62.0</version>
</Package>`
      zip.file("package.xml", phase10bPackage)

      const classesDir10 = path.join(baseDir, "classes")
      for (const cls of ["BrevoConversationsController", "BrevoConversationsControllerTest"]) {
        const clsFile = path.join(classesDir10, `${cls}.cls`)
        const metaFile = path.join(classesDir10, `${cls}.cls-meta.xml`)
        if (fs.existsSync(clsFile)) zip.file(`classes/${cls}.cls`, fs.readFileSync(clsFile))
        if (fs.existsSync(metaFile)) zip.file(`classes/${cls}.cls-meta.xml`, fs.readFileSync(metaFile))
      }
    }

    // ─── Phase 10c: LWC (pass accountId to email templates) ──────
    if (phase === "10c") {
      const phase10cPackage = `<?xml version="1.0" encoding="UTF-8"?>
<Package xmlns="http://soap.sforce.com/2006/04/metadata">
    <types>
        <members>brevoInbox</members>
        <members>brevoRecordChat</members>
        <name>LightningComponentBundle</name>
    </types>
    <version>62.0</version>
</Package>`
      zip.file("package.xml", phase10cPackage)

      const lwcDir10 = path.join(baseDir, "lwc")
      for (const comp of ["brevoInbox", "brevoRecordChat"]) {
        const compDir = path.join(lwcDir10, comp)
        if (fs.existsSync(compDir)) {
          addFolderToZip(zip, compDir, `lwc/${comp}`)
        }
      }
    }

    const zipBuffer = await zip.generateAsync({ type: "nodebuffer" })
    const filenames: Record<string, string> = {
      "1": "brevo-fase1-campos.zip",
      "2": "brevo-fase2-apex-lwc.zip",
      "3": "brevo-fase3-apikey.zip",
      "4": "brevo-fase4-email-wa-sms.zip",
      "5": "brevo-fase5-webhook.zip",
      "6": "brevo-fase6-conversaciones-persistidas.zip",
      "6a": "brevo-fase6a-objetos-custom.zip",
      "6b": "brevo-fase6b-apex-lwc.zip",
      "7a": "brevo-fase7a-nuevos-objetos.zip",
      "7b": "brevo-fase7b-mejoras-inbox.zip",
      "8": "brevo-fase8-lead-autoconv.zip",
      "9a": "brevo-fase9a-apex-email-templates.zip",
      "9b": "brevo-fase9b-lwc-mejoras.zip",
      "10a": "brevo-fase10a-objeto-puente.zip",
      "10b": "brevo-fase10b-apex-filtro-colegio.zip",
      "10c": "brevo-fase10c-lwc-accountid.zip",
    }
    const filename = filenames[phase] || "brevo-deploy.zip"

    return new NextResponse(zipBuffer, {
      headers: {
        "Content-Type": "application/zip",
        "Content-Disposition": `attachment; filename=${filename}`,
      },
    })
  } catch (error) {
    return NextResponse.json({ error: String(error) }, { status: 500 })
  }
}
