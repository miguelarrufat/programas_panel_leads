import { NextRequest, NextResponse } from "next/server"

/**
 * Webhook Bridge: Brevo Conversations -> Salesforce
 *
 * Brevo sends simple HTTP POST webhooks when conversation events occur.
 * This route authenticates to Salesforce via OAuth 2.0 (password flow)
 * and updates Lead/Contact Brevo fields + Brevo_Visitor_Id__c.
 *
 * Required env vars:
 * - SF_LOGIN_URL: https://login.salesforce.com (prod) or https://test.salesforce.com (sandbox)
 * - SF_CLIENT_ID: Consumer Key from Connected App
 * - SF_CLIENT_SECRET: Consumer Secret from Connected App
 * - SF_USERNAME: Integration user username
 * - SF_PASSWORD: Password + Security Token concatenated
 *
 * Optional:
 * - BREVO_WEBHOOK_SECRET: Secret to validate webhook origin
 */

// ─── SALESFORCE OAUTH ────────────────────────────────────────────
interface SfTokenResponse {
  access_token: string
  instance_url: string
  token_type: string
}

let cachedToken: SfTokenResponse | null = null
let tokenExpiresAt = 0

async function getSalesforceToken(): Promise<SfTokenResponse> {
  if (cachedToken && Date.now() < tokenExpiresAt) {
    return cachedToken
  }

  const loginUrl = process.env.SF_LOGIN_URL || "https://login.salesforce.com"

  const response = await fetch(`${loginUrl}/services/oauth2/token`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "password",
      client_id: process.env.SF_CLIENT_ID || "",
      client_secret: process.env.SF_CLIENT_SECRET || "",
      username: process.env.SF_USERNAME || "",
      password: process.env.SF_PASSWORD || "",
    }),
  })

  if (!response.ok) {
    const errorText = await response.text()
    throw new Error(`SF OAuth failed: ${response.status} ${errorText}`)
  }

  cachedToken = (await response.json()) as SfTokenResponse
  tokenExpiresAt = Date.now() + 1.5 * 60 * 60 * 1000 // 1.5h cache
  return cachedToken
}

// ─── HELPER: SOQL query ──────────────────────────────────────────
async function sfQuery(
  token: SfTokenResponse,
  soql: string
): Promise<{ records: Record<string, unknown>[] }> {
  const res = await fetch(
    `${token.instance_url}/services/data/v62.0/query?q=${encodeURIComponent(soql)}`,
    { headers: { Authorization: `Bearer ${token.access_token}` } }
  )
  if (!res.ok) {
    console.error(`[v0] SOQL query failed: ${res.status} ${await res.text()}`)
    return { records: [] }
  }
  return res.json()
}

// ─── HELPER: PATCH record ────────────────────────────────────────
async function sfPatch(
  token: SfTokenResponse,
  objectName: string,
  recordId: string,
  body: Record<string, unknown>
): Promise<boolean> {
  const res = await fetch(
    `${token.instance_url}/services/data/v62.0/sobjects/${objectName}/${recordId}`,
    {
      method: "PATCH",
      headers: {
        Authorization: `Bearer ${token.access_token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(body),
    }
  )
  if (!res.ok) {
    console.error(
      `[v0] PATCH ${objectName}/${recordId} failed: ${res.status} ${await res.text()}`
    )
    return false
  }
  return true
}

// ─── FIND AND UPDATE RECORDS ─────────────────────────────────────
async function findAndUpdateRecords(
  token: SfTokenResponse,
  identifier: string,
  visitorId: string,
  eventType: string,
  conversationStatus: string
) {
  if (!identifier) return

  const safeId = identifier.replace(/'/g, "\\'")
  const now = new Date().toISOString()

  // Query Leads -- use standard fields + known custom fields
  const leadSoql = `SELECT Id, Brevo_Sin_Leer__c, Brevo_Conv_Abiertas__c, Brevo_Primera_Conversacion__c FROM Lead WHERE IsConverted = false AND (Email = '${safeId}' OR Phone = '${safeId}' OR Additional_Phone_1__c = '${safeId}' OR Additional_Phone_2__c = '${safeId}' OR Email_de_Contacto__c = '${safeId}') LIMIT 5`

  // Query Contacts -- standard phone fields only (safe, no custom field errors)
  const contactSoql = `SELECT Id, Brevo_Sin_Leer__c, Brevo_Conv_Abiertas__c, Brevo_Primera_Conversacion__c FROM Contact WHERE Email = '${safeId}' OR Phone = '${safeId}' OR MobilePhone = '${safeId}' OR HomePhone = '${safeId}' OR OtherPhone = '${safeId}' LIMIT 5`

  const [leadData, contactData] = await Promise.all([
    sfQuery(token, leadSoql),
    sfQuery(token, contactSoql),
  ])

  const updates: Promise<boolean>[] = []

  // Process Leads
  for (const lead of leadData.records) {
    const body = buildUpdateBody(
      lead as Record<string, number | null | string>,
      eventType,
      conversationStatus,
      now
    )
    if (visitorId) body.Brevo_Visitor_Id__c = visitorId
    updates.push(sfPatch(token, "Lead", lead.Id as string, body))
  }

  // Process Contacts
  for (const contact of contactData.records) {
    const body = buildUpdateBody(
      contact as Record<string, number | null | string>,
      eventType,
      conversationStatus,
      now
    )
    if (visitorId) body.Brevo_Visitor_Id__c = visitorId
    updates.push(sfPatch(token, "Contact", contact.Id as string, body))
  }

  const results = await Promise.all(updates)
  const successCount = results.filter(Boolean).length
  console.log(
    `[v0] Updated ${successCount} records for identifier: ${identifier}`
  )
  return successCount
}

function buildUpdateBody(
  record: Record<string, number | null | string>,
  eventType: string,
  conversationStatus: string,
  now: string
): Record<string, unknown> {
  const body: Record<string, unknown> = {
    Brevo_Ultima_Comunicacion__c: now,
  }

  if (!record.Brevo_Primera_Conversacion__c) {
    body.Brevo_Primera_Conversacion__c = now
  }

  if (
    eventType === "message.received" ||
    eventType === "conversationFragment" ||
    eventType === "conversationStarted"
  ) {
    body.Brevo_Sin_Leer__c =
      ((record.Brevo_Sin_Leer__c as number) || 0) + 1
    body.Brevo_Estado__c = "Sin leer"
    // Increment open conversations only for new conversations
    if (eventType === "conversationStarted") {
      body.Brevo_Conv_Abiertas__c =
        ((record.Brevo_Conv_Abiertas__c as number) || 0) + 1
    }
  } else if (eventType === "conversationTranscript") {
    // Transcript = conversation ended/resolved
    body.Brevo_Conv_Abiertas__c = Math.max(
      0,
      ((record.Brevo_Conv_Abiertas__c as number) || 0) - 1
    )
    body.Brevo_Estado__c =
      ((body.Brevo_Conv_Abiertas__c as number) || 0) > 0
        ? "Abierta"
        : "Sin actividad"
    body.Brevo_Sin_Leer__c = 0
  }

  return body
}

// ─── EXTRACT IDENTIFIERS FROM BREVO PAYLOAD ──────────────────────
function extractIdentifiers(payload: Record<string, unknown>): {
  email: string
  phone: string
  visitorId: string
} {
  const visitor = (payload.visitor || {}) as Record<string, unknown>
  const attrs = (visitor.attributes || {}) as Record<string, string>
  const contactAttrs = (visitor.contactAttributes || {}) as Record<
    string,
    string
  >
  const integrationAttrs = (visitor.integrationAttributes || {}) as Record<
    string,
    string
  >

  const email =
    attrs.EMAIL ||
    attrs.email ||
    contactAttrs.EMAIL ||
    contactAttrs.email ||
    integrationAttrs.EMAIL ||
    integrationAttrs.email ||
    (payload.visitorEmail as string) ||
    ""

  const phone =
    attrs.PHONE ||
    attrs.phone ||
    attrs.SMS ||
    attrs.sms ||
    contactAttrs.PHONE ||
    contactAttrs.phone ||
    contactAttrs.SMS ||
    contactAttrs.sms ||
    integrationAttrs.PHONE ||
    integrationAttrs.phone ||
    (payload.visitorPhone as string) ||
    ""

  const visitorId =
    (visitor.id as string) ||
    (payload.visitorId as string) ||
    ""

  return { email, phone, visitorId }
}

// ─── WEBHOOK SECRET VALIDATION ───────────────────────────────────
function validateWebhookSecret(req: NextRequest): boolean {
  const secret = process.env.BREVO_WEBHOOK_SECRET
  if (!secret) return true // Skip if not configured

  const headerSecret = req.headers.get("x-brevo-secret")
  return headerSecret === secret
}

// ─── MAIN HANDLER ────────────────────────────────────────────────
export async function POST(req: NextRequest) {
  try {
    if (!validateWebhookSecret(req)) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Check required env vars
    if (!process.env.SF_CLIENT_ID || !process.env.SF_USERNAME) {
      console.error(
        "[v0] Missing SF env vars: SF_CLIENT_ID, SF_CLIENT_SECRET, SF_USERNAME, SF_PASSWORD"
      )
      // Still return 200 to Brevo so it doesn't retry
      return NextResponse.json({
        success: false,
        error: "Salesforce credentials not configured",
      })
    }

    const payload = (await req.json()) as Record<string, unknown>
    const eventName =
      (payload.eventName as string) ||
      (payload.event as string) ||
      "unknown"
    const conversationId = (payload.conversationId as string) || ""
    const conversationStatus =
      (payload.conversationStatus as string) || "open"

    console.log(
      `[v0] Brevo webhook received: ${eventName}, conversationId: ${conversationId}`
    )

    const { email, phone, visitorId } = extractIdentifiers(payload)
    const identifier = email || phone

    console.log(
      `[v0] Extracted - email: ${email}, phone: ${phone}, visitorId: ${visitorId}`
    )

    if (!identifier) {
      console.log("[v0] No identifier found in webhook payload, skipping")
      return NextResponse.json({
        success: true,
        event: eventName,
        skipped: "no_identifier",
      })
    }

    // Get SF token and update records
    const sfToken = await getSalesforceToken()

    // Update by email first, then also by phone if different
    let updatedCount = await findAndUpdateRecords(
      sfToken,
      email,
      visitorId,
      eventName,
      conversationStatus
    )

    // If phone is different from email and email found no matches, try phone
    if (phone && phone !== email) {
      const phoneUpdates = await findAndUpdateRecords(
        sfToken,
        phone,
        visitorId,
        eventName,
        conversationStatus
      )
      updatedCount = (updatedCount || 0) + (phoneUpdates || 0)
    }

    return NextResponse.json({
      success: true,
      event: eventName,
      conversationId,
      updatedRecords: updatedCount,
    })
  } catch (error) {
    console.error("[v0] Webhook bridge error:", error)
    // Always return 200 to Brevo to prevent retries
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    })
  }
}

// Health check
export async function GET() {
  const hasCredentials = !!(
    process.env.SF_CLIENT_ID && process.env.SF_USERNAME
  )
  return NextResponse.json({
    status: hasCredentials ? "ok" : "missing_credentials",
    service: "Brevo -> Salesforce Webhook Bridge",
    envVars: {
      SF_LOGIN_URL: !!process.env.SF_LOGIN_URL,
      SF_CLIENT_ID: !!process.env.SF_CLIENT_ID,
      SF_CLIENT_SECRET: !!process.env.SF_CLIENT_SECRET,
      SF_USERNAME: !!process.env.SF_USERNAME,
      SF_PASSWORD: !!process.env.SF_PASSWORD,
    },
  })
}
