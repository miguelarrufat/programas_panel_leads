"use client"

import { useState } from "react"
import { mockConversations } from "@/lib/brevo-data"
import { InboxLayout } from "@/components/brevo/inbox-layout"
import { AppNav } from "@/components/brevo/app-nav"
import { cn } from "@/lib/utils"
import { Users, MessageSquare, MessageCircle, X, Calendar, ListFilter, Building2, Info, Search, Plus, BarChart3, RefreshCw, Pin } from "lucide-react"

// Mock leads data with new fields and diverse statuses
const mockLeads = [
  { id: "1", name: "JMedardo CBaez", studentName: "Carlos Baez Rodriguez", stage: "Primaria", grade: "3ro", year: "2025-2026", status: "New", lastContact: "2026-03-02", convCount: 3, phone: "+593998888330", entryDate: "2026-03-01", school: "Los Pinos", createdDaysAgo: 2 },
  { id: "2", name: "Maria Garcia", studentName: "Sofia Garcia Lopez", stage: "Secundaria", grade: "1ro", year: "2025-2026", status: "New", lastContact: null, convCount: 0, phone: "+593987654321", entryDate: "2026-02-27", school: "San Jose", createdDaysAgo: 5 },
  { id: "3", name: "Carlos Rodriguez", studentName: "Ana Rodriguez Perez", stage: "Infantil", grade: "K3", year: "2025-2026", status: "Convertido", lastContact: "2026-02-19", convCount: 5, phone: "+593912345678", entryDate: "2026-01-08", school: "Academia Central", createdDaysAgo: 30 },
  { id: "4", name: "Ana Martinez", studentName: "Pedro Martinez Ruiz", stage: "Primaria", grade: "5to", year: "2026-2027", status: "Perdido", lastContact: null, convCount: 0, phone: "+593998765432", entryDate: "2026-01-20", school: "Instituto Norte", createdDaysAgo: 45 },
  { id: "5", name: "Pedro Sanchez", studentName: "Lucia Sanchez Vega", stage: "Secundaria", grade: "2do", year: "2025-2026", status: "Granero", lastContact: "2026-02-15", convCount: 2, phone: "+593911223344", entryDate: "2026-01-12", school: "Colegio del Valle", createdDaysAgo: 60 },
  { id: "6", name: "Laura Torres", studentName: "Diego Torres Mendez", stage: "Primaria", grade: "1ro", year: "2026-2027", status: "Pre-Enrollment", lastContact: "2026-02-28", convCount: 4, phone: "+593922334455", entryDate: "2026-02-01", school: "Los Pinos", createdDaysAgo: 15 },
]

// Row color logic based on status and days
const getRowColor = (lead: typeof mockLeads[0]) => {
  // Enrollment (Convertido) - light green
  if (lead.status === "Convertido" || lead.status === "Pre-Enrollment") {
    return "bg-green-50"
  }
  // Perdido - light gray
  if (lead.status === "Perdido") {
    return "bg-gray-100"
  }
  // Granero - blue-gray
  if (lead.status === "Granero") {
    return "bg-slate-200"
  }
  // New without call (4-6 days) - orange/yellow
  if (lead.status === "New" && lead.convCount === 0 && lead.createdDaysAgo >= 4 && lead.createdDaysAgo <= 6) {
    return "bg-amber-50"
  }
  // New (0-3 days) - light blue
  if (lead.status === "New" && lead.createdDaysAgo <= 3) {
    return "bg-blue-50"
  }
  return ""
}

const statusOptions = [
  { value: "", label: "Todos" },
  { value: "New", label: "New" },
  { value: "1er Contacto", label: "First Contact" },
  { value: "School Visit", label: "School Visit" },
  { value: "Entrevista1", label: "Interview" },
  { value: "Solicitud de Plaza", label: "Application for Place" },
  { value: "Prueba de Acceso", label: "Entry Test" },
  { value: "Test Week", label: "Test Week" },
  { value: "Pre-Enrollment", label: "Pre-Enrollment" },
  { value: "Convertido", label: "Enrollment" },
  { value: "Granero", label: "Granero" },
  { value: "Perdido", label: "Perdido" },
]

const yearOptions = [
  { value: "", label: "Todos" },
  { value: "2021-2022", label: "2021-2022" },
  { value: "2022-2023", label: "2022-2023" },
  { value: "2023-2024", label: "2023-2024" },
  { value: "2024-2025", label: "2024-2025" },
  { value: "2025-2026", label: "2025-2026" },
  { value: "2026-2027", label: "2026-2027" },
  { value: "2027-2028", label: "2027-2028" },
  { value: "2028-2029", label: "2028-2029" },
  { value: "2029-2030", label: "2029-2030" },
  { value: "2030-2031", label: "2030-2031" },
]

const schoolOptions = [
  { value: "", label: "Todos" },
  { value: "Los Pinos", label: "Los Pinos" },
  { value: "San Jose", label: "San Jose" },
  { value: "Academia Central", label: "Academia Central" },
  { value: "Instituto Norte", label: "Instituto Norte" },
  { value: "Colegio del Valle", label: "Colegio del Valle" },
]

type Tab = "summary" | "leads" | "conversations"
type SummarySubtab = "leads" | "conversations"

// Mock summary data
const mockSummaryStats = {
  totalLeads: 156,
  newCount: 23,
  enrolledCount: 45,
  lostCount: 12,
  leadsByStatus: [
    { status: "New", count: 23 },
    { status: "1er Contacto", count: 34 },
    { status: "School Visit", count: 28 },
    { status: "Entrevista", count: 18 },
    { status: "Pre-Enrollment", count: 15 },
    { status: "Convertido", count: 45 },
    { status: "Perdido", count: 12 },
  ],
  leadsByStage: [
    { stage: "Infantil", count: 42 },
    { stage: "Primaria", count: 68 },
    { stage: "Secundaria", count: 46 },
  ],
  leadsByGrade: [
    { grade: "K3", count: 15 },
    { grade: "K4", count: 12 },
    { grade: "K5", count: 15 },
    { grade: "1ro Primaria", count: 18 },
    { grade: "2do Primaria", count: 14 },
    { grade: "3ro Primaria", count: 12 },
    { grade: "4to Primaria", count: 10 },
    { grade: "5to Primaria", count: 8 },
    { grade: "6to Primaria", count: 6 },
    { grade: "1ro Secundaria", count: 16 },
    { grade: "2do Secundaria", count: 15 },
    { grade: "3ro Secundaria", count: 15 },
  ],
  weeklyLeads: [
    { week: "W1", count: 8 },
    { week: "W2", count: 12 },
    { week: "W3", count: 15 },
    { week: "W4", count: 10 },
    { week: "W5", count: 18 },
    { week: "W6", count: 14 },
    { week: "W7", count: 22 },
    { week: "W8", count: 16 },
    { week: "W9", count: 19 },
    { week: "W10", count: 13 },
    { week: "W11", count: 17 },
    { week: "W12", count: 20 },
  ],
  lastContactDist: [
    { bucket: "0-3 days", count: 28 },
    { bucket: "4-7 days", count: 35 },
    { bucket: "8-14 days", count: 22 },
    { bucket: "15-30 days", count: 18 },
    { bucket: "30+ days", count: 25 },
    { bucket: "No contact", count: 28 },
  ],
  openConvs: 34,
  closedConvs: 89,
  unlinkedConvs: 12,
  convByStatus: [
    { status: "Abierta", count: 34 },
    { status: "Resuelta", count: 45 },
    { status: "Cerrada", count: 44 },
  ],
  convBySource: [
    { source: "whatsapp", count: 68 },
    { source: "email", count: 42 },
    { source: "instagram", count: 15 },
    { source: "facebook", count: 10 },
  ],
  weeklyConvs: [
    { week: "W1", count: 12 },
    { week: "W2", count: 18 },
    { week: "W3", count: 22 },
    { week: "W4", count: 15 },
    { week: "W5", count: 25 },
    { week: "W6", count: 20 },
    { week: "W7", count: 28 },
    { week: "W8", count: 24 },
    { week: "W9", count: 30 },
    { week: "W10", count: 22 },
    { week: "W11", count: 26 },
    { week: "W12", count: 32 },
  ],
}

export default function GlobalInboxPage() {
  const [activeTab, setActiveTab] = useState<Tab>("summary")
  const [summarySubtab, setSummarySubtab] = useState<SummarySubtab>("leads")
  const [summaryYear, setSummaryYear] = useState("2025-2026")
  const [summarySchool, setSummarySchool] = useState("")
  const [isPinned, setIsPinned] = useState(false)
  const [selectedLead, setSelectedLead] = useState<typeof mockLeads[0] | null>(null)
  const [showLegend, setShowLegend] = useState(false)
  const [filterYear, setFilterYear] = useState("2025-2026")
  const [filterStatus, setFilterStatus] = useState("")
  const [filterSchool, setFilterSchool] = useState("")
  const [searchTerm, setSearchTerm] = useState("")

  // Filter leads
  const filteredLeads = mockLeads.filter(lead => {
    if (filterYear && lead.year !== filterYear) return false
    if (filterStatus && lead.status !== filterStatus) return false
    if (filterSchool && lead.school !== filterSchool) return false
    if (searchTerm) {
      const term = searchTerm.toLowerCase()
      const matchesSearch = lead.name.toLowerCase().includes(term) ||
        lead.phone.toLowerCase().includes(term) ||
        lead.status.toLowerCase().includes(term) ||
        lead.studentName.toLowerCase().includes(term)
      if (!matchesSearch) return false
    }
    return true
  })

  const newLeadCount = mockLeads.filter(l => l.status === "Nuevo" || l.status === "Abierto").length
  const unreadConvCount = mockConversations.filter(c => c.unreadCount > 0).length

  return (
    <div className="flex h-screen flex-col">
      <AppNav />

      {/* Tabs: Summary | Leads | Conversations */}
      <div className="border-b border-border bg-card">
        <div className="flex">
          <button
            onClick={() => setActiveTab("summary")}
            className={cn(
              "flex items-center gap-2 border-b-2 px-4 py-3 text-sm font-medium transition-colors",
              activeTab === "summary"
                ? "border-primary text-primary"
                : "border-transparent text-muted-foreground hover:border-muted hover:text-foreground"
            )}
          >
            <BarChart3 size={16} />
            Summary
          </button>
          <button
            onClick={() => setActiveTab("leads")}
            className={cn(
              "flex items-center gap-2 border-b-2 px-4 py-3 text-sm font-medium transition-colors",
              activeTab === "leads"
                ? "border-primary text-primary"
                : "border-transparent text-muted-foreground hover:border-muted hover:text-foreground"
            )}
          >
            <Users size={16} />
            Leads
            {newLeadCount > 0 && (
              <span className="rounded-full bg-primary px-2 py-0.5 text-xs font-semibold text-primary-foreground">
                {newLeadCount}
              </span>
            )}
          </button>
          <button
            onClick={() => setActiveTab("conversations")}
            className={cn(
              "flex items-center gap-2 border-b-2 px-4 py-3 text-sm font-medium transition-colors",
              activeTab === "conversations"
                ? "border-primary text-primary"
                : "border-transparent text-muted-foreground hover:border-muted hover:text-foreground"
            )}
          >
            <MessageSquare size={16} />
            Conversations
            {unreadConvCount > 0 && (
              <span className="rounded-full bg-primary px-2 py-0.5 text-xs font-semibold text-primary-foreground">
                {unreadConvCount}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Tab Content */}
      {activeTab === "summary" ? (
        <div className="flex-1 overflow-auto bg-background p-4">
          {/* Filters Row */}
          <div className="mb-4 flex items-center gap-4">
            <div className="flex flex-col">
              <label className="mb-1 text-xs text-muted-foreground">Entrance Year</label>
              <select 
                value={summaryYear}
                onChange={(e) => setSummaryYear(e.target.value)}
                className="rounded-md border border-border bg-card px-3 py-2 text-sm"
              >
                {yearOptions.map(opt => (
                  <option key={opt.value} value={opt.value}>{opt.label}</option>
                ))}
              </select>
            </div>
            <div className="flex flex-col">
              <label className="mb-1 text-xs text-muted-foreground">School</label>
              <select 
                value={summarySchool}
                onChange={(e) => setSummarySchool(e.target.value)}
                className="rounded-md border border-border bg-card px-3 py-2 text-sm"
              >
                {schoolOptions.map(opt => (
                  <option key={opt.value} value={opt.value}>{opt.label}</option>
                ))}
              </select>
            </div>
            <div className="flex flex-col">
              <label className="mb-1 text-xs text-transparent">Actions</label>
              <div className="flex gap-2">
                <button className="flex h-9 w-9 items-center justify-center rounded-md border border-border bg-card text-muted-foreground hover:bg-muted">
                  <RefreshCw size={16} />
                </button>
                <button 
                  onClick={() => setIsPinned(!isPinned)}
                  className={cn(
                    "flex h-9 w-9 items-center justify-center rounded-md border",
                    isPinned ? "border-primary bg-primary/10 text-primary" : "border-border bg-card text-muted-foreground hover:bg-muted"
                  )}
                >
                  <Pin size={16} />
                </button>
              </div>
            </div>
          </div>

          {/* Sub-tabs */}
          <div className="mb-4 border-b border-border">
            <div className="flex">
              <button
                onClick={() => setSummarySubtab("leads")}
                className={cn(
                  "flex items-center gap-2 border-b-2 px-4 py-2 text-sm font-medium transition-colors",
                  summarySubtab === "leads"
                    ? "border-primary text-primary"
                    : "border-transparent text-muted-foreground hover:text-foreground"
                )}
              >
                <Users size={14} />
                Leads Summary
              </button>
              <button
                onClick={() => setSummarySubtab("conversations")}
                className={cn(
                  "flex items-center gap-2 border-b-2 px-4 py-2 text-sm font-medium transition-colors",
                  summarySubtab === "conversations"
                    ? "border-primary text-primary"
                    : "border-transparent text-muted-foreground hover:text-foreground"
                )}
              >
                <MessageSquare size={14} />
                Conversations Summary
              </button>
            </div>
          </div>

          {/* Leads Summary Content */}
          {summarySubtab === "leads" && (
            <div className="space-y-4">
              {/* KPI Cards */}
              <div className="grid grid-cols-4 gap-4">
                <div className="rounded-lg border border-border bg-muted/30 p-4 text-center">
                  <p className="text-xs uppercase text-muted-foreground">Total Leads</p>
                  <p className="text-3xl font-bold">{mockSummaryStats.totalLeads}</p>
                </div>
                <div className="rounded-lg border border-sky-200 bg-sky-50 p-4 text-center">
                  <p className="text-xs uppercase text-muted-foreground">New</p>
                  <p className="text-3xl font-bold text-sky-700">{mockSummaryStats.newCount}</p>
                </div>
                <div className="rounded-lg border border-green-200 bg-green-50 p-4 text-center">
                  <p className="text-xs uppercase text-muted-foreground">Enrolled</p>
                  <p className="text-3xl font-bold text-green-700">{mockSummaryStats.enrolledCount}</p>
                </div>
                <div className="rounded-lg border border-red-200 bg-red-50 p-4 text-center">
                  <p className="text-xs uppercase text-muted-foreground">Lost</p>
                  <p className="text-3xl font-bold text-red-700">{mockSummaryStats.lostCount}</p>
                </div>
              </div>

              {/* Charts Row 1 */}
              <div className="grid grid-cols-2 gap-4">
                {/* Leads by Status */}
                <div className="rounded-lg border border-border bg-card p-4">
                  <h3 className="mb-3 font-medium">Leads by Status</h3>
                  <div className="space-y-2">
                    {mockSummaryStats.leadsByStatus.map(item => {
                      const max = Math.max(...mockSummaryStats.leadsByStatus.map(i => i.count))
                      return (
                        <div key={item.status} className="flex items-center gap-2">
                          <span className="w-24 truncate text-xs text-muted-foreground">{item.status}</span>
                          <div className="h-5 flex-1 overflow-hidden rounded bg-muted">
                            <div 
                              className="h-full rounded bg-gradient-to-r from-sky-500 to-sky-600" 
                              style={{ width: `${(item.count / max) * 100}%` }}
                            />
                          </div>
                          <span className="w-8 text-right text-sm font-medium">{item.count}</span>
                        </div>
                      )
                    })}
                  </div>
                </div>
                {/* Leads by Stage */}
                <div className="rounded-lg border border-border bg-card p-4">
                  <h3 className="mb-3 font-medium">Leads by Stage</h3>
                  <div className="space-y-2">
                    {mockSummaryStats.leadsByStage.map(item => {
                      const max = Math.max(...mockSummaryStats.leadsByStage.map(i => i.count))
                      return (
                        <div key={item.stage} className="flex items-center gap-2">
                          <span className="w-24 truncate text-xs text-muted-foreground">{item.stage}</span>
                          <div className="h-5 flex-1 overflow-hidden rounded bg-muted">
                            <div 
                              className="h-full rounded bg-gradient-to-r from-violet-500 to-violet-600" 
                              style={{ width: `${(item.count / max) * 100}%` }}
                            />
                          </div>
                          <span className="w-8 text-right text-sm font-medium">{item.count}</span>
                        </div>
                      )
                    })}
                  </div>
                </div>
              </div>

              {/* Charts Row 2 */}
              <div className="grid grid-cols-2 gap-4">
                {/* Weekly Leads */}
                <div className="rounded-lg border border-border bg-card p-4">
                  <h3 className="mb-3 font-medium">Weekly Lead Entries (Last 12 Weeks)</h3>
                  <div className="flex h-32 items-end justify-between gap-1">
                    {mockSummaryStats.weeklyLeads.map(item => {
                      const max = Math.max(...mockSummaryStats.weeklyLeads.map(i => i.count))
                      return (
                        <div key={item.week} className="flex flex-1 flex-col items-center gap-1">
                          <div 
                            className="w-full rounded-t bg-sky-500" 
                            style={{ height: `${(item.count / max) * 100}%` }}
                            title={`${item.week}: ${item.count} leads`}
                          />
                          <span className="text-[10px] text-muted-foreground">{item.week}</span>
                        </div>
                      )
                    })}
                  </div>
                </div>
                {/* Last Contact Distribution */}
                <div className="rounded-lg border border-border bg-card p-4">
                  <h3 className="mb-3 font-medium">Last Contact (Days Ago)</h3>
                  <div className="space-y-2">
                    {mockSummaryStats.lastContactDist.map(item => {
                      const max = Math.max(...mockSummaryStats.lastContactDist.map(i => i.count))
                      return (
                        <div key={item.bucket} className="flex items-center gap-2">
                          <span className="w-24 truncate text-xs text-muted-foreground">{item.bucket}</span>
                          <div className="h-5 flex-1 overflow-hidden rounded bg-muted">
                            <div 
                              className="h-full rounded bg-gradient-to-r from-amber-500 to-amber-600" 
                              style={{ width: `${(item.count / max) * 100}%` }}
                            />
                          </div>
                          <span className="w-8 text-right text-sm font-medium">{item.count}</span>
                        </div>
                      )
                    })}
                  </div>
                </div>
              </div>

              {/* Leads by Grade */}
              <div className="rounded-lg border border-border bg-card p-4">
                <h3 className="mb-3 font-medium">Leads by Grade (Top 12)</h3>
                <div className="grid grid-cols-2 gap-x-8 gap-y-2">
                  {mockSummaryStats.leadsByGrade.map(item => {
                    const max = Math.max(...mockSummaryStats.leadsByGrade.map(i => i.count))
                    return (
                      <div key={item.grade} className="flex items-center gap-2">
                        <span className="w-28 truncate text-xs text-muted-foreground">{item.grade}</span>
                        <div className="h-5 flex-1 overflow-hidden rounded bg-muted">
                          <div 
                            className="h-full rounded bg-gradient-to-r from-emerald-500 to-emerald-600" 
                            style={{ width: `${(item.count / max) * 100}%` }}
                          />
                        </div>
                        <span className="w-8 text-right text-sm font-medium">{item.count}</span>
                      </div>
                    )
                  })}
                </div>
              </div>
            </div>
          )}

          {/* Conversations Summary Content */}
          {summarySubtab === "conversations" && (
            <div className="space-y-4">
              {/* KPI Cards */}
              <div className="grid grid-cols-4 gap-4">
                <div className="rounded-lg border border-blue-200 bg-blue-50 p-4 text-center">
                  <p className="text-xs uppercase text-muted-foreground">Open</p>
                  <p className="text-3xl font-bold text-blue-700">{mockSummaryStats.openConvs}</p>
                </div>
                <div className="rounded-lg border border-gray-200 bg-gray-50 p-4 text-center">
                  <p className="text-xs uppercase text-muted-foreground">Closed</p>
                  <p className="text-3xl font-bold text-gray-700">{mockSummaryStats.closedConvs}</p>
                </div>
                <div className="rounded-lg border border-amber-200 bg-amber-50 p-4 text-center">
                  <p className="text-xs uppercase text-muted-foreground">Unlinked</p>
                  <p className="text-3xl font-bold text-amber-700">{mockSummaryStats.unlinkedConvs}</p>
                </div>
                <div className="rounded-lg border border-border bg-muted/30 p-4 text-center">
                  <p className="text-xs uppercase text-muted-foreground">Total</p>
                  <p className="text-3xl font-bold">{mockSummaryStats.openConvs + mockSummaryStats.closedConvs}</p>
                </div>
              </div>

              {/* Charts Row */}
              <div className="grid grid-cols-2 gap-4">
                {/* Conversations by Status */}
                <div className="rounded-lg border border-border bg-card p-4">
                  <h3 className="mb-3 font-medium">Conversations by Status</h3>
                  <div className="space-y-2">
                    {mockSummaryStats.convByStatus.map(item => {
                      const max = Math.max(...mockSummaryStats.convByStatus.map(i => i.count))
                      return (
                        <div key={item.status} className="flex items-center gap-2">
                          <span className="w-24 truncate text-xs text-muted-foreground">{item.status}</span>
                          <div className="h-5 flex-1 overflow-hidden rounded bg-muted">
                            <div 
                              className="h-full rounded bg-gradient-to-r from-cyan-500 to-cyan-600" 
                              style={{ width: `${(item.count / max) * 100}%` }}
                            />
                          </div>
                          <span className="w-8 text-right text-sm font-medium">{item.count}</span>
                        </div>
                      )
                    })}
                  </div>
                </div>
                {/* Conversations by Channel */}
                <div className="rounded-lg border border-border bg-card p-4">
                  <h3 className="mb-3 font-medium">Conversations by Channel</h3>
                  <div className="space-y-2">
                    {mockSummaryStats.convBySource.map(item => {
                      const max = Math.max(...mockSummaryStats.convBySource.map(i => i.count))
                      return (
                        <div key={item.source} className="flex items-center gap-2">
                          <span className="w-24 truncate text-xs text-muted-foreground">{item.source}</span>
                          <div className="h-5 flex-1 overflow-hidden rounded bg-muted">
                            <div 
                              className="h-full rounded bg-gradient-to-r from-pink-500 to-pink-600" 
                              style={{ width: `${(item.count / max) * 100}%` }}
                            />
                          </div>
                          <span className="w-8 text-right text-sm font-medium">{item.count}</span>
                        </div>
                      )
                    })}
                  </div>
                </div>
              </div>

              {/* Weekly Activity */}
              <div className="rounded-lg border border-border bg-card p-4">
                <h3 className="mb-3 font-medium">Weekly Conversation Activity (Last 12 Weeks)</h3>
                <div className="flex h-32 items-end justify-between gap-1">
                  {mockSummaryStats.weeklyConvs.map(item => {
                    const max = Math.max(...mockSummaryStats.weeklyConvs.map(i => i.count))
                    return (
                      <div key={item.week} className="flex flex-1 flex-col items-center gap-1">
                        <div 
                          className="w-full rounded-t bg-violet-500" 
                          style={{ height: `${(item.count / max) * 100}%` }}
                          title={`${item.week}: ${item.count} conversations`}
                        />
                        <span className="text-[10px] text-muted-foreground">{item.week}</span>
                      </div>
                    )
                  })}
                </div>
              </div>
            </div>
          )}
        </div>
      ) : activeTab === "leads" ? (
        <div className="flex-1 overflow-auto bg-background p-4">
          {/* Search Bar Row */}
          <div className="mb-4 flex items-center gap-2">
            {/* Search Input */}
            <div className="relative flex-1" style={{ maxWidth: 400 }}>
              <Search size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input
                type="text"
                placeholder="Search by name, phone, status, campaign..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full rounded-md border border-border bg-card py-2 pl-9 pr-3 text-sm"
              />
            </div>
            {/* Search Button */}
            <button className="flex h-9 w-9 items-center justify-center rounded-md bg-primary text-primary-foreground">
              <Search size={16} />
            </button>
            {/* Clear Button */}
            <button 
              onClick={() => setSearchTerm("")}
              className="flex h-9 w-9 items-center justify-center rounded-md border border-border bg-card text-muted-foreground hover:bg-muted"
            >
              <X size={16} />
            </button>
            
            {/* Spacer */}
            <div className="flex-1" />
            
            {/* New Lead Button */}
            <button className="flex items-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90">
              <Plus size={16} />
              New Lead
            </button>
          </div>

          {/* Filters Row */}
          <div className="mb-4 flex items-center gap-4">
            {/* Entrance Year Filter */}
            <div className="flex flex-col">
              <label className="mb-1 text-xs text-muted-foreground">Entrance Year</label>
              <div className="relative">
                <Calendar size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <select 
                  value={filterYear}
                  onChange={(e) => setFilterYear(e.target.value)}
                  className="rounded-md border border-border bg-card py-2 pl-9 pr-3 text-sm"
                >
                  {yearOptions.map(opt => (
                    <option key={opt.value} value={opt.value}>{opt.label}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Status Filter */}
            <div className="flex flex-col">
              <label className="mb-1 text-xs text-muted-foreground">Status</label>
              <div className="relative">
                <ListFilter size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <select 
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value)}
                  className="rounded-md border border-border bg-card py-2 pl-9 pr-3 text-sm"
                >
                  {statusOptions.map(opt => (
                    <option key={opt.value} value={opt.value}>{opt.label}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* School Filter */}
            <div className="flex flex-col">
              <label className="mb-1 text-xs text-muted-foreground">School</label>
              <div className="relative">
                <Building2 size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <select 
                  value={filterSchool}
                  onChange={(e) => setFilterSchool(e.target.value)}
                  className="rounded-md border border-border bg-card py-2 pl-9 pr-3 text-sm"
                >
                  {schoolOptions.map(opt => (
                    <option key={opt.value} value={opt.value}>{opt.label}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Legend Button */}
            <div className="relative flex flex-col">
              <label className="mb-1 text-xs text-transparent">Legend</label>
              <button
                onClick={() => setShowLegend(!showLegend)}
                className="flex items-center gap-1 rounded-md border border-border bg-card px-3 py-2 text-sm text-muted-foreground transition-colors hover:bg-muted"
                title="Ver leyenda"
              >
                <Info size={16} />
              </button>
              
              {/* Legend Popup */}
              {showLegend && (
                <div className="absolute right-0 top-full z-50 mt-1 w-64 rounded-lg border border-border bg-card p-4 shadow-lg">
                  <div className="mb-3 flex items-center justify-between">
                    <h3 className="font-medium">Legend</h3>
                    <button onClick={() => setShowLegend(false)} className="text-muted-foreground hover:text-foreground">
                      <X size={16} />
                    </button>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 rounded-md bg-blue-50 px-3 py-2 text-sm">
                      <span>New (0-3 days)</span>
                    </div>
                    <div className="flex items-center gap-2 rounded-md bg-amber-50 px-3 py-2 text-sm">
                      <span>New w/o call (4-6d)</span>
                    </div>
                    <div className="flex items-center gap-2 rounded-md bg-green-50 px-3 py-2 text-sm">
                      <span>Won / Enrollment / Enrolment</span>
                    </div>
                    <div className="flex items-center gap-2 rounded-md bg-gray-100 px-3 py-2 text-sm">
                      <span>Lost</span>
                    </div>
                    <div className="flex items-center gap-2 rounded-md bg-slate-200 px-3 py-2 text-sm">
                      <span>Granero/Barn</span>
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div className="ml-auto text-sm text-muted-foreground">
              {filteredLeads.length} leads encontrados
            </div>
          </div>

          <div className="overflow-hidden rounded-lg border border-border bg-card">
            <table className="w-full text-sm">
              <thead className="border-b border-border bg-muted/50">
                <tr>
                  <th className="px-3 py-3 text-left font-medium text-muted-foreground">#</th>
                  <th className="px-3 py-3 text-left font-medium text-muted-foreground">Nombre Contacto</th>
                  <th className="px-3 py-3 text-left font-medium text-muted-foreground">Nombre Alumno</th>
                  <th className="px-3 py-3 text-left font-medium text-muted-foreground">Etapa</th>
                  <th className="px-3 py-3 text-left font-medium text-muted-foreground">Curso</th>
                  <th className="px-3 py-3 text-left font-medium text-muted-foreground">Ano</th>
                  <th className="px-3 py-3 text-left font-medium text-muted-foreground">Estado</th>
                  <th className="px-3 py-3 text-left font-medium text-muted-foreground">Ultimo Contacto</th>
                  <th className="px-3 py-3 text-center font-medium text-muted-foreground">Contact</th>
                  <th className="px-3 py-3 text-left font-medium text-muted-foreground">Telefono</th>
                  <th className="px-3 py-3 text-left font-medium text-muted-foreground">Fecha Entrada</th>
                  <th className="px-3 py-3 text-left font-medium text-muted-foreground">Colegio</th>
                </tr>
              </thead>
              <tbody>
                {filteredLeads.map((lead, idx) => (
                  <tr key={lead.id} className={cn("border-b border-border last:border-0", getRowColor(lead))}>
                    <td className="px-3 py-3 text-muted-foreground">{idx + 1}</td>
                    <td className="px-3 py-3 font-medium">{lead.name}</td>
                    <td className="px-3 py-3">{lead.studentName}</td>
                    <td className="px-3 py-3">{lead.stage}</td>
                    <td className="px-3 py-3">{lead.grade}</td>
                    <td className="px-3 py-3">{lead.year}</td>
                    <td className="px-3 py-3">
                      <span className={cn(
                        "rounded-full px-2 py-0.5 text-xs font-medium",
                        lead.status === "Nuevo" ? "bg-blue-100 text-blue-700" : "bg-green-100 text-green-700"
                      )}>
                        {lead.status}
                      </span>
                    </td>
                    <td className="px-3 py-3 text-muted-foreground">
                      {lead.lastContact ? (
                        <>{lead.lastContact} {lead.convCount > 0 && <span className="text-primary">({lead.convCount})</span>}</>
                      ) : "-"}
                    </td>
                    <td className="px-3 py-3 text-center">
                      <button
                        onClick={() => setSelectedLead(lead)}
                        className="rounded p-1 text-muted-foreground transition-colors hover:bg-primary/10 hover:text-primary"
                        title="Ver conversaciones"
                      >
                        <MessageCircle size={18} />
                      </button>
                    </td>
                    <td className="px-3 py-3 text-muted-foreground">{lead.phone}</td>
                    <td className="px-3 py-3 text-muted-foreground">{lead.entryDate}</td>
                    <td className="px-3 py-3">{lead.school}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <InboxLayout
          conversations={mockConversations}
          title="Todas las conversaciones"
        />
      )}

      {/* Conversations Modal (60% width) */}
      {selectedLead && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
          <div className="relative flex h-[80vh] w-[60%] flex-col rounded-lg bg-card shadow-xl">
            <div className="flex items-center justify-between border-b border-border px-4 py-3">
              <h2 className="text-lg font-semibold">Conversaciones - {selectedLead.name}</h2>
              <button
                onClick={() => setSelectedLead(null)}
                className="rounded p-1 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
              >
                <X size={20} />
              </button>
            </div>
            <div className="flex-1 overflow-auto p-4">
              <div className="flex h-full items-center justify-center text-muted-foreground">
                <div className="text-center">
                  <MessageCircle size={48} className="mx-auto mb-2 opacity-50" />
                  <p>Aqui se mostraria el componente brevoRecordChat</p>
                  <p className="text-sm">para el Lead: {selectedLead.name}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
