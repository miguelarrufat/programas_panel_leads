"use client"

import { Download, FileArchive, Database, Code, Layers, AlertTriangle, CheckCircle2 } from "lucide-react"
import Link from "next/link"

export default function DownloadsPage() {
  return (
    <div className="min-h-screen bg-background p-8">
      <div className="mx-auto max-w-3xl">
        <Link href="/" className="mb-6 inline-flex items-center text-sm text-muted-foreground hover:text-foreground">
          ← Volver al Inbox
        </Link>
        
        <h1 className="mb-2 text-3xl font-bold">Salesforce Deployment ZIPs</h1>
        <p className="mb-4 text-muted-foreground">
          Para desplegar en Produccion via Workbench
        </p>

        {/* Production Instructions */}
        <div className="mb-6 flex items-start gap-3 rounded-lg border border-blue-200 bg-blue-50 p-4">
          <CheckCircle2 className="mt-0.5 h-5 w-5 text-blue-600" />
          <div className="text-sm">
            <p className="font-medium text-blue-800">Deploy en 2 pasos para Produccion:</p>
            <ol className="mt-1 list-decimal pl-4 text-blue-700">
              <li>Primero: ZIP 1 (Metadata + test independiente)</li>
              <li>Segundo: ZIP 2 (Apex + LWC + tests completos)</li>
            </ol>
          </div>
        </div>

        <div className="space-y-4">
          {/* ZIP 1 - Metadata */}
          <div className="rounded-lg border-2 border-blue-500 bg-card p-6">
            <div className="flex items-start gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-blue-100 text-blue-600">
                <Database size={24} />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className="rounded bg-blue-500 px-2 py-0.5 text-xs font-medium text-white">PASO 1</span>
                  <h2 className="text-lg font-semibold">Metadata + Test Independiente</h2>
                </div>
                <p className="mt-1 text-sm text-muted-foreground">
                  Objetos custom, campos, Named Credentials + BrevoDeployValidator (test sin dependencias)
                </p>
                <div className="mt-2 rounded bg-muted p-2 text-xs">
                  <strong>Test Level:</strong> <code className="text-blue-700">RunSpecifiedTests</code><br/>
                  <strong>Run Tests:</strong> <code className="text-blue-700">BrevoDeployValidator</code>
                  <p className="mt-1 text-green-600">Incluye su propia clase de test - se puede desplegar independientemente</p>
                </div>
              </div>
              <a
                href="/api/salesforce-zip/metadata"
                download="1-brevo-metadata.zip"
                className="flex items-center gap-2 rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
              >
                <Download size={16} />
                Descargar
              </a>
            </div>
          </div>

          {/* ZIP 2 - Apex + LWC */}
          <div className="rounded-lg border-2 border-green-500 bg-card p-6">
            <div className="flex items-start gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-green-100 text-green-600">
                <Code size={24} />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className="rounded bg-green-500 px-2 py-0.5 text-xs font-medium text-white">PASO 2</span>
                  <h2 className="text-lg font-semibold">Apex + LWC + Tests</h2>
                </div>
                <p className="mt-1 text-sm text-muted-foreground">
                  Controllers, Handlers, Triggers, Tests y Lightning Web Components
                </p>
                <div className="mt-2 rounded bg-muted p-2 text-xs">
                  <strong>Test Level:</strong> <code className="text-green-700">RunSpecifiedTests</code><br/>
                  <strong>Run Tests:</strong><br/>
                  <code className="text-green-700">
                    BrevoConversationsControllerTest, BrevoWebhookHandlerTest, BrevoLeadTriggerHandlerTest, BrevoFieldUpdaterTest, BrevoMessageTriggerHandlerTest
                  </code>
                  <p className="mt-1 text-muted-foreground">Despliega despues de que Metadata este en el org</p>
                </div>
              </div>
              <a
                href="/api/salesforce-zip/apex-lwc"
                download="2-brevo-apex-lwc.zip"
                className="flex items-center gap-2 rounded-md bg-green-600 px-4 py-2 text-sm font-medium text-white hover:bg-green-700"
              >
                <Download size={16} />
                Descargar
              </a>
            </div>
          </div>

          {/* Separator */}
          <div className="flex items-center gap-4 py-4">
            <div className="h-px flex-1 bg-border" />
            <span className="text-xs text-muted-foreground">Alternativas</span>
            <div className="h-px flex-1 bg-border" />
          </div>

          {/* ZIP Completo */}
          <div className="rounded-lg border border-dashed border-border bg-muted/30 p-6">
            <div className="flex items-start gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-gray-200 text-gray-600">
                <FileArchive size={24} />
              </div>
              <div className="flex-1">
                <h2 className="text-lg font-semibold">ZIP Completo (Todo junto)</h2>
                <p className="mt-1 text-sm text-muted-foreground">
                  Metadata + Apex + LWC en un solo archivo
                </p>
                <div className="mt-2 rounded bg-muted p-2 text-xs">
                  <strong>Run Tests:</strong> Los 4 tests principales
                </div>
              </div>
              <a
                href="/api/salesforce-zip"
                download="brevo-salesforce-complete.zip"
                className="flex items-center gap-2 rounded-md border border-border bg-card px-4 py-2 text-sm font-medium hover:bg-muted"
              >
                <Download size={16} />
                Descargar
              </a>
            </div>
          </div>
        </div>

        {/* Changelog */}
        <div className="mt-8 rounded-lg border bg-card p-6">
          <h2 className="mb-4 flex items-center gap-2 text-lg font-semibold">
            <Layers size={20} />
            Changelog - Ultima actualizacion
          </h2>
          <div className="space-y-3 text-sm">
            <div className="rounded bg-muted/50 p-3">
              <p className="font-medium text-foreground">v2.9.10 - 4 Marzo 2026</p>
              <ul className="mt-2 list-disc pl-5 text-muted-foreground space-y-1">
                <li><strong>Fix package.xml:</strong> Agregados BrevoMessageTrigger, BrevoMessageTriggerHandler y BrevoMessageTriggerHandlerTest al package.xml</li>
                <li><strong>Trigger BrevoMessageTrigger:</strong> Actualiza Lead.Fecha_de_ltima_Llamada__c cuando se crea un mensaje con Sender_Type__c='agent'</li>
                <li><strong>Contador emitidas via Brevo_Message:</strong> Cuenta conversaciones que tienen al menos un mensaje con Sender_Type__c='agent'</li>
                <li><strong>Last Contact desde Lead:</strong> Ahora usa Lead.Fecha_de_ltima_Llamada__c</li>
                <li><strong>Fix carga inicial Leads:</strong> connectedCallback ahora carga loadSchoolOptions() y loadLeads() al iniciar</li>
                <li><strong>Tab Leads por defecto:</strong> Al cargar el LWC, se muestra la tab Leads en lugar de Conversations</li>
                <li><strong>Metricas separadas:</strong> Enrolled (Status='Convertido') vs Funnel Converted (IsConverted=true)</li>
                <li><strong>Fix filtro Enrollment:</strong> Cuando Status=Convertido, busca IsConverted=true para mostrar leads convertidos</li>
                <li><strong>KPIs corregidos con API Names:</strong> New, Enrolled (Convertido), Interview (Entrevista1), Barn (Granero), Lost (Perdido)</li>
                <li><strong>Nuevo KPI Interview:</strong> Muestra leads con status Entrevista1</li>
                <li><strong>6 KPIs en fila:</strong> Total Leads, New, Interview, Enrolled, Barn, Lost</li>
                <li><strong>Leads by Entrance Year:</strong> Nueva tabla en Summary mostrando leads por ano y status (visible solo con filtro All)</li>
                <li><strong>Entrance Year default All:</strong> El filtro de Entrance Year ahora tiene All como valor por defecto</li>
                <li><strong>Fix Conversion Funnel rates:</strong> Calculo de stepRate y totalRate con variables Decimal</li>
                <li><strong>Fix Leads by Grade:</strong> Ordena en Apex consultando Product2.Orden_de_los_cursos__c</li>
                <li><strong>Weekly Lead Entries con eje Y:</strong> Grafico muestra numeros en eje Y, lineas de grid y valores sobre cada punto</li>
                <li><strong>Modal Related al 50%:</strong> Popup mas ancho para que no se corte el contenido</li>
                <li><strong>Columna Etapa en Related:</strong> Nueva columna con Curso_de_Inter_s__r.Etapa__c</li>
                <li><strong>Grade con nombre:</strong> Usa Curso_de_Inter_s__r.Name en hijos de Contact</li>
                <li><strong>Fix Hijos de Contact:</strong> Objeto Relacion_de_alumno__c con Padre_Madre__c y Hijo__c</li>
              </ul>
            </div>
            <div className="rounded bg-muted/50 p-3">
              <p className="font-medium text-foreground">v2.5 - Anterior</p>
              <ul className="mt-2 list-disc pl-5 text-muted-foreground space-y-1">
                <li>5 KPIs con porcentajes: Total Leads, New, Enrolled, Granero, Lost</li>
                <li>Contact Name clickable - abre Lead en nueva pestana</li>
                <li>Lead Status badge azul en Conversations</li>
                <li>Flow Status en popup 60%</li>
                <li>Related Records con hijos de Contact y datos de Opportunity</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
